# PaddleOCR coordinate smoke test

- source: `E:\申博材料\Davood Shojaei\cache\model_phase1\law_sources\Level 3 (Departmental Regulations)\GB_T50500-2024_建设工程工程量清单计价标准.pdf`
- source_sha256: `86223fe842088d3abbf57b2bc4db5ac9001c3f783a1fda0c6cb3b9c6778999f8`
- status: `needs_human_review`

## Page 1

<!-- source_locator: DOC-86223fe84208::pdf-page-0001::ocr-bbox-0001 -->
建设工程工程量清单计价

<!-- source_locator: DOC-86223fe84208::pdf-page-0001::ocr-bbox-0002 -->
(GB/T 50500—2024)

<!-- source_locator: DOC-86223fe84208::pdf-page-0001::ocr-bbox-0003 -->
及计算标准应用与实务

<!-- source_locator: DOC-86223fe84208::pdf-page-0001::ocr-bbox-0004 -->
JIANSHE GONGCHENG GONGCHENGLIANG QINGDAN

<!-- source_locator: DOC-86223fe84208::pdf-page-0001::ocr-bbox-0005 -->
JIJIA JI JISUAN BIAOZHUN YINGYONG YU SHIWU

<!-- source_locator: DOC-86223fe84208::pdf-page-0001::ocr-bbox-0006 -->
本书编委会

<!-- source_locator: DOC-86223fe84208::pdf-page-0001::ocr-bbox-0007 -->
编著

## Page 2

## Page 3

<!-- source_locator: DOC-86223fe84208::pdf-page-0003::ocr-bbox-0001 -->
建设工程工程量清单计价

<!-- source_locator: DOC-86223fe84208::pdf-page-0003::ocr-bbox-0002 -->
(GB/T 50500-2024)

<!-- source_locator: DOC-86223fe84208::pdf-page-0003::ocr-bbox-0003 -->
及计算标准应用与实务

<!-- source_locator: DOC-86223fe84208::pdf-page-0003::ocr-bbox-0004 -->
JIANSHE GONGCHENG GONGCHENGLIANG QINGDAN

<!-- source_locator: DOC-86223fe84208::pdf-page-0003::ocr-bbox-0005 -->
JIJIA JI JISUAN BIAOZHUN YINGYONG YU SHIWU

<!-- source_locator: DOC-86223fe84208::pdf-page-0003::ocr-bbox-0006 -->
本书编委会编著

## Page 4

## Page 5

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0001 -->
前言

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0002 -->
为贯彻落实《建设工程工程量清单计价标准》（GB/T 50500—2024)，积极

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0003 -->
响应《湖北省深化工程造价市场化改革实施方案》精神，湖北省住房和城乡建

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0004 -->
设厅组织造价咨询、施工、法律等多方领域的行业专家，围绕工程造价市场化

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0005 -->
改革议题展开为期5个多月的深入学习与研讨。专家们结合本省工程实际情况

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0006 -->
及实践经验，经多轮研讨与论证，编制完成《建设工程工程量清单计价（GB/T

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0007 -->
50500一2024)及计算标准应用与实务》（以下简称“本实务”)，为行业从业人

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0008 -->
员精心打造了一份极具参考价值的学习资料。

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0009 -->
2024版工程量清单计价标准的发布，是工程计价模式从“政府定额主导”

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0010 -->
向“市场自主定价”转型的重要里程碑。在此关键节点，本实务应运而生，旨

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0011 -->
在为行业从业人员提供一套系统、实用、可操作的实施细则，推动新标准平稳

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0012 -->
落地，助力工程造价管理向科学化、精细化迈进。

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0013 -->
本实务以“立足国家标准，细化湖北特色”为宗旨，对标准条文进行本地

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0014 -->
化解析，并辅以丰富的应用实务示例。通过“条文解析+案例分析”的形式，

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0015 -->
聚焦市场化计价模式下最高投标限价编制依据、工程变更、价格调整、争议解

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0016 -->
决等热点问题，深入剖析编制思路与方法。同时，结合湖北省实际，完善了

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0017 -->
24版清单标准模式下的计价程序，制定了符合本省数据归集和交换标准的配

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0018 -->
套表格式样，切实强化实务操作性，帮助从业者攻克工作难点。

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0019 -->
在专业计算标准方面，本实务结合24版工程量计算标准，对各专业内容

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0020 -->
进行逐一注解分析，并以示例形式展现实际操作要点。针对各专业工程计算标

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0021 -->
准附录中清单子目不全、项目名称易混淆、特征描述易出错、计量单位易表述

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0022 -->
不当、计算规则难理解等问题，通过补充清单子目、特定注解、施工工艺说明、

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0023 -->
公式推导等方式，进行全方位、多角度的阐释，部分内容还辅以图表，力求让

<!-- source_locator: DOC-86223fe84208::pdf-page-0005::ocr-bbox-0024 -->
1

## Page 10

## Page 320

<!-- source_locator: DOC-86223fe84208::pdf-page-0320::ocr-bbox-0001 -->
建设工程工程量清单计价

<!-- source_locator: DOC-86223fe84208::pdf-page-0320::ocr-bbox-0002 -->
(GB/T 50500-2024)

<!-- source_locator: DOC-86223fe84208::pdf-page-0320::ocr-bbox-0003 -->
及计算标准应用与实务

<!-- source_locator: DOC-86223fe84208::pdf-page-0320::ocr-bbox-0004 -->
JIANSHE GONGCHENG GONGCHENGLIANG QINGDAN

<!-- source_locator: DOC-86223fe84208::pdf-page-0320::ocr-bbox-0005 -->
JIJIA JI JISUAN BIAOZHUN YINGYONG YU SHIWU
