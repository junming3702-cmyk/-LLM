# Phase 1 RAG corpus index

This directory contains a citation-preserving lexical baseline built from the local four-level law corpus. It is the retrieval preparation layer for the text-only MVP.

- `corpus_chunks.jsonl`: one citation-ready chunk per line with legal hierarchy, source role, locator, file hash and evidence boundary metadata.
- `lexical_postings.json`: deterministic Chinese-character-bigram and alphanumeric postings for reproducible lexical retrieval tests.
- `index_catalog.json`: build parameters, counts, source partitions, exclusions and limitations.
- `excluded_sources.jsonl`: source records deliberately excluded from candidate retrieval, such as superseded or incomplete duplicates.

The current index does not contain vector embeddings and does not call an LLM. Retrieval should default to `primary`, then consider `supplement`, `warning` or `verification` only with visible labels and human confirmation. External fallback results are not silently merged into this local index.
