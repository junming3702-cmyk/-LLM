# Embedding / hybrid retrieval comparison v1

本次运行使用60条 final synthetic gold issues和678个本地法规chunks。

注意：当前环境没有可用的 neural embedding runtime/model；因此 `char_tfidf_vector_proxy` 仅是可复现的稀疏向量代理，不得表述为神经 embedding 结果。

## Summary

| Mode | Supported cases | Recall@1 | Recall@3 | Recall@5 | Recall@10 | MRR | Unsupported/abstention cases |
|---|---:|---:|---:|---:|---:|---:|---:|
| lexical_bm25 | 52 | 0.635 | 0.827 | 0.865 | 0.923 | 0.744 | 8 |
| char_tfidf_vector_proxy | 52 | 0.596 | 0.865 | 0.904 | 0.942 | 0.722 | 8 |
| hybrid_bm25_char_tfidf_proxy | 52 | 0.731 | 0.846 | 0.904 | 0.942 | 0.801 | 8 |

## Interpretation boundary

本报告只比较本地 lexical baseline 与稀疏向量代理/混合排序。外部检索未调用，人工审查闭环未调用；gold evidence 只用于离线评价。
