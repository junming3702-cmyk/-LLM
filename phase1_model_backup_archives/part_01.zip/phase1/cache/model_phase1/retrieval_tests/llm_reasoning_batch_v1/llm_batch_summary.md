# LLM reasoning batch v1

- Model: `deepseek-chat`
- Requested rows: 60
- Written rows: 60
- Successful API responses: 60
- Valid JSON responses: 60
- Gate status: `{"corrected": 60}`
- Conclusion types after gate: `{"insufficient_information": 60}`
- Confidence after gate: `{"insufficient_information": 60}`
- External retrieval: not called
- Human review: not called; outputs remain review-required states
- Gold labels/answers: excluded from runtime requests

The JSONL file preserves raw model output and the deterministic gated response separately.
