# Contract sample labeling area

This directory contains the Phase 1 annotation schema, empty CSV template and annotation protocol. No contract sample has been added yet. The intended sample sources are public, anonymized or synthetic full/partial contract-document bundles, subject to explicit provenance and hash recording.

Use `contract_review_label_template_v2.csv` for one finding per row and cite legal evidence using `chunk_id` values from `..\rag_index\corpus_chunks.jsonl`. Keep model proposals and human-adjudicated gold labels distinguishable in the audit trail.
