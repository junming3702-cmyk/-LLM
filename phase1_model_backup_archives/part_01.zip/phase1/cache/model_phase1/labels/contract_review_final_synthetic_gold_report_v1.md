# Final synthetic gold set v1

The 60-row adjudicated issue pool has been promoted after explicit user approval on 2026-08-23.

- Status: `final_synthetic_gold_for_retrieval_experiments`
- Records: 60
- Confirmation source: `user_approved_current_phase`
- Audit chain preserved: candidate pool → adjudicated pool → final gold

This promotion does not authorize embedding, LLM or external retrieval. Those remain the next separately reviewable phase.
