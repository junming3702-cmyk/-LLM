# Gold issue pool｜first-pass evidence adjudication

Reviewed rows: 60
Explicit corrections: 4 (SYN-P1-G04-I25, SYN-P1-G07-I46, SYN-P1-G08-I56, SYN-P1-G09-I57)

The pass verified every excerpt and cited chunk ID, then narrowed claims where the cited law did not directly support the original wording. The dataset remains pending user approval and is not yet final gold.

## Decisions

| Decision | Count |
|---|---:|
| `accepted` | 56 |
| `revised` | 4 |

## Human-review statuses

| Status | Count |
|---|---:|
| `accepted` | 44 |
| `insufficient_information` | 16 |

## Approval boundary

After user approval, this file may become the 60-row final synthetic gold set for retrieval comparison. Before that approval, all `agent_reviewed_pending_user_approval` rows remain provisional.
