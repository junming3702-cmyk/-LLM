# Gold issue pool｜human review batches

The first three rows were accepted in the previous synthetic sanity check. The 57 new rows below remain pending human confirmation.

## Batch 01｜SYN-P1-G01-I01–SYN-P1-G02-I10

| Issue | Category | Severity | Evidence boundary | Legal chunks | Status |
|---|---|---|---|---:|---|
| `SYN-P1-G01-I01` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G01-I02` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G01-I03` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G01-I04` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G01-I05` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G01-I06` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G01-I07` | `potential_non_compliance` | `high` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G02-I08` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G02-I09` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G02-I10` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |

## Batch 02｜SYN-P1-G02-I11–SYN-P1-G03-I20

| Issue | Category | Severity | Evidence boundary | Legal chunks | Status |
|---|---|---|---|---:|---|
| `SYN-P1-G02-I11` | `potential_non_compliance` | `high` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G02-I12` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G02-I13` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G02-I14` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G03-I15` | `potential_non_compliance` | `medium` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G03-I16` | `potential_non_compliance` | `high` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G03-I17` | `no_issue_identified` | `informational` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G03-I18` | `no_issue_identified` | `informational` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G03-I19` | `no_issue_identified` | `informational` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G03-I20` | `no_issue_identified` | `informational` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |

## Batch 03｜SYN-P1-G03-I21–SYN-P1-G05-I30

| Issue | Category | Severity | Evidence boundary | Legal chunks | Status |
|---|---|---|---|---:|---|
| `SYN-P1-G03-I21` | `no_issue_identified` | `informational` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G04-I22` | `no_issue_identified` | `informational` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G04-I23` | `no_issue_identified` | `informational` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G04-I24` | `no_issue_identified` | `informational` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G04-I25` | `no_issue_identified` | `informational` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G04-I26` | `no_issue_identified` | `informational` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G04-I27` | `no_issue_identified` | `informational` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G04-I28` | `no_issue_identified` | `informational` | `supported_by_primary_local_source` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G05-I29` | `missing_or_insufficient_evidence` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G05-I30` | `missing_or_insufficient_evidence` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |

## Batch 04｜SYN-P1-G05-I31–SYN-P1-G06-I40

| Issue | Category | Severity | Evidence boundary | Legal chunks | Status |
|---|---|---|---|---:|---|
| `SYN-P1-G05-I31` | `missing_or_insufficient_evidence` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G05-I32` | `missing_or_insufficient_evidence` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G05-I33` | `missing_or_insufficient_evidence` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G05-I34` | `missing_or_insufficient_evidence` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G05-I35` | `missing_or_insufficient_evidence` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G06-I36` | `missing_or_insufficient_evidence` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G06-I37` | `internal_inconsistency` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G06-I38` | `internal_inconsistency` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G06-I39` | `internal_inconsistency` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G06-I40` | `internal_inconsistency` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |

## Batch 05｜SYN-P1-G06-I41–SYN-P1-G08-I50

| Issue | Category | Severity | Evidence boundary | Legal chunks | Status |
|---|---|---|---|---:|---|
| `SYN-P1-G06-I41` | `internal_inconsistency` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G06-I42` | `internal_inconsistency` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G07-I43` | `cross_document_link_missing_or_inconsistent` | `medium` | `not_supported_by_current_corpus` | 0 | `candidate_pending_human_confirmation` |
| `SYN-P1-G07-I44` | `cross_document_link_missing_or_inconsistent` | `medium` | `not_supported_by_current_corpus` | 0 | `candidate_pending_human_confirmation` |
| `SYN-P1-G07-I45` | `cross_document_link_missing_or_inconsistent` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G07-I46` | `cross_document_link_missing_or_inconsistent` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G07-I47` | `cross_document_link_missing_or_inconsistent` | `medium` | `partially_supported` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G07-I48` | `out_of_scope_or_unverifiable` | `informational` | `not_supported_by_current_corpus` | 0 | `candidate_pending_human_confirmation` |
| `SYN-P1-G07-I49` | `out_of_scope_or_unverifiable` | `informational` | `not_supported_by_current_corpus` | 0 | `candidate_pending_human_confirmation` |
| `SYN-P1-G08-I50` | `out_of_scope_or_unverifiable` | `informational` | `not_supported_by_current_corpus` | 0 | `candidate_pending_human_confirmation` |

## Batch 06｜SYN-P1-G08-I51–SYN-P1-G09-I57

| Issue | Category | Severity | Evidence boundary | Legal chunks | Status |
|---|---|---|---|---:|---|
| `SYN-P1-G08-I51` | `out_of_scope_or_unverifiable` | `informational` | `not_supported_by_current_corpus` | 0 | `candidate_pending_human_confirmation` |
| `SYN-P1-G08-I52` | `potential_non_compliance` | `medium` | `supported_by_supplementary_source_only` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G08-I53` | `potential_non_compliance` | `medium` | `supported_by_supplementary_source_only` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G08-I54` | `potential_non_compliance` | `high` | `supported_by_multiple_local_levels` | 2 | `candidate_pending_human_confirmation` |
| `SYN-P1-G08-I55` | `potential_non_compliance` | `high` | `supported_by_multiple_local_levels` | 2 | `candidate_pending_human_confirmation` |
| `SYN-P1-G08-I56` | `temporal_or_version_uncertainty` | `medium` | `requires_human_legal_review` | 1 | `candidate_pending_human_confirmation` |
| `SYN-P1-G09-I57` | `temporal_or_version_uncertainty` | `medium` | `requires_human_legal_review` | 1 | `candidate_pending_human_confirmation` |

## Confirmation rule

A pending row becomes final gold only after a human reviewer confirms or revises the document excerpt, risk category, legal chunk citation, evidence boundary and recommended action. If a row is rejected or requires facts unavailable in the current corpus, retain it with the revised status and reason instead of deleting it.
