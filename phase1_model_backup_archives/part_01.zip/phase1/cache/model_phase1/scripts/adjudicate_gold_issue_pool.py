"""Perform a first-pass evidence audit of the expanded issue pool.

This is an assistant-aided adjudication pass, not a final legal opinion. It
checks every row's provenance and citation boundary, applies a small number of
explicit corrections, and leaves the final dataset pending user approval.
"""

from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import date
from pathlib import Path


ROOT = Path(r"E:\申博材料\Davood Shojaei\cache\model_phase1")
POOL = ROOT / "labels" / "contract_review_gold_pool_v1.jsonl"
CORPUS = ROOT / "rag_index" / "corpus_chunks.jsonl"
DOC_ROOT = ROOT / "documents_raw"
OUT = ROOT / "labels"


def load_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main() -> None:
    rows = load_jsonl(POOL)
    chunks = {row["chunk_id"]: row for row in load_jsonl(CORPUS)}
    all_docs = "\n".join(path.read_text(encoding="utf-8") for path in DOC_ROOT.rglob("*.txt"))
    reviewed = []
    corrections = []

    for row in rows:
        item = dict(row)
        issue_id = item["issue_id"]
        missing_chunks = [chunk_id for chunk_id in item["legal_basis_chunk_ids"] if chunk_id not in chunks]
        excerpt_found = item["document_excerpt"] in all_docs
        if missing_chunks or not excerpt_found:
            raise ValueError(f"Evidence audit failed for {issue_id}: missing_chunks={missing_chunks}, excerpt_found={excerpt_found}")

        # The previous three sanity-check findings stay accepted and retain
        # their previous provenance state.
        if item.get("annotation_state") == "human_confirmed_synthetic_v1":
            item["reviewer_type"] = "previously_accepted_synthetic_sanity_check"
            item["review_decision"] = "accepted"
            item["review_notes"] = "Retained from the previously approved three-case sanity check."
            reviewed.append(item)
            continue

        item["reviewer_type"] = "assistant_aided_evidence_audit"
        item["review_timestamp"] = str(date.today())
        item["annotation_state"] = "agent_reviewed_pending_user_approval"
        item["review_decision"] = "accepted"
        item["review_notes"] = "Excerpt located; cited chunk IDs resolved; evidence boundary reviewed. Final human/user approval remains pending."

        category = item["risk_category"]
        if category in {"missing_or_insufficient_evidence", "out_of_scope_or_unverifiable"}:
            item["human_review_status"] = "insufficient_information"
        elif category == "cross_document_link_missing_or_inconsistent" and not item["legal_basis_chunk_ids"]:
            item["human_review_status"] = "insufficient_information"
        else:
            item["human_review_status"] = "accepted"

        # Correction 1: a date/version mismatch is not itself supported by
        # Article 21. Keep the issue, but remove the overly specific citation.
        if issue_id == "SYN-P1-G08-I56":
            item["legal_basis_chunk_ids"] = []
            item["legal_basis_locators"] = []
            item["legal_basis_roles"] = []
            item["evidence_boundary"] = "requires_human_legal_review"
            item["human_review_status"] = "insufficient_information"
            item["review_decision"] = "revised"
            item["gold_risk_statement"] = "文件版本与补充通知所称法规版本之间的关系无法由当前文件包确认；当前材料不足以判断适用版本或修订效果，不应直接生成确定性合规结论。"
            item["recommended_human_action"] = "补充正式法规版本、公布/施行状态和修订关系，由人工法律专业人员确认适用版本。"
            item["review_notes"] = "Revised: Article 21 is not direct evidence of the version relationship; citation removed to prevent unsupported legal grounding."
            corrections.append(issue_id)

        # Correction 2: Article 9 supplies the three-month rule, but the
        # missing permit issue date prevents a temporal conclusion.
        if issue_id == "SYN-P1-G09-I57":
            item["evidence_boundary"] = "partially_supported"
            item["human_review_status"] = "insufficient_information"
            item["review_decision"] = "revised"
            item["gold_risk_statement"] = "《建筑法》第九条提供了施工许可证签发后三个月开工的时间规则，但当前材料没有签发日期，因此无法判断期限是否届满。"
            item["review_notes"] = "Revised: preserved Article 9 citation and narrowed the claim to a missing-date evidence gap."
            corrections.append(issue_id)

        # Correction 3: the missing receipt record does not prove a legal
        # breach; it only prevents verification of the notification process.
        if issue_id == "SYN-P1-G07-I46":
            item["review_decision"] = "revised"
            item["gold_risk_statement"] = "招标文件修改通知引用补充文件B，但当前文件包缺少投标人对B的签收记录；这不足以直接证明违反时限要求，却使通知范围和实际送达状态无法核验。"
            item["review_notes"] = "Revised: distinguished missing delivery evidence from a proven violation of Article 21."
            corrections.append(issue_id)

        # Correction 4: narrow the negative sample so it does not imply that
        # all Building Law Article 8 conditions were verified.
        if issue_id == "SYN-P1-G04-I25":
            item["gold_risk_statement"] = "当前条款列明已提供规划许可证和施工图纸等部分材料，与《建筑法》第八条对应条件相符；其他许可条件仍未在本 finding 中核验。"
            item["review_decision"] = "revised"
            item["review_notes"] = "Revised: limited the negative finding to the inspected evidence rather than the complete permit application."
            corrections.append(issue_id)

        reviewed.append(item)

    if len(reviewed) != 60:
        raise AssertionError(f"Expected 60 reviewed rows, got {len(reviewed)}")

    jsonl_path = OUT / "contract_review_gold_adjudicated_v1.jsonl"
    jsonl_path.write_text("\n".join(json.dumps(row, ensure_ascii=False) for row in reviewed) + "\n", encoding="utf-8")
    fields = sorted({key for row in reviewed for key in row})
    with (OUT / "contract_review_gold_adjudicated_v1.csv").open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for row in reviewed:
            writer.writerow({key: json.dumps(value, ensure_ascii=False) if isinstance(value, list) else value for key, value in row.items()})

    decisions = Counter(row["review_decision"] for row in reviewed)
    statuses = Counter(row["human_review_status"] for row in reviewed)
    manifest = {
        "dataset_version": "contract_review_gold_adjudicated_v1",
        "created_date": str(date.today()),
        "status": "first_pass_review_pending_user_approval",
        "rows": len(reviewed),
        "review_method": "assistant_aided_evidence_audit_with_explicit_corrections",
        "reviewed_source_pool": str(POOL),
        "decision_counts": dict(sorted(decisions.items())),
        "human_review_status_counts": dict(sorted(statuses.items())),
        "correction_issue_ids": corrections,
        "final_gold_ready": False,
        "next_action": "User approval or correction is required before promoting agent_reviewed rows to final gold.",
        "limitations": [
            "This pass checks traceability and claim boundaries; it is not a substitute for legal counsel.",
            "Synthetic documents are not real procurement records.",
            "No embedding, LLM or external fallback was used.",
        ],
    }
    (OUT / "contract_review_gold_adjudicated_manifest_v1.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    report = [
        "# Gold issue pool｜first-pass evidence adjudication",
        "",
        f"Reviewed rows: {len(reviewed)}",
        f"Explicit corrections: {len(corrections)} ({', '.join(corrections)})",
        "",
        "The pass verified every excerpt and cited chunk ID, then narrowed claims where the cited law did not directly support the original wording. The dataset remains pending user approval and is not yet final gold.",
        "",
        "## Decisions",
        "",
        "| Decision | Count |",
        "|---|---:|",
    ]
    report.extend(f"| `{key}` | {value} |" for key, value in sorted(decisions.items()))
    report.extend(["", "## Human-review statuses", "", "| Status | Count |", "|---|---:|"])
    report.extend(f"| `{key}` | {value} |" for key, value in sorted(statuses.items()))
    report.extend([
        "",
        "## Approval boundary",
        "",
        "After user approval, this file may become the 60-row final synthetic gold set for retrieval comparison. Before that approval, all `agent_reviewed_pending_user_approval` rows remain provisional.",
    ])
    (OUT / "contract_review_gold_adjudication_report_v1.md").write_text("\n".join(report) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
