"""Build a 50-80 issue-level synthetic candidate pool for human confirmation.

The generated clauses are synthetic test inputs. Legal basis IDs are resolved
from the current local RAG corpus rather than invented. New rows remain
pending_human_confirmation; they are not silently promoted to final gold.
"""

from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from datetime import date
from pathlib import Path


ROOT = Path(r"E:\申博材料\Davood Shojaei\cache\model_phase1")
CORPUS = ROOT / "rag_index" / "corpus_chunks.jsonl"
OUT_DOCS = ROOT / "documents_raw" / "synthetic_contract_gold_pool_v1"
OUT_LABELS = ROOT / "labels"
OUT_DOCS.mkdir(parents=True, exist_ok=True)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def load_chunks() -> list[dict]:
    return [json.loads(line) for line in CORPUS.read_text(encoding="utf-8").splitlines() if line.strip()]


def resolve_rules(chunks: list[dict]) -> dict[str, dict]:
    specs = {
        "reg15": ("中华人民共和国招标投标法实施条例", "第十五条", None),
        "reg16": ("中华人民共和国招标投标法实施条例", "第十六条", None),
        "reg20": ("中华人民共和国招标投标法实施条例", "第二十条", None),
        "reg21": ("中华人民共和国招标投标法实施条例", "第二十一条", None),
        "reg23": ("中华人民共和国招标投标法实施条例", "第二十三条", None),
        "reg24": ("中华人民共和国招标投标法实施条例", "第二十四条", None),
        "reg25": ("中华人民共和国招标投标法实施条例", "第二十五条", None),
        "reg26": ("中华人民共和国招标投标法实施条例", "第二十六条", None),
        "reg27": ("中华人民共和国招标投标法实施条例", "第二十七条", None),
        "reg35": ("中华人民共和国招标投标法实施条例", "第三十五条", None),
        "reg37": ("中华人民共和国招标投标法实施条例", "第三十七条", None),
        "reg39": ("中华人民共和国招标投标法实施条例", "第三十九条", None),
        "reg40": ("中华人民共和国招标投标法实施条例", "第四十条", None),
        "reg44": ("中华人民共和国招标投标法实施条例", "第四十四条", None),
        "reg46": ("中华人民共和国招标投标法实施条例", "第四十六条", None),
        "reg49": ("中华人民共和国招标投标法实施条例", "第四十九条", None),
        "reg50": ("中华人民共和国招标投标法实施条例", "第五十条", None),
        "law24": ("中华人民共和国招标投标法 20171227", "第二十四条", None),
        "law28": ("中华人民共和国招标投标法 20171227", "第二十八条", None),
        "law34": ("中华人民共和国招标投标法 20171227", "第三十四条", None),
        "law36": ("中华人民共和国招标投标法 20171227", "第三十六条", None),
        "law40": ("中华人民共和国招标投标法 20171227", "第四十条", None),
        "law41": ("中华人民共和国招标投标法 20171227", "第四十一条", None),
        "law46": ("中华人民共和国招标投标法 20171227", "第四十六条", None),
        "build7": ("中华人民共和国建筑法 20190423", "第七条", None),
        "build8": ("中华人民共和国建筑法 20190423", "第八条", None),
        "build9": ("中华人民共和国建筑法 20190423", "第九条", None),
        "build12": ("中华人民共和国建筑法 20190423", "第十二条", None),
        "sc2": ("四川省建筑管理条例", "第二条", None),
        "sc8": ("四川省建筑管理条例", "第八条", None),
        "sc11": ("四川省建筑管理条例", "第十一条", None),
        "sc12": ("四川省建筑管理条例", "第十二条", None),
        "sc15": ("四川省建筑管理条例", "第十五条", None),
        "sc18": ("四川省建筑管理条例", "第十八条", None),
        "sc35": ("四川省建筑管理条例", "第三十五条", None),
        "e2": ("电子招标投标办法最终稿", "第二条", None),
        "e3": ("电子招标投标办法最终稿", "第三条", None),
        "e7": ("电子招标投标办法最终稿", "第七条", None),
        "tech_timestamp": ("技术规范发布稿", "3.31", "应提供按照国家授时中心"),
        "tech_contract_link": ("技术规范发布稿", "3.31", "标段（包）与合同的关联关系"),
    }
    resolved = {}
    for key, (title_prefix, article, contains) in specs.items():
        candidates = [
            chunk for chunk in chunks
            if chunk["title"].startswith(title_prefix) and chunk["article"] == article
            and (contains is None or contains in chunk["text"])
        ]
        if not candidates:
            raise RuntimeError(f"Could not resolve local law chunk for {key}: {title_prefix} {article} {contains}")
        resolved[key] = candidates[0]
    return resolved


def add_case(cases, bundle_lines, seq, *, bundle_id, document_id, excerpt, location, category, severity, rule_keys, boundary, statement, action, scope_note="construction tender synthetic context"):
    rule_chunks = [RULES[key] for key in rule_keys]
    issue_id = f"{bundle_id}-I{seq:02d}"
    bundle_lines.append(f"{location} {excerpt}")
    cases.append({
        "sample_id": bundle_id,
        "project_id": bundle_id,
        "document_id": document_id,
        "document_type": "synthetic_contract_document",
        "document_location": location,
        "document_excerpt": excerpt,
        "issue_id": issue_id,
        "risk_category": category,
        "risk_severity": severity,
        "legal_basis_chunk_ids": [chunk["chunk_id"] for chunk in rule_chunks],
        "legal_basis_locators": [f"{chunk['title']} {chunk['article']}" for chunk in rule_chunks],
        "legal_basis_roles": [chunk["corpus_partition"] for chunk in rule_chunks],
        "gold_risk_statement": statement,
        "evidence_boundary": boundary,
        "recommended_human_action": action,
        "human_review_status": "pending",
        "annotation_state": "candidate_pending_human_confirmation",
        "annotator_id": "synthetic_candidate_author",
        "annotation_timestamp": str(date.today()),
        "reviewer_notes": f"Needs human confirmation before final gold designation. Scope: {scope_note}.",
    })


def main() -> None:
    global RULES
    RULES = resolve_rules(load_chunks())
    cases = []
    bundle_docs: dict[str, dict[str, list[str]]] = {}
    sequence = 0

    def case(**kwargs):
        nonlocal sequence
        sequence += 1
        bundle_id = f"SYN-P1-G{((sequence - 1) // 7) + 1:02d}"
        document_id = f"{bundle_id}-D{((sequence - 1) % 7) + 1:02d}"
        bundle_docs.setdefault(bundle_id, {}).setdefault(document_id, [])
        add_case(cases, bundle_docs[bundle_id][document_id], sequence, bundle_id=bundle_id, document_id=document_id, **kwargs)

    positive = [
        ("招标文件发售期仅为3日。", "reg16", "该期限低于本地 Level 2 条文所载的5日要求，应核验适用范围和版本。"),
        ("招标文件发售期为4日，且收取费用以获得利润为目的。", "reg16", "发售期限和收费目的均需要对照第十六条人工复核。"),
        ("资格后审在投标文件递交前由招标人单独完成。", "reg20", "资格后审时点与现有条文表述不一致，应人工核验。"),
        ("澄清文件影响报价，但仅在投标截止前7日发送且不顺延截止时间。", "reg21", "澄清时限和是否顺延存在潜在风险，应核验实际影响。"),
        ("招标文件含有排斥潜在投标人的条件，修改后直接开标，不重新招标。", "reg23", "如果该内容影响投标，修改后是否需要重新招标应提交人工复核。"),
        ("将依法必须招标的项目拆成两个标段以规避招标。", "reg24", "标段划分目的可能触及规避招标风险，不作自动法律结论。"),
        ("投标保证金按估算价3%收取，保证金有效期60日而投标有效期90日。", "reg26", "比例和有效期均与现有条文存在潜在不一致。"),
        ("招标文件规定最低投标限价为最高投标限价的80%。", "reg27", "设置最低投标限价的条款需要人工复核。"),
        ("投标人撤回文件后，招标人在15日后退还投标保证金。", "reg35", "保证金退还时点需要对照第三十五条复核。"),
        ("资格预审后更换联合体成员并继续参加投标。", "reg37", "联合体成员变化的法律后果需要人工确认。"),
        ("不同投标人的项目管理成员完全相同，且由同一单位制作投标文件。", "reg40", "该组合事实可能触及串通投标识别规则，应人工调查。"),
        ("开标时仅有2个投标人，招标人仍直接开标并定标。", "reg44", "投标人数量和后续流程需要人工核验。"),
        ("招标人指定某专家参加依法必须招标项目的评标委员会。", "reg46", "专家确定方式可能与现有条文不一致。"),
        ("评标委员会使用招标文件未载明的‘品牌偏好’作为评分标准。", "reg49", "评标依据超出招标文件范围的风险需要人工复核。"),
        ("以投标报价是否接近标底作为唯一否决条件。", "reg50", "该否决条件需要对照第五十条人工复核。"),
        ("依法必须招标项目从发售招标文件到投标截止仅安排12日。", "law24", "投标文件编制时间可能低于现有法律条文要求。"),
    ]
    for excerpt, rule, statement in positive:
        case(excerpt=excerpt, location=f"第{sequence + 1}.1条", category="potential_non_compliance", severity="high" if rule in {"reg26", "reg40", "law24"} else "medium", rule_keys=[rule], boundary="supported_by_primary_local_source", statement=statement, action="核对适用项目、版本和完整文件包后，由采购或法律专业人员决定是否修订。")

    negatives = [
        ("招标文件发售期为5日，费用仅限印刷和邮寄成本。", "reg16"),
        ("投标保证金为估算价2%，有效期与投标有效期一致。", "reg26"),
        ("招标文件载明投标有效期，并从投标截止日起算。", "reg25"),
        ("依法必须招标项目从招标文件发出至投标截止为20日。", "law24"),
        ("投标文件在截止时间前送达；截止后送达的文件不接收。", "law28"),
        ("开标时间和地点与招标文件预先确定的内容一致。", "law34"),
        ("开标过程公开拆封、宣读并记录归档。", "law36"),
        ("评标委员会仅按招标文件确定的标准和方法评审。", "law40"),
        ("建筑工程开工前已取得施工许可证，或已核对限额以下例外。", "build7"),
        ("申请施工许可证时已提供规划许可证及施工图纸等材料。", "build8"),
        ("四川项目的承包企业在核定资质等级和范围内参加投标。", "sc18"),
        ("电子招标文件与纸质形式在本办法适用范围内按同等法律效力处理。", "e2"),
    ]
    for excerpt, rule in negatives:
        case(excerpt=excerpt, location=f"第{sequence + 1}.2条", category="no_issue_identified", severity="informational", rule_keys=[rule], boundary="supported_by_primary_local_source", statement="在当前 synthetic context 下，条款文本与所引用本地来源的相应要求一致；不代表整个项目已完成合规审查。", action="记录为未发现当前问题，并保留人工抽查和版本核验。")

    information = [
        ("文件只写明‘投标有效期按规定执行’，未给出具体天数和起算点。", "reg25"),
        ("合同未提供项目估算价，因此无法核验投标保证金比例。", "reg26"),
        ("合同未提供投标有效期，无法核验保证金有效期是否一致。", "reg26"),
        ("补充通知未记录发送日期，无法判断是否满足澄清时间要求。", "reg21"),
        ("文件包未提供施工许可证或限额以下例外的证明材料。", "build7"),
        ("文件包未提供规划许可证，无法核验施工许可证申请条件。", "build8"),
        ("未提供承包企业专业技术人员执业资格证明。", "build12"),
        ("省外企业未提供在四川报送企业基本信息的记录。", "sc11"),
    ]
    for excerpt, rule in information:
        case(excerpt=excerpt, location=f"第{sequence + 1}.3条", category="missing_or_insufficient_evidence", severity="medium", rule_keys=[rule], boundary="partially_supported", statement="现有文件证据不足以完成确定性判断；需要补充文件、版本或项目事实后再审查。", action="补齐缺失材料并由人工确认其真实性、适用范围和时间状态。")

    inconsistencies = [
        ("正文写投标有效期90日，投标函写60日。", ["reg25"]),
        ("保证金表写估算价2%，专用条款写3%。", ["reg26"]),
        ("招标文件写开标地点为A会议室，开标记录写为B会议室。", ["law34"]),
        ("一处写最高投标限价1000万元，另一处写800万元且未说明计算方法。", ["reg27"]),
        ("项目地点一处写四川成都，另一处写云南昆明，地方适用性无法确定。", ["sc2"]),
        ("承包商资质表为二级，投标资格声明为一级，未说明有效版本。", ["sc18"]),
    ]
    for excerpt, rules in inconsistencies:
        case(excerpt=excerpt, location=f"第{sequence + 1}.4条", category="internal_inconsistency", severity="medium", rule_keys=rules, boundary="partially_supported", statement="文件包内部存在影响法规适用或合规判断的矛盾，当前不能直接确定最终法律结论。", action="锁定版本、核对原始文件和签署/发布记录，再由人工确认采用的事实。")

    cross_document = [
        ("评标办法以附件A为准，但文件包未提供附件A。", [], "无当前法规 chunk 能单独证明附件实际缺失；应先补齐文件包。"),
        ("合同引用‘最新工程量清单’，但没有列出文件名、版本或哈希。", [], "证据链无法追溯到具体文件，当前只能标记为跨文件风险。"),
        ("联合体协议被列为资格文件，但清单中没有该协议。", ["reg37"], "联合体文件缺失可能影响资格核验，但仍需人工确认项目是否接受联合体。"),
        ("招标文件修改通知引用补充文件B，投标人签收记录中没有B。", ["reg21"], "修改文件与签收记录之间缺乏可追溯关联。"),
        ("施工图纸目录引用图纸C，实际上传包中没有图纸C。", ["build8"], "施工图纸是相关许可条件之一，但当前不能据此作出最终法律判断。"),
    ]
    for excerpt, rules, statement in cross_document:
        case(excerpt=excerpt, location=f"第{sequence + 1}.5条", category="cross_document_link_missing_or_inconsistent", severity="medium", rule_keys=rules, boundary="partially_supported" if rules else "not_supported_by_current_corpus", statement=statement, action="补齐并固定引用文件、版本、哈希和接收记录；必要时提交法律专业人员复核。")

    out_scope = [
        "BIM模型中的梁截面与图纸是否存在几何碰撞，本次文本法规库无法判断。",
        "合同税费计算是否符合地方税收政策，当前招投标法规库不能单独核验。",
        "供应商材料性能是否满足未提供的专业技术标准，当前证据不足。",
        "项目现场实际噪声是否超过环境标准，不能由合同文字单独判断。",
    ]
    for excerpt in out_scope:
        case(excerpt=excerpt, location=f"第{sequence + 1}.6条", category="out_of_scope_or_unverifiable", severity="informational", rule_keys=[], boundary="not_supported_by_current_corpus", statement="该问题超出当前文本型招投标法规语料库能够验证的范围，不生成法规结论。", action="转交相应 BIM、工程技术、税务或现场检测流程，并保留人工复核标记。")

    supplements = [
        ("电子平台没有生成国家授时中心标准时间的时间戳。", "tech_timestamp"),
        ("平台没有建立标段（包）与合同的关联关系。", "tech_contract_link"),
    ]
    for excerpt, rule in supplements:
        case(excerpt=excerpt, location=f"第{sequence + 1}.7条", category="potential_non_compliance", severity="medium", rule_keys=[rule], boundary="supported_by_supplementary_source_only", statement="该问题可由当前 Level 3 技术规范补充文件支持，但不能仅凭补充文件作出核心法规效力结论。", action="核对技术规范适用范围、正式版本和系统实际功能，并由人工确认是否影响项目审查。", scope_note="supplement-only evidence")

    multi = [
        ("四川项目将施工工程指定给某单位，并通过拆分标段规避招标。", ["sc15", "reg24"]),
        ("四川项目未取得施工许可证即开工，且未提供限额以下例外依据。", ["build7", "sc12"]),
    ]
    for excerpt, rules in multi:
        case(excerpt=excerpt, location=f"第{sequence + 1}.8条", category="potential_non_compliance", severity="high", rule_keys=rules, boundary="supported_by_multiple_local_levels", statement="该条款同时涉及国家层级和四川地方层级来源；需要确认工程所在地、项目类型和各来源的适用关系后再判断。", action="先确认项目事实和地方适用范围，再由人工比较多层级来源并记录冲突处理。", scope_note="multi-law applicability")

    temporal = [
        ("文件标注为2020年版本，但补充通知引用2026年法规版本，未说明修订关系。", ["reg21"]),
        ("施工许可证资料没有签发日期，无法判断三个月开工期限是否已届满。", ["build9"]),
    ]
    for excerpt, rules in temporal:
        case(excerpt=excerpt, location=f"第{sequence + 1}.9条", category="temporal_or_version_uncertainty", severity="medium", rule_keys=rules, boundary="requires_human_legal_review", statement="当前证据不足以确定适用版本或时间状态，不能直接作出合规判断。", action="补充正式版本、公布/施行状态和关键日期，并进行人工法律复核。")

    if len(cases) != 57:
        raise AssertionError(f"Expected 57 new candidates, got {len(cases)}")

    # Write grouped synthetic documents.
    for old in OUT_DOCS.glob("*.txt"):
        old.unlink()
    manifest_rows = []
    for bundle_id, documents in sorted(bundle_docs.items()):
        for document_id, lines in sorted(documents.items()):
            path = OUT_DOCS / f"{document_id}.txt"
            header = [
                "[SYNTHETIC TEST DOCUMENT — NOT A REAL TENDER OR CONTRACT]",
                f"Bundle ID: {bundle_id}",
                f"Document ID: {document_id}",
                "Document type: synthetic_contract_document",
                "Project location: varies by issue; synthetic context only",
                "",
            ]
            path.write_text("\n".join(header + lines) + "\n", encoding="utf-8")
            manifest_rows.append({
                "sample_id": bundle_id,
                "document_id": document_id,
                "file_name": path.name,
                "raw_path": str(path),
                "file_hash": sha256(path),
                "source_status": "synthetic_candidate",
                "human_review_status": "pending_human_confirmation",
            })

    previous = []
    previous_path = OUT_LABELS / "contract_review_gold_v1.jsonl"
    if previous_path.exists():
        previous = [json.loads(line) for line in previous_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        for row in previous:
            row["annotation_state"] = "human_confirmed_synthetic_v1"
            row["legal_basis_roles"] = ["primary"]
    all_rows = previous + cases
    pool_path = OUT_LABELS / "contract_review_gold_pool_v1.jsonl"
    pool_path.write_text("\n".join(json.dumps(row, ensure_ascii=False) for row in all_rows) + "\n", encoding="utf-8")

    fieldnames = sorted({key for row in all_rows for key in row})
    with (OUT_LABELS / "contract_review_gold_pool_v1.csv").open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for row in all_rows:
            writer.writerow({key: json.dumps(value, ensure_ascii=False) if isinstance(value, list) else value for key, value in row.items()})

    with (OUT_DOCS / "sample_manifest.csv").open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(manifest_rows[0]))
        writer.writeheader()
        writer.writerows(manifest_rows)

    review_lines = [
        "# Gold issue pool｜human review batches",
        "",
        "The first three rows were accepted in the previous synthetic sanity check. The 57 new rows below remain pending human confirmation.",
        "",
    ]
    for batch_no, start in enumerate(range(0, len(cases), 10), start=1):
        batch = cases[start : start + 10]
        review_lines.append(f"## Batch {batch_no:02d}｜{batch[0]['issue_id']}–{batch[-1]['issue_id']}")
        review_lines.append("")
        review_lines.append("| Issue | Category | Severity | Evidence boundary | Legal chunks | Status |")
        review_lines.append("|---|---|---|---|---:|---|")
        for row in batch:
            review_lines.append(
                f"| `{row['issue_id']}` | `{row['risk_category']}` | `{row['risk_severity']}` | `{row['evidence_boundary']}` | {len(row['legal_basis_chunk_ids'])} | `{row['annotation_state']}` |"
            )
        review_lines.append("")
    review_lines.extend([
        "## Confirmation rule",
        "",
        "A pending row becomes final gold only after a human reviewer confirms or revises the document excerpt, risk category, legal chunk citation, evidence boundary and recommended action. If a row is rejected or requires facts unavailable in the current corpus, retain it with the revised status and reason instead of deleting it.",
    ])
    (OUT_LABELS / "contract_review_gold_pool_review_batches_v1.md").write_text("\n".join(review_lines) + "\n", encoding="utf-8")

    counts = Counter(row["risk_category"] for row in all_rows)
    states = Counter(row["annotation_state"] for row in all_rows)
    manifest = {
        "dataset_version": "contract_review_gold_pool_v1",
        "created_date": str(date.today()),
        "status": "candidate_pool_pending_human_confirmation",
        "total_rows": len(all_rows),
        "previous_confirmed_rows": len(previous),
        "new_candidate_rows": len(cases),
        "final_gold_ready": False,
        "source_policy": "synthetic_only; no external public cases were imported",
        "counts_by_risk_category": dict(sorted(counts.items())),
        "counts_by_annotation_state": dict(sorted(states.items())),
        "bundle_documents": manifest_rows,
        "next_action": "Human review and adjudication are required before pending rows can be designated final gold.",
        "limitations": [
            "Synthetic clauses test retrieval and evidence boundaries; they are not real project records.",
            "Legal basis comes from the current local corpus, but version, force and applicability still require human verification.",
            "The 3 previously accepted rows remain separate from the 57 new pending candidates.",
        ],
    }
    (OUT_LABELS / "contract_review_gold_pool_manifest_v1.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
