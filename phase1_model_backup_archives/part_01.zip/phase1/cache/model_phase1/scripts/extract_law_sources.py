"""Extract supported law-source files into article-level JSONL blocks.

This is a deterministic preparation step only. It does not call an LLM or
perform legal interpretation. Unsupported legacy .doc files are recorded as
UNSUPPORTED rather than guessed.
"""

from __future__ import annotations

import hashlib
import json
import re
import zipfile
from datetime import date
from pathlib import Path
from xml.etree import ElementTree as ET

import fitz
from docx import Document
from lxml import html


ROOT = Path(r"E:\申博材料\Davood Shojaei\cache\model_phase1\law_sources")
OUT = Path(r"E:\申博材料\Davood Shojaei\cache\model_phase1\law_extracted")
OUT.mkdir(parents=True, exist_ok=True)

ARTICLE_RE = re.compile(
    r"(?m)^\s*(?:\[[^\]]+\]\s*)?(第[一二三四五六七八九十百千万零〇0-9]+条)"
)
CLAUSE_RE = re.compile(r"(?m)^\s*(?:\[[^\]]+\]\s*)?(\d+(?:\.\d+)+)(?:\s+)")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def level_for(path: Path) -> tuple[str, str]:
    text = str(path.parent)
    if path.name.startswith("law_prc_tendering_bidding_2017_revision"):
        return "Level 1", "law"
    if "Level 1" in text:
        return "Level 1", "law"
    if "Level 2" in text:
        return "Level 2", "administrative_regulation"
    if "Level 3" in text:
        if path.name.startswith("GB_T"):
            return "S2", "standard_application_handbook"
        if path.name.startswith("技术规范发布稿"):
            return "Level 3", "technical_specification_supplement"
        return "Level 3", "departmental_regulation"
    if "Level 4" in text:
        return "Level 4", "local_regulation_or_standard"
    return "unassigned", "unknown"


def title_for(path: Path) -> str:
    return path.stem.replace("_", " ").strip()


def role_for(path: Path) -> tuple[str, str | None]:
    """Return retrieval role and optional parent source title.

    The role is deliberately separate from normative_type: a technical
    specification may support an electronic-tendering rule without carrying
    the same evidentiary weight as the rule itself.
    """
    if path.name.startswith("技术规范发布稿"):
        return "supplementary_document", "电子招标投标办法"
    if path.name.startswith("GB_T50500"):
        return "practice_material_only", "GB/T 50500—2024 官方标准文本（未提供/未核验）"
    if path.name.startswith("law_prc_tendering_bidding"):
        return "verification_copy", "中华人民共和国招标投标法"
    if path.suffix.lower() == ".doc":
        return "superseded_legacy_duplicate", None
    return "primary_candidate", None


def read_docx(path: Path) -> tuple[str, str]:
    doc = Document(str(path))
    blocks: list[str] = []
    for idx, paragraph in enumerate(doc.paragraphs, start=1):
        text = " ".join(paragraph.text.split())
        if text:
            blocks.append(f"[paragraph {idx}] {text}")
    for tidx, table in enumerate(doc.tables, start=1):
        rows = []
        for row in table.rows:
            rows.append(" | ".join(" ".join(cell.text.split()) for cell in row.cells))
        if rows:
            blocks.append(f"[table {tidx}]\n" + "\n".join(rows))
    return "\n".join(blocks), "docx"


def read_pdf(path: Path) -> tuple[str, str]:
    pages = []
    with fitz.open(str(path)) as pdf:
        for page_no, page in enumerate(pdf, start=1):
            text = "\n".join(" ".join(line.split()) for line in page.get_text("text").splitlines() if line.strip())
            if text:
                pages.append(f"[page {page_no}]\n{text}")
    return "\n".join(pages), "pdf_text"


def read_html(path: Path) -> tuple[str, str]:
    root = html.fromstring(path.read_bytes())
    for bad in root.xpath("//script|//style|//noscript"):
        bad.getparent().remove(bad)
    text = "\n".join(" ".join(line.split()) for line in root.text_content().splitlines() if line.strip())
    return text, "html_text"


def read_odt(path: Path) -> tuple[str, str]:
    """Read paragraph and table text from an OpenDocument text file."""
    namespaces = {
        "text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
        "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
    }
    with zipfile.ZipFile(path) as archive:
        root = ET.fromstring(archive.read("content.xml"))
    blocks: list[str] = []
    for element in root.iter():
        if element.tag == f"{{{namespaces['text']}}}p":
            text = " ".join("".join(element.itertext()).split())
            if text:
                blocks.append(text)
        elif element.tag == f"{{{namespaces['table']}}}table-row":
            cells = []
            for cell in element.findall("table:table-cell", namespaces):
                cell_text = " ".join("".join(cell.itertext()).split())
                if cell_text:
                    cells.append(cell_text)
            if cells:
                blocks.append(" | ".join(cells))
    return "\n".join(blocks), "odt_text"


def article_blocks(text: str) -> list[tuple[str, str]]:
    matches = list(ARTICLE_RE.finditer(text))
    if not matches:
        clause_matches = list(CLAUSE_RE.finditer(text))
        if clause_matches:
            blocks = []
            for idx, match in enumerate(clause_matches):
                end = clause_matches[idx + 1].start() if idx + 1 < len(clause_matches) else len(text)
                blocks.append((match.group(1), text[match.start() : end].strip()))
            return blocks
        return [("unsegmented", text.strip())] if text.strip() else []
    blocks = []
    prefix = text[: matches[0].start()].strip()
    if prefix:
        blocks.append(("preamble", prefix))
    for idx, match in enumerate(matches):
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(text)
        blocks.append((match.group(1), text[match.start() : end].strip()))
    return blocks


def main() -> None:
    manifest_path = OUT / "extraction_manifest.jsonl"
    # Rebuild derived extraction outputs so renamed/replaced source files do
    # not leave stale JSONL blocks that could accidentally enter the index.
    for old_output in OUT.glob("*.jsonl"):
        old_output.unlink()
    candidates = sorted(
        p for p in ROOT.rglob("*")
        if p.is_file() and p.suffix.lower() in {".docx", ".doc", ".pdf", ".html", ".odt"}
        and "law_extracted" not in p.parts
    )
    with manifest_path.open("w", encoding="utf-8") as manifest:
        for path in candidates:
            level, normative_type = level_for(path)
            source_role, parent_source_title = role_for(path)
            source_id = hashlib.sha1(str(path).encode("utf-8")).hexdigest()[:12]
            base = {
                "source_id": source_id,
                "title": title_for(path),
                "local_file": str(path),
                "normative_level": level,
                "normative_type": normative_type,
                "source_role": source_role,
                "parent_source_title": parent_source_title,
                "file_hash": sha256(path),
                "extraction_date": str(date.today()),
            }
            ext = path.suffix.lower()
            if ext == ".doc":
                base.update({
                    "status": "UNSUPPORTED_LEGACY_DOC",
                    "extraction_method": None,
                    "output_file": None,
                    "article_count": 0,
                    "character_count": 0,
                    "note": "Legacy .doc conversion dependency unavailable; no text guessed.",
                })
                manifest.write(json.dumps(base, ensure_ascii=False) + "\n")
                continue
            try:
                if ext == ".docx":
                    text, method = read_docx(path)
                elif ext == ".pdf":
                    text, method = read_pdf(path)
                elif ext == ".html":
                    text, method = read_html(path)
                else:
                    text, method = read_odt(path)
                blocks = article_blocks(text)
                extraction_status = "EXTRACTED"
                if len(blocks) == 1 and blocks[0][0] == "unsegmented":
                    extraction_status = "EXTRACTED_UNSEGMENTED"
                base.update({
                    "status": extraction_status,
                    "extraction_method": method,
                    "output_file": str(OUT / f"{source_id}.jsonl"),
                    "article_count": len(blocks),
                    "character_count": len(text),
                    "note": "Article segmentation is mechanical; legal applicability remains unverified.",
                })
                output = Path(base["output_file"])
                with output.open("w", encoding="utf-8") as fh:
                    for article, block_text in blocks:
                        record = {
                            **base,
                            "article": article,
                            "text": block_text,
                            "source_locator": article,
                        }
                        fh.write(json.dumps(record, ensure_ascii=False) + "\n")
            except Exception as exc:  # record failure; do not silently skip
                base.update({
                    "status": "EXTRACTION_ERROR",
                    "extraction_method": None,
                    "output_file": None,
                    "article_count": 0,
                    "character_count": 0,
                    "note": f"{type(exc).__name__}: {exc}",
                })
            manifest.write(json.dumps(base, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
