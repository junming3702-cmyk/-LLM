"""Promote the approved adjudicated issue pool to final synthetic gold.

This promotion records the user's approval as the finalization event while
preserving the candidate and adjudicated files as an audit trail.
"""

from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import date
from pathlib import Path


ROOT = Path(r"E:\申博材料\Davood Shojaei\cache\model_phase1")
INPUT = ROOT / "labels" / "contract_review_gold_adjudicated_v1.jsonl"
OUT = ROOT / "labels"


def main() -> None:
    rows = [json.loads(line) for line in INPUT.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(rows) != 60:
        raise AssertionError(f"Expected 60 adjudicated rows, got {len(rows)}")
    for row in rows:
        if row.get("annotation_state") not in {"human_confirmed_synthetic_v1", "agent_reviewed_pending_user_approval"}:
            raise ValueError(f"Unexpected annotation state for {row['issue_id']}: {row.get('annotation_state')}")
        row["annotation_state"] = "human_confirmed_synthetic_v1"
        row["gold_status"] = "final_synthetic_gold"
        row["confirmation_source"] = "user_approved_current_phase"
        row["confirmation_date"] = str(date.today())
        row["final_gold_note"] = "Promoted after user approval; retain evidence boundary and insufficient-information labels."

    jsonl_path = OUT / "contract_review_final_synthetic_gold_v1.jsonl"
    jsonl_path.write_text("\n".join(json.dumps(row, ensure_ascii=False) for row in rows) + "\n", encoding="utf-8")
    fields = sorted({key for row in rows for key in row})
    with (OUT / "contract_review_final_synthetic_gold_v1.csv").open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value, ensure_ascii=False) if isinstance(value, list) else value for key, value in row.items()})

    manifest = {
        "dataset_version": "contract_review_final_synthetic_gold_v1",
        "promoted_date": str(date.today()),
        "status": "final_synthetic_gold_for_retrieval_experiments",
        "rows": len(rows),
        "confirmation_source": "user_approved_current_phase",
        "source_audit_chain": {
            "candidate_pool": str(OUT / "contract_review_gold_pool_v1.jsonl"),
            "adjudicated_pool": str(INPUT),
            "final_jsonl": str(jsonl_path),
        },
        "risk_category_counts": dict(sorted(Counter(row["risk_category"] for row in rows).items())),
        "human_review_status_counts": dict(sorted(Counter(row["human_review_status"] for row in rows).items())),
        "evidence_boundary_counts": dict(sorted(Counter(row["evidence_boundary"] for row in rows).items())),
        "limitations": [
            "This is a final synthetic gold set for retrieval experiments, not a real procurement case dataset.",
            "Insufficient-information and abstention cases remain intentionally in the gold set.",
            "No embedding, LLM or external retrieval has been run against this promoted set yet.",
        ],
        "next_stage": "embedding/hybrid retrieval comparison, subject to separate stage approval",
    }
    (OUT / "contract_review_final_synthetic_gold_manifest_v1.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    report = [
        "# Final synthetic gold set v1",
        "",
        "The 60-row adjudicated issue pool has been promoted after explicit user approval on 2026-08-23.",
        "",
        "- Status: `final_synthetic_gold_for_retrieval_experiments`",
        "- Records: 60",
        "- Confirmation source: `user_approved_current_phase`",
        "- Audit chain preserved: candidate pool → adjudicated pool → final gold",
        "",
        "This promotion does not authorize embedding, LLM or external retrieval. Those remain the next separately reviewable phase.",
    ]
    (OUT / "contract_review_final_synthetic_gold_report_v1.md").write_text("\n".join(report) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
