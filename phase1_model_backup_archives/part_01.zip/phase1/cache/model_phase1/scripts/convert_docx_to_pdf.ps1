param(
    [Parameter(Mandatory = $true)]
    [string]$InputPath,
    [Parameter(Mandatory = $true)]
    [string]$OutputPath
)

$resolvedInput = (Resolve-Path -LiteralPath $InputPath).Path
$outputParent = Split-Path -Parent $OutputPath
if (-not (Test-Path -LiteralPath $outputParent)) {
    New-Item -ItemType Directory -Path $outputParent -Force | Out-Null
}
$resolvedOutput = [System.IO.Path]::GetFullPath($OutputPath)

$word = $null
$document = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $document = $word.Documents.Open($resolvedInput, $false, $true)
    # 17 = wdExportFormatPDF. The source DOCX is opened read-only and is not modified.
    $document.ExportAsFixedFormat($resolvedOutput, 17)
    $document.Close($false)
    $document = $null
    $word.Quit()
    $word = $null
    Get-Item -LiteralPath $resolvedOutput | Select-Object FullName, Length
}
finally {
    if ($document -ne $null) {
        $document.Close($false)
        [System.Runtime.InteropServices.Marshal]::ReleaseComObject($document) | Out-Null
    }
    if ($word -ne $null) {
        $word.Quit()
        [System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}

