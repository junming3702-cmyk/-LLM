#!/usr/bin/env python
"""Render selected pages of a derived PDF for visual QA."""

from __future__ import annotations

import argparse
from pathlib import Path

import pypdfium2 as pdfium


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    parser.add_argument("--pages", default="1,80,165")
    parser.add_argument("--scale", type=float, default=1.5)
    args = parser.parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)
    pdf = pdfium.PdfDocument(str(args.input))
    rendered = []
    for page_number in [int(item) for item in args.pages.split(",") if item.strip()]:
        page = pdf[page_number - 1]
        bitmap = page.render(scale=args.scale)
        path = args.output_root / f"page-{page_number:04d}.png"
        bitmap.to_pil().save(path)
        rendered.append(str(path))
    print("\n".join(rendered))


if __name__ == "__main__":
    main()
