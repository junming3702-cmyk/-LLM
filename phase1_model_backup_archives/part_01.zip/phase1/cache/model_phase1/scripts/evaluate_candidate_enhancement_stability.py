#!/usr/bin/env python
"""Score the approved six-sample candidate-enhancement stability experiment."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from pypdf import PdfReader

from mineru_source_locator_adapter import critical_tokens, normalize_text


OCR_EXPECTED_TOKENS = {
    2: [],
    5: ["GB/T 50500—2024", "湖北省", "5个多月", "24版"],
    320: ["GB/T 50500—2024"],
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def token_in_text(token: str, text: str) -> bool:
    return normalize_text(token) in normalize_text(text)


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def evaluate_ocr(quality_path: Path, locator_path: Path, source_path: Path) -> dict[str, Any]:
    quality = load_json(quality_path)
    rows = [json.loads(line) for line in locator_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    by_page: dict[int, list[dict[str, Any]]] = {}
    for row in rows:
        by_page.setdefault(int(row["page_number"]), []).append(row)
    page_results: list[dict[str, Any]] = []
    for page in quality["pages"]:
        page_number = int(page["page_number"])
        text = "\n".join(row["text"] for row in by_page.get(page_number, []))
        expected = OCR_EXPECTED_TOKENS.get(page_number, [])
        matched = [token for token in expected if token_in_text(token, text)]
        coordinates_complete = all(row.get("pixel_polygon") and row.get("pdf_polygon_top_left") for row in by_page.get(page_number, []))
        page_results.append({
            "page_number": page_number,
            "detected_textline_count": page["detected_textline_count"],
            "text_chars": page["text_chars"],
            "coordinate_coverage": page["coordinate_coverage"],
            "coordinates_complete": coordinates_complete,
            "expected_smoke_tokens": expected,
            "matched_smoke_tokens": matched,
            "critical_token_recall": round(len(matched) / len(expected), 4) if expected else None,
            "blank_page_preserved": page["text_chars"] == 0 if not expected else None,
            "quality_status": page["quality_status"],
        })
    nonempty = [row for row in page_results if row["text_chars"] > 0]
    token_scored = [row for row in page_results if row["critical_token_recall"] is not None]
    return {
        "source_file": str(source_path),
        "source_sha256": sha256_file(source_path),
        "pages": page_results,
        "nonempty_page_count": len(nonempty),
        "minimum_nonempty_coordinate_coverage": min((row["coordinate_coverage"] for row in nonempty), default=0.0),
        "all_nonempty_coordinates_complete": all(row["coordinates_complete"] for row in nonempty),
        "scored_critical_token_recall": round(sum(row["critical_token_recall"] for row in token_scored) / len(token_scored), 4) if token_scored else None,
        "blank_page_false_recovery_check": next((row["blank_page_preserved"] for row in page_results if row["page_number"] == 2), None),
        "quality_status": "needs_human_review",
        "human_confirmation": "pending",
    }


def evaluate_mineru(gate_path: Path, formatted_pdf: Path, split_manifest_path: Path) -> dict[str, Any]:
    gate = load_json(gate_path)
    split_manifest = load_json(split_manifest_path)
    reader = PdfReader(str(formatted_pdf))
    chunk_results: list[dict[str, Any]] = []
    for row in gate["chunk_reports"]:
        start, end = int(row["original_page_start"]), int(row["original_page_end"])
        mineru_text = Path(str(row["mineru_markdown"])).read_text(encoding="utf-8")
        source_text = "\n".join((reader.pages[index - 1].extract_text() or "") for index in range(start, end + 1))
        source_tokens = sorted(critical_tokens(source_text))
        matched = [token for token in source_tokens if token_in_text(token, mineru_text)]
        chunk_results.append({
            "chunk_name": row["chunk_name"],
            "original_page_range": f"{start}-{end}",
            "text_block_count": row["text_block_count"],
            "backmatch_coverage": row["backmatch_coverage"],
            "linked_coverage": row["linked_coverage"],
            "mapping_method_counts": row["mapping_method_counts"],
            "blocked_block_count": row["blocked_block_count"],
            "source_critical_token_count": len(source_tokens),
            "source_critical_tokens": source_tokens,
            "matched_critical_tokens": matched,
            "critical_token_recall": round(len(matched) / len(source_tokens), 4) if source_tokens else None,
            "quality_status": row["quality_status"],
        })
    log_path = Path(str(gate["blocked_block_log_path"]))
    log_rows = [json.loads(line) for line in log_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    reason_complete = sum(bool(row.get("gate_block_reason")) for row in log_rows) / len(log_rows) if log_rows else 1.0
    identity_ok = gate["original_source_sha256"] == split_manifest["source_sha256"] and Path(gate["baseline_locator_map"]).exists()
    scored = [row for row in chunk_results if row["critical_token_recall"] is not None]
    return {
        "source_file": split_manifest["source_file"],
        "source_sha256": split_manifest["source_sha256"],
        "chunks": chunk_results,
        "minimum_backmatch_coverage": min((row["backmatch_coverage"] for row in chunk_results), default=0.0),
        "all_selected_chunks_meet_auto_threshold": all(row["backmatch_coverage"] >= 0.8 for row in chunk_results),
        "scored_critical_token_recall": round(sum(row["critical_token_recall"] for row in scored) / len(scored), 4) if scored else None,
        "blocked_reason_completeness": round(reason_complete, 4),
        "source_identity_preservation": identity_ok,
        "quality_status": "needs_human_review",
    }


def render_markdown(result: dict[str, Any]) -> str:
    ocr = result["ocr"]
    mineru = result["mineru"]
    lines = [
        "# Candidate enhancement stability experiment — result",
        "",
        "**Status:** completed; no embedding, LLM, RAG write or external fallback was executed.",
        "",
        "## A. PaddleOCR coordinate OCR",
        "",
        "| Page | Text lines | Chars | Coordinate coverage | Smoke-token recall | Blank preserved |",
        "|---:|---:|---:|---:|---:|---:|",
    ]
    for row in ocr["pages"]:
        recall = "—" if row["critical_token_recall"] is None else f"{row['critical_token_recall']:.1%}"
        blank = "—" if row["blank_page_preserved"] is None else ("PASS" if row["blank_page_preserved"] else "FAIL")
        lines.append(f"| {row['page_number']} | {row['detected_textline_count']} | {row['text_chars']} | {row['coordinate_coverage']:.1%} | {recall} | {blank} |")
    lines.extend([
        "",
        f"- Minimum non-empty-page coordinate coverage: **{ocr['minimum_nonempty_coordinate_coverage']:.1%}**",
        f"- All non-empty lines have coordinates: **{ocr['all_nonempty_coordinates_complete']}**",
        f"- Scored smoke-token recall: **{ocr['scored_critical_token_recall']:.1%}**",
        f"- Blank page false-recovery check: **{'PASS' if ocr['blank_page_false_recovery_check'] else 'FAIL'}**",
        "- Human confirmation: **pending**; the smoke-token set is an analyst-curated technical check, not a legal adjudication.",
        "",
        "## B. DOCX → formatted PDF → MinerU API",
        "",
        "| Chunk | Original pages | Blocks | Backmatch | Blocked | Critical-token recall |",
        "|---|---:|---:|---:|---:|---:|",
    ])
    for row in mineru["chunks"]:
        recall = "—" if row["critical_token_recall"] is None else f"{row['critical_token_recall']:.1%}"
        lines.append(f"| {row['chunk_name']} | {row['original_page_range']} | {row['text_block_count']} | {row['backmatch_coverage']:.1%} | {row['blocked_block_count']} | {recall} |")
    lines.extend([
        "",
        f"- Minimum selected-chunk backmatch: **{mineru['minimum_backmatch_coverage']:.1%}**",
        f"- All selected chunks meet 80% threshold: **{mineru['all_selected_chunks_meet_auto_threshold']}**",
        f"- Scored critical-token recall against formatted-PDF text: **{(mineru['scored_critical_token_recall'] or 0):.1%}**",
        f"- Blocked-reason completeness: **{mineru['blocked_reason_completeness']:.1%}**",
        f"- Source-identity preservation: **{mineru['source_identity_preservation']}**",
        "",
        "## Gate decision",
        "",
        "Both branches remain candidate enhancements. PaddleOCR passes the coordinate/blank-page smoke checks but remains human-review gated. The selected MinerU chunks include 65% and 60% backmatch cases, so the branch remains `needs_human_review` and cannot be promoted to RAG.",
    ])
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ocr-quality", required=True, type=Path)
    parser.add_argument("--ocr-locator", required=True, type=Path)
    parser.add_argument("--ocr-source", required=True, type=Path)
    parser.add_argument("--mineru-gate", required=True, type=Path)
    parser.add_argument("--formatted-pdf", required=True, type=Path)
    parser.add_argument("--split-manifest", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    args = parser.parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)
    result = {
        "experiment_id": "CANDIDATE-ENHANCEMENT-STABILITY-20260824-001",
        "scope": "approved six-sample Scheme A",
        "ocr": evaluate_ocr(args.ocr_quality, args.ocr_locator, args.ocr_source),
        "mineru": evaluate_mineru(args.mineru_gate, args.formatted_pdf, args.split_manifest),
        "overall_status": "needs_human_review",
        "rag_write": False,
        "llm_reasoning": False,
    }
    (args.output_root / "candidate_enhancement_stability_result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    (args.output_root / "candidate_enhancement_stability_report.md").write_text(render_markdown(result), encoding="utf-8")
    print(json.dumps({"result": str(args.output_root / 'candidate_enhancement_stability_result.json'), "report": str(args.output_root / 'candidate_enhancement_stability_report.md')}, ensure_ascii=False))


if __name__ == "__main__":
    main()
