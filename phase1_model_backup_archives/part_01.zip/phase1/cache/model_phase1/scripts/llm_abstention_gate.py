"""Deterministic post-LLM schema and abstention gate.

The gate is deliberately independent of the language model. It canonicalizes
evidence metadata from the runtime retrieval package, rejects citations that
were not supplied to the model, and forces an insufficient-information or
human-review outcome when decisive legal elements are missing.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any


DECISIVE_FIELDS = (
    "subject",
    "conduct_or_condition",
    "jurisdiction_and_scope",
    "legal_consequence",
)
MISSING_STATES = {"missing", "conflicting", "unknown", ""}


def _set_field(target: dict, key: str, value: Any, actions: list[str], path: str) -> None:
    if target.get(key) != value:
        target[key] = value
        actions.append(f"corrected {path}.{key}")


def _minimal_response(runtime_input: dict, reason: str) -> dict:
    return {
        "run_id": runtime_input.get("run_id", ""),
        "project_id": runtime_input.get("project_id", ""),
        "review_scope": runtime_input.get("review_scope", {}),
        "findings": [],
        "project_summary": {
            "findings_count": 0,
            "high_priority_review_items": [],
            "evidence_gaps": [reason],
            "not_assessed": [],
            "supplement_candidate_pool_dependencies": [],
            "statement_boundary": "本结果仅辅助人工审查，不是最终法律结论",
        },
        "retrieval_audit": {
            "local_sources_used": [],
            "external_sources_used": [],
            "queries": [],
            "model_and_parameters": {},
            "high_trust_candidates_used": [],
            "supplement_candidate_pool_searched": False,
            "supplement_candidate_pool_used": False,
            "supplement_candidate_pool_use_reason": "",
            "supplement_candidate_pool_dependency": False,
            "unresolved_conflicts": [],
            "external_retrieval_called": False,
        },
    }


def _canonicalize_evidence(finding: dict, runtime_input: dict, actions: list[str]) -> tuple[list[dict], bool, bool]:
    supplied = {
        row.get("chunk_id"): row
        for row in runtime_input.get("retrieved_legal_evidence", [])
        if row.get("chunk_id")
    }
    raw_evidence = finding.get("legal_evidence")
    if not isinstance(raw_evidence, list):
        raw_evidence = []

    canonical: list[dict] = []
    invalid = False
    for index, evidence in enumerate(raw_evidence):
        if not isinstance(evidence, dict):
            invalid = True
            actions.append(f"rejected legal_evidence[{index}] because it is not an object")
            continue
        chunk_id = evidence.get("chunk_id")
        source = supplied.get(chunk_id)
        if source is None:
            invalid = True
            actions.append(f"rejected legal_evidence[{index}] because chunk_id was not in runtime retrieval")
            continue

        item = deepcopy(evidence)
        authoritative_fields = (
            "law",
            "article",
            "source_locator",
            "normative_level",
            "normative_type",
            "source_role",
            "parent_source_title",
            "corpus_partition",
            "evidence_weight",
            "requires_human_review",
            "citation_ready",
            "independent_legal_evidence",
            "legal_evidence_eligibility",
            "citation_mode",
            "jurisdiction_note",
        )
        for field in authoritative_fields:
            value = source.get(field)
            if value is None and field == "independent_legal_evidence":
                value = not (
                    source.get("legal_evidence_eligibility") == "supplement_only"
                    or source.get("source_role") == "practice_material_only"
                )
            elif value is None and field == "legal_evidence_eligibility":
                value = (
                    "supplement_only"
                    if source.get("source_role") == "practice_material_only"
                    else "independent_candidate"
                )
            elif value is None and field == "citation_mode":
                value = (
                    "contextual_only"
                    if source.get("source_role") == "practice_material_only"
                    else "verbatim_source_citation"
                )
            if value is not None:
                _set_field(item, field, value, actions, f"legal_evidence[{index}]")
        _set_field(item, "legal_quote", source.get("legal_quote", ""), actions, f"legal_evidence[{index}]")

        if not item.get("source_locator") or not item.get("legal_quote"):
            invalid = True
            actions.append(f"rejected legal_evidence[{index}] because locator or quote is empty")
            continue
        canonical.append(item)

    finding["legal_evidence"] = canonical
    only_supplementary = bool(canonical) and all(
        item.get("independent_legal_evidence") is False
        or item.get("legal_evidence_eligibility") == "supplement_only"
        or item.get("source_role") == "practice_material_only"
        for item in canonical
    )
    return canonical, invalid, only_supplementary


def apply_gate(raw_response: Any, runtime_input: dict) -> dict:
    """Return raw-preserving gate result with a safe final response."""

    actions: list[str] = []
    if not isinstance(raw_response, dict):
        reason = "LLM response was not a JSON object"
        return {
            "status": "blocked",
            "blocked": True,
            "actions": [reason],
            "response": _minimal_response(runtime_input, reason),
        }

    response = deepcopy(raw_response)
    _set_field(response, "run_id", runtime_input.get("run_id", ""), actions, "root")
    _set_field(response, "project_id", runtime_input.get("project_id", ""), actions, "root")
    if not isinstance(response.get("findings"), list):
        reason = "LLM response findings is not a list"
        return {
            "status": "blocked",
            "blocked": True,
            "actions": actions + [reason],
            "response": _minimal_response(runtime_input, reason),
        }

    runtime_scope = runtime_input.get("review_scope", {})
    if not isinstance(response.get("review_scope"), dict):
        response["review_scope"] = deepcopy(runtime_scope)
        actions.append("corrected root.review_scope")
    if runtime_scope.get("jurisdiction_status") != "confirmed":
        _set_field(response["review_scope"], "jurisdiction_status", runtime_scope.get("jurisdiction_status", "uncertain"), actions, "review_scope")

    for index, finding in enumerate(response["findings"]):
        path = f"findings[{index}]"
        if not isinstance(finding, dict):
            response["findings"][index] = {
                "finding_id": f"GATE-{index + 1:03d}",
                "conclusion_type": "insufficient_information",
                "confidence_assessment": "insufficient_information",
                "human_review_status": "review_required",
                "reasoning_conclusion": "依据当前材料无法得出确切结论：finding 不是 JSON object。",
            }
            actions.append(f"replaced {path} with safe insufficient-information finding")
            continue

        contract = runtime_input.get("contract_evidence", {})
        for field in ("document_id", "document_location", "document_excerpt"):
            if contract.get(field):
                _set_field(finding, field, contract[field], actions, path)

        coverage = finding.get("legal_element_coverage")
        if not isinstance(coverage, dict):
            coverage = {}
            finding["legal_element_coverage"] = coverage
            actions.append(f"created {path}.legal_element_coverage")
        missing_fields = [field for field in DECISIVE_FIELDS if coverage.get(field) in MISSING_STATES or field not in coverage]
        if runtime_scope.get("jurisdiction_status") != "confirmed" and "jurisdiction_and_scope" not in missing_fields:
            missing_fields.append("jurisdiction_and_scope")
            _set_field(coverage, "jurisdiction_and_scope", "missing", actions, f"{path}.legal_element_coverage")

        evidence, invalid_evidence, only_supplementary = _canonicalize_evidence(finding, runtime_input, actions)
        force_insufficient = bool(missing_fields) or not evidence or invalid_evidence
        old_conclusion = finding.get("reasoning_conclusion", "")
        if force_insufficient:
            if old_conclusion and "gate_original_conclusion" not in finding:
                finding["gate_original_conclusion"] = old_conclusion
            reason_parts = []
            if missing_fields:
                reason_parts.append("缺少决定性法律要件：" + "、".join(missing_fields))
            if not evidence:
                reason_parts.append("没有可用且可定位的运行时法规证据")
            if invalid_evidence:
                reason_parts.append("部分法规引用未通过运行时证据回配")
            reason = "；".join(reason_parts)
            _set_field(finding, "conclusion_type", "insufficient_information", actions, path)
            _set_field(finding, "confidence_assessment", "insufficient_information", actions, path)
            _set_field(finding, "human_review_status", "review_required", actions, path)
            _set_field(finding, "evidence_boundary", "supported_by_supplementary_source_only" if only_supplementary else "requires_human_legal_review", actions, path)
            _set_field(finding, "reasoning_conclusion", f"依据当前材料无法得出确切结论。{reason}。", actions, path)
            if not finding.get("recommended_human_action"):
                _set_field(finding, "recommended_human_action", "补充项目所在地、项目类型和适用法规版本，并提交专业人员复核。", actions, path)
        elif only_supplementary:
            _set_field(finding, "conclusion_type", "requires_human_legal_review", actions, path)
            _set_field(finding, "confidence_assessment", "low", actions, path)
            _set_field(finding, "human_review_status", "review_required", actions, path)
            _set_field(finding, "evidence_boundary", "supported_by_supplementary_source_only", actions, path)

    summary = response.get("project_summary")
    if not isinstance(summary, dict):
        summary = {}
        response["project_summary"] = summary
        actions.append("created root.project_summary")
    _set_field(summary, "findings_count", len(response["findings"]), actions, "project_summary")
    _set_field(summary, "statement_boundary", "本结果仅辅助人工审查，不是最终法律结论", actions, "project_summary")

    audit = response.get("retrieval_audit")
    if not isinstance(audit, dict):
        audit = {}
        response["retrieval_audit"] = audit
        actions.append("created root.retrieval_audit")
    if runtime_input.get("runtime_constraints", {}).get("external_retrieval_called") is False:
        _set_field(audit, "external_sources_used", [], actions, "retrieval_audit")
        _set_field(audit, "external_retrieval_called", False, actions, "retrieval_audit")

    return {
        "status": "corrected" if actions else "passed",
        "blocked": False,
        "actions": actions,
        "response": response,
    }
