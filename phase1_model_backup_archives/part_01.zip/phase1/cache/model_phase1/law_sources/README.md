# Model Phase 1｜Law sources

本目录按四层法规/规范知识库组织：

1. `Level 1 （law）`：法律，包括《中华人民共和国招标投标法》《中华人民共和国建筑法》；
2. `Level 2`：行政法规，包括《中华人民共和国招标投标法实施条例》；
3. `Level 3 (Departmental Regulations)`：部门规章及经核验后纳入的国家级规范/标准；
4. `Level 4 (Local regulations and standard documents)`：地方性法规、地方规章和地方标准文件，依据工程所在地动态筛选。

目录层级不等于最终法律效力结论。每个文件仍需在 registry 中记录 `normative_level`、`normative_type`、制定机关、版本、效力状态、来源 URL、文件哈希和抽取状态。

外部检索来源与四层法规知识库分开登记：国家法律法规数据库用于版本、效力和条款核验；建设造价信息网站仅在来源身份、访问稳定性和内容性质核验后作为可选外部资料源，不自动视为法律依据。
