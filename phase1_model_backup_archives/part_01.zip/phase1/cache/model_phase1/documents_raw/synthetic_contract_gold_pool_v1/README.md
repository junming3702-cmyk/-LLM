# Synthetic contract gold candidate pool v1

This directory contains 57 synthetic partial contract-document samples generated for human confirmation. They are not real tenders, contracts or legal cases, and no external public case was imported.

Each document is linked to one or more issue-level rows in `cache/model_phase1/labels/contract_review_gold_pool_v1.jsonl`. File hashes are recorded in `sample_manifest.csv`. The corresponding rows remain `pending_human_confirmation` until a human reviewer confirms or revises the excerpt, risk category, legal basis, evidence boundary and recommended action.
