# Model Phase 1｜Raw contract documents

保存原始项目合同文件或经过明确授权的匿名化副本。不得把未经授权的私人合同文件上传到外部模型或外部服务。

每个项目使用匿名 `project_id`，文件名不得直接暴露项目名称、客户、地址或个人信息。原始文件登记在 `document_manifest.csv`，并保留文件哈希。
