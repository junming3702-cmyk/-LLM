# Synthetic contract bundle v1

This is a deliberately synthetic, non-confidential test bundle for the Phase 1 text-only RAG MVP. It is not an actual tender, contract or legal opinion. The clauses are designed to test evidence location, a clear article-level mismatch, and a missing cross-document reference.

- `01_synthetic_tender_document.txt`: synthetic tender-document clauses.
- `02_synthetic_appendix_register.txt`: synthetic appendix register with a deliberately missing attachment reference.
- Bundle ID: `SYN-P1-001`.
