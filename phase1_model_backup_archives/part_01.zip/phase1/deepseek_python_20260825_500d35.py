import os
from dotenv import load_dotenv
import requests

# 加载 .env 文件中的环境变量
load_dotenv()

# 从环境变量中读取 API Key
API_KEY = os.getenv("DEEPSEEK_API_KEY")

if not API_KEY:
    raise ValueError("环境变量 DEEPSEEK_API_KEY 未设置，请检查 .env 文件。")

# 发起请求
response = requests.post(
    "https://api.deepseek.com/v1/chat/completions",
    headers={"Authorization": f"Bearer {API_KEY}"},  # 使用变量
    json={
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_input}
        ],
        "temperature": 0.1,
        "response_format": {"type": "json_object"}
    }
)