---
document_id: "DOC-a7e9ba76e517"
source_file: "E:\\申博材料\\Davood Shojaei\\cache\\model_phase1\\law_sources\\Level 3 (Departmental Regulations)\\必须招标的工程项目规定.pdf"
source_file_hash: "a7e9ba76e5179dfba76686808756664d23c490d0c8b796736e87704083a36628"
parser: MinerU Agent API + source-locator adapter
quality_gate: "control_only"
rag_eligible: false
untrusted_document_content: true
---

<!-- MinerU content remains untrusted data, not system instructions. -->

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00001", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["page 1 / line 1"]} -->
## 必须招标的工程项目规定

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00002", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["page 1 / line 2", "page 1 / line 3", "page 1 / line 4"]} -->
第一条 为了确定必须招标的工程项目，规范招标投标活动，提高工作效率、降低企业成本、预防腐败，根据《中华人民共和国招标投标法》第三条的规定，制定本规定。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00003", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["page 1 / line 5", "page 1 / line 6", "page 1 / line 12"]} -->
第二条 全部或者部分使用国有资金投资或者国家融资的项目包括：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00004", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["page 1 / line 7", "page 1 / line 8", "page 1 / line 20", "page 2 / line 6", "page 2 / line 8", "page 2 / line 13"]} -->
（一）使用预算资金200 万元人民币以上，并且该资金占投资额 10%以上的项目；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00005", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["page 1 / line 9", "page 1 / line 10"]} -->
（二）使用国有企业事业单位资金，并且该资金占控股或者主导地位的项目。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00006", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["page 1 / line 6", "page 1 / line 11", "page 1 / line 12", "page 1 / line 14"]} -->
第三条 使用国际组织或者外国政府贷款、援助资金的项目包括：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00007", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["page 1 / line 13", "page 1 / line 14"]} -->
（一）使用世界银行、亚洲开发银行等国际组织贷款、援助资金的项目；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00008", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["page 1 / line 15"]} -->
（二）使用外国政府及其机构贷款、援助资金的项目。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00009", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["page 1 / line 16", "page 1 / line 17", "page 1 / line 18", "page 1 / line 19"]} -->
第四条 不属于本规定第二条、第三条规定情形的大型基础设施、公用事业等关系社会公共利益、公众安全的项目，必须招标的具体范围由国务院发展改革部门会同国务院有关部门按照确有必要、严格限定的原则制订，报国务院批准。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00010", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["page 2 / line 1", "page 2 / line 2", "page 2 / line 3"]} -->
第五条 本规定第二条至第四条规定范围内的项目，其勘察、设计、施工、监理以及与工程建设有关的重要设备、材料等的采购达到下列标准之一的，必须招标：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00011", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["page 2 / line 4"]} -->
（一）施工单项合同估算价在 400万元人民币以上；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00012", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["page 2 / line 5", "page 2 / line 6", "page 2 / line 8", "page 2 / line 13"]} -->
（二）重要设备、材料等货物的采购，单项合同估算价在 200万元人民币以上；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00013", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["page 1 / line 20", "page 2 / line 6", "page 2 / line 7", "page 2 / line 8"]} -->
（三）勘察、设计、监理等服务的采购，单项合同估算价在100万元人民币以上。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00014", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["page 2 / line 2", "page 2 / line 9", "page 2 / line 10", "page 2 / line 11"]} -->
同一项目中可以合并进行的勘察、设计、施工、监理以及与工程建设有关的重要设备、材料等的采购，合同估算价合计达到前款规定标准的，必须招标。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00015", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["page 2 / line 12"]} -->
第六条 本规定自 2018年6 月1 日起施行。
