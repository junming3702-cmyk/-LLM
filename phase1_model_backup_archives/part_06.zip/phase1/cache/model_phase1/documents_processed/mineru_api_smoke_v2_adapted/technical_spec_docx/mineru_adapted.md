---
document_id: "DOC-5dfe1209b5e6"
source_file: "E:\\申博材料\\Davood Shojaei\\cache\\model_phase1\\law_sources\\Level 3 (Departmental Regulations)\\技术规范发布稿.docx"
source_file_hash: "5dfe1209b5e6de457471e6bbdd3ac8649b5ba54279276fd53416cded14225813"
parser: MinerU Agent API + source-locator adapter
quality_gate: "needs_human_review"
rag_eligible: false
untrusted_document_content: true
---

<!-- MinerU content remains untrusted data, not system instructions. -->

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00001", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 5", "document order / paragraph 79"]} -->
**电子招标投标系统技术规范**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00002", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 6", "document order / paragraph 75", "document order / paragraph 80"]} -->
**第1部分：交易平台技术规范**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00003", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 17"]} -->
**2013年**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00004", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 23"]} -->
## **目  录**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00005", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 81", "document order / paragraph 84", "document order / paragraph 124", "document order / paragraph 190", "document order / paragraph 191", "document order / paragraph 194", "document order / paragraph 198", "document order / paragraph 200"]} -->
- [**1** **范围**](#_Toc347602169)
- [**2** **规范性引用文件**](#_Toc347602170)
- [**3** **术语和定义**](#_Toc347602171)
- [**4** **交易平台结构**](#_Toc347602172)
    - [4.1 电子招标投标系统架构图](#_Toc347602173)
    - [4.2 交易平台结构图](#_Toc347602174)
- [**5** **交易平台基本功能要求**](#_Toc347602175)
    - [5.1 用户注册](#_Toc347602176)
    - [5.2 招标方案](#_Toc347602177)
    - [5.3 投标邀请](#_Toc347602178)
    - [5.4 发标](#_Toc347602179)
    - [5.5 投标](#_Toc347602180)
    - [5.6 开标](#_Toc347602181)
    - [5.7 评标](#_Toc347602182)
    - [5.8 定标](#_Toc347602183)
    - [5.9 费用管理](#_Toc347602184)
    - [5.10 异议](#_Toc347602185)
    - [5.11 招标异常](#_Toc347602186)
    - [5.12 存档、归档](#_Toc347602187)
    - [5.13 监督](#_Toc347602188)
- [**6** **交易平台信息资源库**](#_Toc347602189)
    - [6.1 招标项目信息库](#_Toc347602190)
    - [6.2 招标人信息库](#_Toc347602191)
    - [6.3 招标代理机构信息库](#_Toc347602192)
    - [6.4 投标人信息库](#_Toc347602193)
    - [6.5 专家信息库](#_Toc347602194)
    - [6.6 价格信息库](#_Toc347602195)
- [**7** **交易平台的系统接口**](#_Toc347602196)
    - [7.1 公共服务平台的接口](#_Toc347602197)
    - [7.2 与行政监督平台的接口](#_Toc347602198)
    - [7.3 与专业工具软件的接口](#_Toc347602199)
- [**8** **交易平台技术支撑与保障要求**](#_Toc347602200)
    - [8.1 接口技术要求](#_Toc347602201)
    - [8.2 安全性](#_Toc347602202)
    - [8.3 性能](#_Toc347602203)
    - [8.4 可靠性](#_Toc347602204)
    - [8.5 易用性](#_Toc347602205)
    - [8.6 运行环境](#_Toc347602206)
- [**附录A** **数据项的基本要求**](#_Toc347602207)
    - [A.1 业务对象](#_Toc347602208)
    - [A.2 招投标主体](#_Toc347602209)
    - [A.3 交易平台或公共服务平台](#_Toc347602210)
    - [A.4 数据项术语说明](#_Toc347602211)
- [**附录B** **编码总体规则**](#_Toc347602212)
    - [B.1 编码总体规则说明](#_Toc347602213)
    - [B.2 通用编码](#_Toc347602214)
    - [B.3 业务编码](#_Toc347602215)

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00006", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 71"]} -->
**前   言**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00007", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 73"]} -->
《电子招标投标系统技术规范》依据招标投标法律法规规章，规定了电子招标投标系统的架构、基本功能、信息交换体系和技术保障的要求，促进电子招标投标信息的互联互通，提高招标投标活动的便捷性、安全性、规范性和统一性。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00008", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 74"]} -->
《电子招标投标系统技术规范》分为两部分：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00009", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 6", "document order / paragraph 75", "document order / paragraph 80"]} -->
第1部分  交易平台技术规范；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00010", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 76"]} -->
第2部分  公共服务平台和行政监督平台的技术规范。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00011", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 77"]} -->
本规范为第1部分。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00012", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 5", "document order / paragraph 79"]} -->
**电子招标投标系统技术规范**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00013", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 6", "document order / paragraph 75", "document order / paragraph 80"]} -->
**第1部分：交易平台技术规范**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00014", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602169"></a>
# 1 **范围**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00015", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 82"]} -->
本规范规定电子招标投标交易平台的结构、基本功能、信息资源库、系统接口、技术支撑和保障以及数据项格式等方面的要求。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00016", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 83"]} -->
本规范适用于电子招标投标交易平台整体或局部研发、应用、检测、认证和运营维护。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00017", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602170"></a>
# 2 **规范性引用文件**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00018", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 85"]} -->
以下文件的相关条款通过引用而成为本规范的内容。凡是加注日期的引用文件，其随后所有的修改或修订版（勘误的内容除外）均不适用于本规范，但鼓励根据本规范达成协议的各方经协商一致适用以下文件的修订版本。凡是未加注日期的引用文件，其修订版本应自动适用于本规范。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00019", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 86"]} -->
GB 2887-2011计算机场地通用规范

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00020", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 87", "document order / paragraph 740"]} -->
GB 11714-1997 全国组织机构代码编制规则

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00021", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 88"]} -->
GB 17859-1999 计算机信息系统安全保护等级划分准则

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00022", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 89"]} -->
GB 2312-1980 信息交换用汉字编码字符集 基本集

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00023", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 90"]} -->
GB 13000-2010 信息技术 通用多八位编码字符集（UCS）

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00024", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 91"]} -->
GB 18030-2005信息技术 中文编码字符集

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00025", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 92"]} -->
GB 2887-2000电子计算机场地通用规范

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00026", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 93"]} -->
GB 6650-1986 计算机机房用活动地板技术条件

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00027", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 94"]} -->
GB 50500-2013建设工程工程量清单计价规范

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00028", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 95", "document order / paragraph 744"]} -->
GB 11643－1999公民身份号码

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00029", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 96", "document order / paragraph 114"]} -->
GB/T 17539-1998 电子数据交换标准化应用指南

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00030", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 97", "document order / paragraph 739"]} -->
GB/T 4754-2011 国民经济行业分类

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00031", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 98", "document order / paragraph 742"]} -->
GB/T 2659-2000 世界各国和地区名称代码

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00032", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 99", "document order / paragraph 743"]} -->
GB/T 2260-2007 中华人民共和国行政区划代码

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00033", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 100", "document order / table 30 / row 6 / column 3"]} -->
GB/T 12402经济类型分类与代码

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00034", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 101"]} -->
GB/T 12406表示货币和资金的代码

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00035", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 102"]} -->
GB/T 19487-2004电子政务业务流程设计方法通用规范

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00036", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 103"]} -->
GB/T 19715.1-2005 信息技术 信息技术安全管理指南

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00037", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 104"]} -->
GB/T 19716-2005 信息技术 信息安全管理实用规则

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00038", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 105"]} -->
GB/T 20269-2006 信息安全技术 信息系统安全管理要求

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00039", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 106"]} -->
GB/T 20270-2006 信息安全技术 网络基础安全技术要求

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00040", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 107"]} -->
GB/T 20271-2006 信息安全技术 信息系统通用安全技术要求

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00041", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 108"]} -->
GB/T 18018-2007 信息安全技术 路由器安全技术要求

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00042", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 109"]} -->
GB/T 21064-2007 电子政务系统总体设计要求

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00043", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 110"]} -->
GB/T 1988-1998 信息技术 信息交换用七位编码字符集

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00044", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 111"]} -->
GB/T 11457-2006 信息技术软件工程术语

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00045", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 112"]} -->
GB/T 12345-1990 信息交换用汉字编码字符集 辅助集

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00046", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 113"]} -->
GB/T 16260-2006 软件工程产品质量

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00047", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 96", "document order / paragraph 114"]} -->
GB/T 17539-1998 电子数据交换标准化应用指南

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00048", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 115"]} -->
GB 50174-2008 电子信息系统机房设计规范

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00049", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 116"]} -->
GB/T 9361-2011 计算机场地安全要求

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00050", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 117"]} -->
CAS 185-2009(C) 多CA联机认证服务系统应用规范

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00051", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 118"]} -->
GB/T 50311-2007综合布线系统工程设计规范

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00052", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 119", "document order / paragraph 745"]} -->
GB/T 2261.1-2003个人基本信息分类与代码 第1部分：人的性别代码

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00053", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 120"]} -->
GB/T 3304-1991 中国各民族名称的罗马字母拼写法和代码

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00054", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 121"]} -->
GB/T 4658-2008 学历代码

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00055", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 122"]} -->
GB/T 8561-2001 专业技术职务代码

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00056", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 123", "document order / paragraph 746"]} -->
评标专家专业分类标准（试行）（发改法规[2010]1538号）

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00057", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602171"></a>
# 3 **术语和定义**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00058", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 125"]} -->
下列术语和定义适用于本规范。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00059", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 126"]} -->
<a id="_Toc335645628"></a>
**3.1 电子招标投标 e-bidding**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00060", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 127"]} -->
根据招标投标相关法律法规规章，以数据电文为主要载体，应用信息技术完成招标投标活动的过程。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00061", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 128"]} -->
数据电文是指以电子、光学、磁或者类似手段生成、发送、接收或者储存的信息。本规范中的“电子文件”是指按照特定用途和规定的内容格式要求编辑生成的数据电文。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00062", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 129"]} -->
<a id="_Toc335645629"></a>
**3.2 交易平台 transaction platform**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00063", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 130"]} -->
招标投标当事人通过数据电文形式完成招标投标交易活动的信息平台。交易平台主要用于在线完成招标投标全部交易过程，编辑、生成、对接、交换和发布有关招标投标数据信息，为行政监督部门和监察机关依法实施监督、监察和受理投诉提供所需的信息通道。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00064", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 131"]} -->
<a id="_Toc335645630"></a>
**3.3 公共服务平台 public service platform**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00065", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 132"]} -->
为满足各交易平台之间电子招标投标信息对接交换、资源共享的需要，并为市场主体、行政监督部门和社会公众提供信息交换、整合和发布的信息平台。公共服务平台具有招标投标相关信息对接交换、发布、资格信誉和业绩验证、行业统计分析、连接评标专家库、提供行政监督通道等服务功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00066", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 133"]} -->
<a id="_Toc335645631"></a>
**3.4 行政监督平台administrative supervision platform**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00067", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 134"]} -->
行政监督部门和监察机关在线监督电子招标投标活动并与交易平台、公共服务平台对接交换相关监督信息的信息平台。行政监督平台应当公布监督职责权限、监督环节、程序、时限和信息交换等要求。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00068", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 135"]} -->
<a id="_Toc335645632"></a>
**3.5 监督通道 supervision channel**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00069", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 136"]} -->
交易平台、公共服务平台为行政监督部门和监察机关依法在线监督、监察电子招标投标活动提供的信息通道。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00070", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 137"]} -->
<a id="_Toc347496758"></a>
**3.6 项目 project**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00071", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 138"]} -->
为实现一定功能价值目标，在特定约束条件下一次性组织实施任务的活动过程，可以分为工程、货物、服务等项目，包含一个或多个招标项目。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00072", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 139"]} -->
<a id="_Toc335645634"></a>
**3.7 招标项目 tendering project**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00073", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 140"]} -->
项目中组织实施一次招标投标全流程的基本单元，可以包括一个或多个标段（包）。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00074", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 141"]} -->
<a id="_Toc335645635"></a>
**3.8 标段（包）bid section (package)**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00075", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 142"]} -->
根据实际需要，依据一定的约束条件及标准，对招标项目构成内容进行合理划分，成为最基本的交易管理单元。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00076", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 143"]} -->
<a id="_Toc335645636"></a>
**3.9 数据项 data item**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00077", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 144"]} -->
电子招标投标系统中为满足功能控制、数据交换、信息共享的需要，反映业务对象特征属性的结构化数据。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00078", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 145"]} -->
<a id="_Toc335645637"></a>
**3.10 信息资源库 information resource database**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00079", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 146"]} -->
电子招标投标系统中反映相关业务对象特征属性的数据项，按照对接交换、查询发布、统计分析等特定功能需要和标准进行分类集合的数据库。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00080", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 147"]} -->
<a id="_Toc335645638"></a>
**3.11 招标项目计划 tendering project plan**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00081", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 148"]} -->
招标人或招标代理机构根据招标方案编制的用于指导和控制招标实际工作的执行文件，主要包括招标项目内容、范围、招标方式、招标组织形式、主要工作内容、人员职责分工、工作质量和时间[进度](http://hanyu.iciba.com/hy/%E8%BF%9B%E5%BA%A6%E4%BF%A1%E6%81%AF)要求等内容。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00082", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 149"]} -->
<a id="_Toc335645639"></a>
**3.12 发标 issue of bidding documents**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00083", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 150"]} -->
招标人按资格预审公告、招标公告或者投标邀请书载明的时间、地点发出资格预审文件或者招标文件的活动。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00084", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 151"]} -->
<a id="_Toc335645640"></a>
**3.13 黑名单 blacklist**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00085", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 152"]} -->
违反有关法律法规规章规定的招标投标当事人名单。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00086", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 153"]} -->
<a id="_Toc335645641"></a>
**3.14 电子开标online bid-opening**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00087", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 154"]} -->
通过交易平台在线完成投标文件拆封解密、展示唱标内容并形成开标记录的工作程序。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00088", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 155"]} -->
<a id="_Toc347496767"></a>
**3.15 电子签名 e-signature**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00089", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 156"]} -->
运用电子密码技术，在数据电文中以电子形式所含，用于识别签名人身份并表明签名人认可其中内容的数据。本规范中的“签署”是指招标投标当事人对数据电文进行电子签名的行为。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00090", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 157"]} -->
<a id="_Toc347496768"></a>
**3.16 电子印章 e-stamp**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00091", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 158"]} -->
模拟在纸质文件上加盖传统实物印章的外观和方式进行电子签名的形式。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00092", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 159"]} -->
<a id="_Toc335645642"></a>
**3.17 开标记录 bid opening record**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00093", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 160"]} -->
记录参加开标的单位、人员、开标过程以及展示唱标内容等相关信息并经电子签名的数据文件。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00094", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 161"]} -->
<a id="_Toc335645643"></a>
**3.18 电子签到 sign-in**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00095", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 162"]} -->
参与电子开标活动的相关人员通过交易平台完成签名报到并形成电子记录文档的工作。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00096", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 163"]} -->
<a id="_Toc335645644"></a>
**3.19 电子评标e-bidding evaluation**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00097", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 164"]} -->
招标项目评标委员会通过交易平台的电子评标系统，按照招标文件约定的评标标准和方法，对电子投标文件评审，并形成评标报告电子文件的工作程序。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00098", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 165"]} -->
<a id="_Toc335645645"></a>
**3.20 回执 receipt**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00099", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 166"]} -->
电子文件接收人通过交易平台向发送人反馈的数据电文形式的签收单据。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00100", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 167"]} -->
<a id="_Toc347496773"></a>
**3.21 存档filing**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00101", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 168"]} -->
按招标投标有关规定和招标人的要求，在交易平台中生成、整理、保存、移交招标投标过程中产生的数据电文的工作。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00102", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 169"]} -->
<a id="_Toc335645646"></a>
**3.22 归档 e-archiving**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00103", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 170"]} -->
<a id="_Toc335645647"></a>
按国家档案管理部门电子档案管理要求整理、保存、移交招标投标过程中产生的数据电文的工作。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00104", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 171"]} -->
<a id="_Toc335645648"></a>
**3.23 编辑 edit**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00105", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 172"]} -->
运用交易平台提供的功能编写、修改、生成电子文件，或者利用其他专业工具生成并导入电子文件的工作。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00106", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 173"]} -->
<a id="_Toc335645649"></a>
**3.24 提交 submission**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00107", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 174"]} -->
招标投标当事人向有关行政监督部门、项目管理部门或者当事人内部管理部门发送数据电文的行为。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00108", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 175"]} -->
<a id="_Toc335645650"></a>
**3.25 发布 issue**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00109", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 176"]} -->
招标人向不特定的受众公布招投标活动中相关数据电文的行为。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00110", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 177"]} -->
<a id="_Toc335645651"></a>
**3.26 发出 sending out**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00111", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 178"]} -->
招标人向招标投标当事人、参与人发送数据电文的行为。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00112", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 179"]} -->
<a id="_Toc335645652"></a>
**3.27 递交 delivery**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00113", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 180"]} -->
招标投标当事人之间发送数据电文的行为。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00114", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 181"]} -->
<a id="_Toc335645653"></a>
**3.28 版式文件 formatted document**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00115", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 182"]} -->
运用数据电文编辑和格式转换技术，使得不同电子阅读软件及设备和阅读软件上显示内容、版面格式固定一致，防止篡改的数据电文。电子招标投标中的大多数电子文件需要采用版式文件。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00116", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 183"]} -->
<a id="_Toc335645654"></a>
**3.29 CA证书certification authority certificate**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00117", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 184"]} -->
<a id="_Toc335645656"></a>
经过有关部门认可的电子认证服务机构基于PKI技术签发、认证和管理的数字证书。CA证书具有数据电文交换中身份识别、电子签名、加密解密等功能。CA证书主要内容包括：证书服务机构的名称、证书持有人的名称及其签名验证数据、证书序列号、有效期、服务机构签名等。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00118", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 185"]} -->
<a id="_Toc335645657"></a>
**3.30 专业工具软件 utility software**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00119", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 186"]} -->
与交易平台兼容对接，用于制作、生成招标项目工程量清单、投标工程量清单报价以及工程投标报价评标分析的工程计价系统软件。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00120", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 187"]} -->
<a id="_Toc335806590"></a>
**3.31 投标文件制作软件bidding document creation software**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00121", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 188"]} -->
投标人用于制作投标文件的专用客户端软件，是交易平台的组成部分，主要具备招标文件导入、投标文件内容编辑、文件格式转换、投标文件生成、分类整理等功能。**3.32 时间戳time stamp**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00122", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 189"]} -->
应用电子签名技术，对电子文件提供日期和时间信息的安全保护和证明。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00123", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602172"></a>
# 4 **交易平台结构**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00124", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602173"></a>
## 4.1 **电子招标投标系统架构图**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00125", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 192"]} -->
电子招标投标系统由电子招标投标交易平台、电子招标投标公共服务平台、电子招标投标行政监督平台三个部分组成。三个平台的主要功能和架构关系如下图所示：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00126", "mapping_method": "non_text_block", "confidence": 0.0, "source_locators": [], "gate_block_reason": "non_text_block_without_text_locator"} -->
![](images/680121ea4c95e792b5a06d714c7c9d70fe41fcc101e3e81a985c692eb3bf0170.jpg)

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00127", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602174"></a>
## 4.2 **交易平台结构图**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00128", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 195"]} -->
交易平台由基本功能、信息资源库、技术支撑与保障、公共服务接口、行政监督接口、专业工具接口、投标文件制作软件等构成，并通过接口与公共服务平台和行政监督平台相连接，其基本功能结构如下图所示。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00129", "mapping_method": "non_text_block", "confidence": 0.0, "source_locators": [], "gate_block_reason": "non_text_block_without_text_locator"} -->
![](images/48341e96a987da14b7ba94dd697fc2ff8239e5c02f3d453bc3e80619afcffddc.jpg)

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00130", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602175"></a>
# 5 **交易平台基本功能要求**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00131", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 199"]} -->
交易平台基本功能应当按照招标投标业务流程要求设置，包括用户注册、招标方案、投标邀请、资格预审、发标、投标、开标、评标、定标、费用管理、异议、监督、招标异常、归档（存档）等功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00132", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602176"></a>
## 5.1 **用户注册**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00133", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801342"></a>
### 5.1.1 **招标人注册**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00134", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 202"]} -->
招标人注册管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00135", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 201", "document order / paragraph 203", "document order / paragraph 204", "document order / paragraph 205", "document order / paragraph 206", "document order / paragraph 207", "document order / paragraph 212", "document order / paragraph 218"]} -->
1. 招标人注册信息数据项应满足6.2的要求。
2. 应具备从公共服务平台公共信息资源数据库交换招标人注册信息的功能，并实现比对、排除重复，以及修正、验证确认、写入招标人信息库的功能。
3. 应具备记录注册信息的申报人员和交易平台验证人员的功能。
4. 应具备招标人绑定一个或多个CA证书的功能。
5. 应具备确定招标人唯一注册编码的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00136", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc282547258"></a>
### 5.1.2 **招标代理机构注册**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00137", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 209"]} -->
招标代理机构注册管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00138", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 205", "document order / paragraph 208", "document order / paragraph 210", "document order / paragraph 211", "document order / paragraph 212", "document order / paragraph 213", "document order / paragraph 218", "document order / paragraph 448"]} -->
1. 招标代理机构注册信息数据项应满足6.3的要求。
2. 应具备从公共服务平台公共信息资源数据库交换招标代理机构注册信息的功能，并实现比对、排除重复，以及修正、验证确认、写入招标代理机构信息库的功能。
3. 应具备记录注册信息的申报人员和交易平台验证人员的功能。
4. 应具备招标代理机构绑定一个或多个CA证书的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00139", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc257702597"></a>
### 5.1.3 **投标人注册**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00140", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 215"]} -->
投标人注册管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00141", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 214", "document order / paragraph 216", "document order / paragraph 285", "document order / table 44 / row 2 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 50 / row 2 / column 1", "document order / table 51 / row 3 / column 1"]} -->
1. 投标人注册信息数据项应满足6.4的要求。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00142", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 205", "document order / paragraph 212", "document order / paragraph 214", "document order / paragraph 217", "document order / paragraph 218", "document order / paragraph 219", "document order / paragraph 220", "document order / paragraph 285"]} -->
5. 应具备从公共服务平台公共信息资源数据库交换投标人注册信息的功能，并实现比对、排除重复，以及修正、验证确认、写入投标人信息库的功能。
6. 应具备记录注册信息的申报人员和交易平台验证人员的功能。
7. 应具备投标人绑定一个或多个CA证书的功能。
8. 宜具备投标人只能将电子印章绑定到一个CA证书的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00143", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602177"></a>
## 5.2 **招标方案**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00144", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801345"></a>
### 5.2.1 **招标项目**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00145", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 223"]} -->
招标项目管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00146", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 81", "document order / paragraph 221", "document order / paragraph 222", "document order / paragraph 224", "document order / paragraph 225", "document order / paragraph 226", "document order / paragraph 227", "document order / paragraph 285"]} -->
1. 应具备项目相关信息的建立和递交功能。数据项应包括项目编号、项目名称、项目地址、项目法人、联系人及其联系方式、项目行业分类、资金来源、项目规模等。
2. 应具备招标项目相关信息的建立和递交功能。数据项应包括项目名称、招标项目编号、招标项目名称、招标人代码、招标代理机构代码、招标内容与范围及招标方案说明、招标方式、招标组织形式、附件等。
3. 应建立项目与属于本项目下的招标项目之间的关联关系。
4. 应具备招标项目标段（包）建立和修改等管理功能。数据项应包括招标项目编号、标段（包）编号、标段（包）名称、标段（包）内容、标段（包）分类代码、投标人资格条件等。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00147", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 81", "document order / paragraph 222", "document order / paragraph 228", "document order / paragraph 229", "document order / paragraph 230", "document order / paragraph 385", "document order / paragraph 645", "document order / table 1 / row 1 / column 1"]} -->
1. 应建立招标项目与本招标项目下标段（包）的关联关系。
2. 应具备根据招标委托合同设定招标项目代理机构职责和权限的功能。数据项应包括招标代理机构代码、招标代理机构名称、招标代理机构资格分类分级代码、招标代理内容、范围、权限、招标代理机构项目负责人及其职责权限和联系方式等。
3. 宜具备招标委托合同的编辑、递交和签署功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00148", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 231", "document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 645"]} -->
5. 应具备向公共服务平台提供招标项目数据的功能。
6. 数据项格式详见附录A.1.1、A.1.2、A.1.3、A.1.25。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00149", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801346"></a>
### 5.2.2 **招标项目计划**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00150", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 234"]} -->
招标项目计划管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00151", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 235", "document order / paragraph 236", "document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306"]} -->
1. 应具备设定招标项目团队成员组成及其职责分工的功能。
2. 宜具备招标项目任务计划的编制、报审、下达、调整等管理功能。数据项应包括招标项目编号和招标项目名称、标段（包）编号、工作任务计划、项目团队成员组成及其职责分工等。
3. 数据项格式详见附录A.1.26。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00152", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602178"></a>
## 5.3 **投标邀请**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00153", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801348"></a>
### 5.3.1 **招标公告与资格预审公告**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00154", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 240"]} -->
招标公告与资格预审公告管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00155", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 241", "document order / paragraph 645", "document order / paragraph 647", "document order / table 44 / row 2 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 2 / column 2", "document order / table 49 / row 2 / column 1"]} -->
1. 应具备公开招标项目采用资格后审的招标公告和采用资格预审的资格预审公告的编辑、提交、审核、验证确认和发布功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00156", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 242"]} -->
招标公告数据项应包括招标项目编号、招标项目名称、相关标段（包）编号和投标资格、招标文件获取时间及获取方法、投标文件递交截止时间及递交方法、公告发布时间、附件等。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00157", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 243"]} -->
资格预审公告数据项应包括招标项目编号、招标项目名称、相关标段（包）编号和投标资格、资格预审文件获取时间及获取方法、资格预审申请文件递交截止时间及递交方法、资格预审公告发布时间、附件等。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00158", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 244"]} -->
b) 应该具备记录招标公告和资格预审公告编辑、递交发布责任人和交易平台验证责任人的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00159", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 245"]} -->
c) 应具备招标公告和资格预审公告同步递交到指定媒介发布的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00160", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 246"]} -->
d) 应具备向公共服务平台同步提供招标公告和资格预审公告的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00161", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 247", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / table 44 / row 2 / column 1", "document order / table 48 / row 2 / column 1"]} -->
e) 招标公告和资格预审公告的数据项格式详见附录A.1.4。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00162", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801349"></a>
### 5.3.2 **投标邀请书**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00163", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 249"]} -->
投标邀请书管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00164", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 250", "document order / paragraph 285", "document order / paragraph 455", "document order / table 5 / row 3 / column 1", "document order / table 7 / row 4 / column 1", "document order / table 9 / row 4 / column 1", "document order / table 44 / row 2 / column 1", "document order / table 48 / row 2 / column 1"]} -->
1. 应具备从投标人信息库中获取满足投标资格条件或特定条件的潜在投标人的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00165", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 238", "document order / paragraph 248", "document order / paragraph 251", "document order / paragraph 285", "document order / paragraph 652", "document order / table 44 / row 4 / column 1", "document order / table 48 / row 4 / column 1", "document order / table 49 / row 4 / column 1"]} -->
9. 应具备投标邀请书的编辑和发出功能。数据项应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00166", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 252"]} -->
采用邀请招标的数据项包括标段（包）编号、标段（包）名称、投标资格、招标文件获取时间及获取方法、投标文件递交截止时间及递交方法、回复截止时间、投标邀请发出时间、附件等。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00167", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 253"]} -->
采用资格预审的项目投标邀请书（代资格预审结果通知书）数据项包括标段（包）编号、标段（包）名称、招标文件获取时间及获取方法、投标文件递交截止时间及递交方法、回复截止时间、投标邀请发出时间、附件等。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00168", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 238", "document order / paragraph 254", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 285", "document order / paragraph 306"]} -->
10. 应具备被邀请人接受和拒绝投标邀请的回复功能。
11. 数据项格式详见附录A.1.5。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00169", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602179"></a>
## 5.4 **发标**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00170", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801354"></a>
### 5.4.1 **招标文件**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00171", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 258"]} -->
招标文件管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00172", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 257", "document order / paragraph 259", "document order / paragraph 260", "document order / paragraph 261", "document order / paragraph 262", "document order / paragraph 263"]} -->
1. 应具备招标文件的编辑、提交、审核、确认、备案、发出功能。数据项应包括标段（包）编号、投标资格、投标有效期、投标保证金、投标文件递交截止时间、投标文件递交方法、开标时间、开标方式、评标办法、附件等。
2. 应具备按照标准文件或示范文本生成招标文件的功能。
3. 应具备设定投标文件主要内容、格式要求的功能。
4. 应具备设定投标文件递交截止时间（开标时间）及其控制的功能。
5. 应具备记录招标文件下载人、下载时间、下载次数的功能。
6. 宜具备将招标文件多个不同格式附件组合打包生成一个文件的功能。
7. 应具备向公共服务平台提供招标文件的功能。
8. 数据项格式详见附录A.1.9。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00173", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc335806607"></a>
### 5.4.2 **资格预审文件**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00174", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 268"]} -->
资格预审文件的管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00175", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 267", "document order / paragraph 335", "document order / paragraph 649", "document order / table 3 / row 3 / column 1", "document order / table 5 / row 2 / column 1", "document order / table 6 / row 2 / column 1", "document order / table 6 / row 4 / column 1", "document order / table 6 / row 5 / column 1"]} -->
1. 资格预审文件的管理应满足5.4.1的规定。资格预审文件数据项应包括标段（包）编号、申请资格、申请有效期、申请文件递交截止时间、申请文件递交方法、开启时间、开启方式、评审办法、附件等。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00176", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
9. 数据项格式详见附录A.1.6。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00177", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801356"></a>
### 5.4.3 **踏勘现场**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00178", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 272"]} -->
踏勘现场管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00179", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 257", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 273", "document order / paragraph 274"]} -->
1. 应具备现场踏勘通知的编辑、发出功能。数据项应包括招标项目编号、标段（包）编号、踏勘通知内容、踏勘发出时间、附件等。
2. 应具备按招标文件约定的时间，向所有已获取招标文件的潜在投标人发出现场踏勘通知和提示现场踏勘时间的功能。
3. 应具备现场踏勘信息的记录功能。数据项应包括招标项目编号、标段（包）编号、踏勘单位名称及其代表姓名、踏勘时间、附件等。
4. 数据项格式详见附录A.1.10、A.1.11。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00180", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 267", "document order / paragraph 277", "document order / table 56 / row 46 / column 1", "document order / table 56 / row 56 / column 1", "document order / table 59 / row 5 / column 1", "document order / table 59 / row 6 / column 1"]} -->
<a id="_Toc262801355"></a>
### 5.4.4 **资格预审文件/招标文件澄清与修改**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00181", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 267", "document order / table 56 / row 46 / column 1", "document order / table 56 / row 56 / column 1", "document order / table 59 / row 5 / column 1", "document order / table 59 / row 6 / column 1"]} -->
资格预审文件/招标文件（5.4.4中统称“文件”）澄清与修改管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00182", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 257", "document order / paragraph 266", "document order / paragraph 267", "document order / paragraph 270", "document order / paragraph 279", "document order / paragraph 280"]} -->
1. 应具备文件澄清问题的编辑、递交功能。数据项应包括标段（包）编号、文件编号、要求澄清的问题、附件等。
2. 应具备符合法律法规规章规定和招标文件约定的由资格预审申请人/投标人递交澄清问题的时间控制功能。
3. 应具备招标人对文件的澄清与修改进行编辑、审核、发出的功能。数据项应包括标段（包）编号、澄清与修改文件编号、对文件澄清与修改的内容、澄清与修改递交时间、附件等。
4. 应具备符合法律法规规章规定和招标文件约定的招标人递交澄清答复的时间控制功能，以及向所有已获取文件的潜在资格预审申请人/投标人发送通知，并以醒目方式公告澄清与修改内容的功能。
5. 应具备潜在资格预审申请人/投标人下载澄清与修改文件，并递交回执的功能。
6. 文件澄清问题的数据项格式详见附录A.1.27，对资格预审文件的澄清与修改的数据项格式详见附录A.1.6，对招标文件的澄清与修改的数据项格式详见附录A.1.9。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00183", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602180"></a>
## 5.5 **投标**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00184", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801358"></a>
### 5.5.1 **资格预审申请文件/投标文件**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00185", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 286", "document order / paragraph 654", "document order / paragraph 659", "document order / table 44 / row 2 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 50 / row 2 / column 1"]} -->
资格预审申请文件/投标文件（在5.5.1中统称“文件”）管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00186", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 257", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 285", "document order / paragraph 288", "document order / paragraph 289"]} -->
1. 应具备在线或离线编辑和制作文件的功能，主要包括文件导入、文件内容编辑、工程量清单（如有）导入、版式文件转换、电子签章、文件生成、校验以及加密等功能。
    投标文件数据项应包括标段（包）编号、投标人代码、投标报价、工期（交货期）、投标有效期、投标保证金形式、投标保证金金额、投标单位项目负责人、投标时间、附件等。
    资格预审申请文件数据项应包括标段（包）编号、申请人代码、投标资格条件、项目负责人、申请时间、附件等。
2. 应具备通过网络对文件递交、修改和撤回功能。
3. 应具备按照招标文件中的递交截止时间控制文件递交、补充、修改和撤回的功能。
4. 应具备递交时间截止后，拒绝资格预审申请人/投标人递交、修改和撤回文件的功能。
5. 应具备拒绝接收递交时间截止时尚未完成传输的文件的功能。
6. 应具备对文件的主要数据项内容和格式进行校验的功能。
7. 应具备文件防篡改的功能。
8. 应具备投标人按照招标文件约定的加密方式选择按标段（包）分段或整体加密、递交文件的功能。
9. 应具备文件接收、校验、按接收时间排序和回执递交功能。
10. 应具备拒收未按法律法规规章规定和招标文件要求递交的文件的功能。
11. 应具备禁止除资格预审申请人/投标人外的任何人在投标截止前解密、提取文件的功能。
12. 截止时间应使用国家授时中心标准时间。
13. 宜动态显示国家授时中心当前时间。
14. 投标文件数据项格式详见附录A.1.12, 资格预审申请文件数据项格式详见附录A.1.7。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00187", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801360"></a>
### 5.5.2 **投标保证金**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00188", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 257", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 285", "document order / paragraph 302", "document order / paragraph 303"]} -->
1. 应具备记录和提示投标保证金接收、退还信息的功能。数据项应包括标段（包）编号、投标人代码、投标人名称、保证金金额、保证金支付形式、保证金凭证接收时间、保证金到账时间和保证金退还时间等。
2. 宜具备投标保证金接收情况展示的功能。
3. 宜具备按照招标文件要求对投标保证金支付形式、资金到账时间、金额、接收凭证等进行符合性校验的功能。
4. 数据项格式详见附录A.1.13。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00189", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602181"></a>
## 5.6 **开标**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00190", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801362"></a>
### 5.6.1 **签到记录**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00191", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 309"]} -->
应具备参加开标的人员通过网络远程办理电子签到的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00192", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801363"></a>
### 5.6.2 **开标唱标**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00193", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 311"]} -->
开标唱标管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00194", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 257", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 285", "document order / paragraph 302"]} -->
1. 应具备开标时验证投标单位是否达到和显示法定数量,并可以根据实际情况启动开标或取消开标的功能。
2. 应具备开标时验证并公布投标文件不被篡改、不遗漏及其投标过程记录的功能。
3. 应具备按开标时间规定控制投标文件解密并记录解密过程的功能。
4. 应具备招标人和投标人按照招标文件约定的解密方式解密投标文件以及解密失败时按规定补救方式执行的功能。
5. 应具备投标文件数据读取、记录、展示的功能。展示内容中应包括标段（包）编号、投标人名称、报价、工期（交货期）、投标保证金额、投标保证金到账时间、投标文件递交时间等招标文件所确定的唱标内容。
6. 应具备开标过程信息的记录、编辑、参与单位电子签名确认和递交功能。数据项应包括标段（包）编号、开标参与单位名称、开标展示内容等。
7. 应具备开标记录经过电子签名确认后，通过交易平台向社会公众和公共服务平台同步交换、公布的功能。
8. 宜具备开标记录模板的编辑、修改、管理的功能。
9. 招标项目开标记录的数据项格式详见附录A.1.14。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00195", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc335806617"></a>
### **5.6.3资格预审文件的开启**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00196", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 267", "document order / paragraph 321", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / paragraph 649", "document order / table 3 / row 1 / column 1", "document order / table 3 / row 3 / column 1", "document order / table 4 / row 1 / column 1"]} -->
1. 资格预审文件的开启管理要求应符合5.6.2的规定。资格预审文件开启记录的数据项应包括标段（包）编号开启参与单位名称、开启时间、开启内容等。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00197", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 267", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 323", "document order / paragraph 687"]} -->
10. 资格预审文件开启数据项格式详见附录A.1.28。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00198", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602182"></a>
## 5.7 **评标**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00199", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801365"></a>
### 5.7.1 **评标委员会**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00200", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 326"]} -->
评标委员会管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00201", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 327"]} -->
1. 应具备申请依法组建评标委员会的功能。数据项应包括标段（包）编号、专家人数、行政区域代码、专业、等级、回避条件等组建要求。
2. 应具备连接依法建立的专家库的功能。
3. 应具备通过公共服务平台连接的专家库通知评标委员会成员报到时间、地点的功能。
4. 应具备接收专家库反馈抽取评标专家名单，并据此设置评标委员会职责分工的功能，相关数据项应包括专家编号、专家姓名、通知时间、通知方式等。
5. 应具备评标委员会成员帐号生成、签到、身份确认、回避确认的功能。
6. 应具备评标专家行为考评记录，并递交到专家所属公共服务平台连接的专家库的功能。
7. 应提供评标委员会名单在评标前的保密功能。
8. 评标委员会数据项格式详见附录A.2.9、A.2.10。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00202", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801366"></a>
### 5.7.2 **评审**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00203", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 336"]} -->
评审管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00204", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 285", "document order / paragraph 324", "document order / paragraph 335", "document order / paragraph 337", "document order / paragraph 338", "document order / paragraph 339", "document order / paragraph 340"]} -->
1. 应具备能够按招标文件约定的评标方法、评审因素和标准设置评审表格和评审项目的功能。
2. 应具备按招标文件约定的评标方法，对投标文件进行解析、对比，辅助评分或计算评标价的功能。
3. 应具备汇总计算投标人综合评分或评标价并进行排序的功能。
4. 应具备编辑和发出评标澄清问题的功能。
5. 应具备投标人编辑和递交投标澄清文件的功能。
6. 应具备依评审权限设置评审项目访问、信息阅读的功能，确保无相应权限者无法查阅或操作相关数据。
7. 宜具备以下评审功能：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00205", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 344"]} -->
按招标项目类型和评标办法设置、维护和管理评标模板。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00206", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 345"]} -->
依据招标项目清单、标底总价、分项单价与投标报价进行校验、对比，提示差异。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00207", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 346"]} -->
检测和辅助分析投标文件及异常投标行为。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00208", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 347"]} -->
评标委员会成员打分结果的检测和辅助分析。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00209", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801367"></a>
### 5.7.3 **评标报告**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00210", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 349"]} -->
评标报告管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00211", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 285", "document order / paragraph 306", "document order / paragraph 324", "document order / paragraph 348"]} -->
1. 应具备评标报告编辑、阅读的权限设置、签署和提交功能。数据项应包括标段（包）编号、中标候选人名称及排名、投标价格、评分结果或评标价格、中标价格、附件等。
2. 应具备向公共服务平台监督通道提供评标报告数据的功能。
3. 评标报告的数据项格式详见附录A.1.15、A.1.16。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00212", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801368"></a>
### 5.7.4 **远程异地评标**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00213", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 354"]} -->
宜按以下要求具备网络远程异地评标的功能：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00214", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 355", "document order / paragraph 356", "document order / paragraph 357", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1"]} -->
1. 对评标委员会实现有效的监控。
2. 对评标时间和地点进行控制。
3. 评标委员会评标必需的沟通功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00215", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc335806623"></a>
### 5.7.5 **资格预审申请文件的评审**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00216", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 335", "document order / table 44 / row 2 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 50 / row 2 / column 1", "document order / table 51 / row 3 / column 1", "document order / table 52 / row 2 / column 1", "document order / table 56 / row 59 / column 1"]} -->
1. 资格预审评审委员会的管理要求应符合5.7.1的规定。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00217", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 335", "document order / paragraph 358", "document order / paragraph 363"]} -->
4. 资格预审申请文件的评审管理要求应符合5.7.2的规定，其中有关价格评审功能不适用于资格预审申请文件的评审。
5. 资格预审结果文件的管理要求应符合5.7.3的规定。数据项应包括标段（包）编号、通过资格预审的申请人名单、附件等。
6. 资格预审申请文件的远程异地评审的管理要求应符合5.7.4的规定。
7. 应具备向公共服务平台监督通道提供资格预审结果文件的功能。
8. 资格预审结果文件的数据项格式详见附录A.1.8

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00218", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602183"></a>
## 5.8 **定标**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00219", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801370"></a>
### 5.8.1 **中标候选人公示**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00220", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 285", "document order / paragraph 306", "document order / paragraph 366", "document order / paragraph 367"]} -->
1. 应具备中标候选人公示的编辑、提交审核、验证确认、备案、发布功能。数据项应包括：标段（包）编号、公示内容（含中标候选人名称及排序、投标价格、中标价格）、公示时间等。
2. 应具备向公共服务平台提供中标候选人公示数据的功能。
3. 中标候选人公示的数据项格式详见附录A.1.17。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00221", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 370", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 3 / column 1", "document order / table 50 / row 3 / column 1", "document order / table 52 / row 3 / column 1", "document order / table 56 / row 60 / column 1", "document order / table 59 / row 3 / column 1"]} -->
<a id="_Toc262801371"></a>
### 5.8.2 **确认资格预审的申请人/确定中标人**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00222", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 371", "document order / paragraph 372", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1"]} -->
1. 应具备授权资格审查委员会确认通过资格预审的申请人/授权评标委员会确定中标人的功能。
2. 应提供招标人确认通过资格预审的申请人/确定中标人的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00223", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc335806627"></a>
### 5.8.3 **中标结果公告**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00224", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 373", "document order / paragraph 374", "document order / paragraph 375"]} -->
1. 应具备编辑、提交审核、验证确认、备案、发布和向公共服务平台提供中标结果公告的功能。数据项应包括：标段（包）编号、标段（包）名称、中标人名称、中标价格、附件等。
2. 中标结果公告的数据项格式详见附录A.1.29。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00225", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801373"></a>
### 5.8.4 **中标通知书**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00226", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 377"]} -->
中标通知书管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00227", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 376", "document order / paragraph 378"]} -->
1. 应具备中标通知书和招标结果通知书的编辑、验证确认和递交的功能。数据项应包括：招标项目名称及其编号、标段（包）编号、中标人、中标价格、附件等。
2. 宜具备中标、未中标理由的编辑、确认、递交功能。
3. 应具备向公共服务平台提供中标通知书和招标结果通知书的功能。
4. 中标通知书和招标结果通知的数据项格式详见附录A.1.18。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00228", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc335806629"></a>
### 5.8.5 **资格预审结果通知书**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00229", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 382", "document order / paragraph 384"]} -->
1. 资格预审结果通知书的管理应满足5.8.4中a)、b)、c)的规定。数据项应包括：招标人、招标代理机构、招标项目名称及其编号、标段（包）编号、资格预审通过单位名称、资格预审通知书发出时间、附件等。
2. 资格预审结果通知书的数据项格式详见附录A.1.19。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00230", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801374"></a>
### 5.8.6 **合同**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00231", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 386"]} -->
合同管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00232", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 257", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 385"]} -->
1. 应提供招标项目标段（包）与合同的关联关系。
2. 应具备根据法律法规规章和招标文件约定的内容，编辑、形成、递交、验证确认和签署合同文本的功能。
3. 应具备向公共服务平台提供规定要求的合同信息的功能。
4. 宜具备按规定要求向相关主体和管理单位收集、记录和验证合同履行结果的相关信息。
5. 合同的数据项格式详见附录A.1.20。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00233", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602184"></a>
## 5.9 **费用管理**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00234", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 393"]} -->
费用管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00235", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 267", "document order / paragraph 285", "document order / paragraph 302", "document order / paragraph 324", "document order / paragraph 394", "document order / paragraph 395", "document order / paragraph 396"]} -->
1. 应具备招投标过程中各类费用的支付结算、退还的信息管理及控制后续相关程序等管理功能。
2. 费用类型包括资格预审文件费用、招标文件费用、图纸押金、投标保证金及其利息、履约保证金、招标代理服务费、交易服务费、评标专家咨询费等。
3. 应具备选择多种支付结算方式的功能。
4. 宜具备支持网上电子支付结算的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00236", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602185"></a>
## 5.10 **异议**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00237", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 399"]} -->
异议管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00238", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 257", "document order / paragraph 266", "document order / paragraph 267", "document order / paragraph 270", "document order / paragraph 285", "document order / paragraph 306"]} -->
1. 应具备投标人对资格预审文件、招标文件、开标过程、资格预审结果、评标结果按规定的时间提出异议的功能。
2. 应具备招标人在规定的时间内答复投标人异议的功能。
3. 异议的数据项格式详见附录A.1.21。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00239", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602186"></a>
## 5.11 **招标异常**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00240", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 404"]} -->
招标异常管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00241", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 257", "document order / paragraph 267", "document order / paragraph 403", "document order / paragraph 405", "document order / paragraph 406", "document order / paragraph 407", "document order / paragraph 408"]} -->
1. 应具备招标终止功能及招标终止公告的编辑、提交和发布功能。
2. 宜具备重新发布招标公告或资格预审公告、资格预审文件或招标文件，并保留已完成招标程序的相关数据的功能。
3. 宜具备招标项目按有关规定改用非招标方式后，记录其他交易方式和成交结果的功能。
4. 招标异常情况报告的数据项格式详见A.1.22。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00242", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602187"></a>
## 5.12 **存档、归档**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00243", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 410"]} -->
存档、归档管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00244", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 285", "document order / paragraph 324", "document order / paragraph 409", "document order / paragraph 411", "document order / paragraph 412", "document order / paragraph 413", "document order / paragraph 414"]} -->
1. 应具备按照有关规定和招标文件的要求对招标投标数据和文件、活动记录进行存档的功能。
2. 应具备数据和文件的分类、整理和归档的功能。数据和文件的归档应符合国家有关电子档案的规定。
3. 应具备按权限查阅招标投标数据和文件的功能。
4. 应具备记录、备份、存档、归档电子招标投标中涉及的操作时间和人员的功能。
5. 应具备评标全过程录像自投标有效期结束之日起存档90日以上的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00245", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602188"></a>
## 5.13 **监督**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00246", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc335806636"></a>
### 5.13.1 **接受监督**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00247", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 418"]} -->
按照招标投标法律法规规章和监督部门的要求，应具备通过公共服务平台的行政监督通道或直接通过行政监督平台，适时与监督部门交换相关数据和文件的功能，并满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00248", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 81", "document order / paragraph 222", "document order / paragraph 237", "document order / paragraph 238", "document order / paragraph 248", "document order / paragraph 255", "document order / paragraph 257", "document order / paragraph 266"]} -->
1. 提交招标人和招标项目的基本情况，以及经核准的招标内容与范围、招标方式、招标组织形式。数据项格式详见附录A.1.1、A.1.2、A.1.3。
2. 提交资格预审公告、招标公告或者投标邀请书。数据项格式详见附录A.1.4、A.1.5。
3. 提交资格预审文件、招标文件。数据项格式详见附录A.1.6、A.1.9。
4. 提交资格审查委员会名单和资格预审结果报告。资格审查委员会数据项格式详见附录A.2.9、A.2.10，资格预审结果数据项格式详见附录A.1.8。
5. 提交投标文件验证、解密及展示、投标人确认等开标过程和开标记录的信息。数据项格式详见A.1.14。
6. 提交评标委员会名单、评标报告和中标候选人。数据项格式详见附录A.2.9、A.2.10、A.1.15、A.1.16。
7. 提交中标候选人公示和中标结果。数据项格式详见附录A.1.17、A.1.29。
8. 提交合同和履行信息。数据项格式详见附录A.1.20。
9. 提交招标异常的有关情况。需要审批或核准的，提交相关审批或核准信息。数据项格式详见附录A.1.22。
10. 接收和执行有关行政监督部门监督指令的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00249", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc335806637"></a>
### 5.13.2 **配合投诉处理**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00250", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 430"]} -->
配合投诉处理管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00251", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 431", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / paragraph 649", "document order / table 3 / row 1 / column 1", "document order / table 3 / row 3 / column 1", "document order / table 4 / row 1 / column 1", "document order / table 5 / row 1 / column 1"]} -->
1. 宜具备编辑、提交投诉事项有关信息、接收、查询投诉受理情况和处理结果的功能。投诉时限应满足相关规定的要求。投诉处理的数据项应包括标段（包）编号、投诉人代码、投诉人名称、投诉内容、理由和依据、投诉提交时间、投诉受理人、受理时间、处理结果、反馈时间、附件等。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00252", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 432", "document order / paragraph 433", "document order / table 44 / row 2 / column 1"]} -->
11. 宜具备向公共服务平台提供投诉处理数据和文件的功能。
12. 投诉处理的数据项格式详见附录A.1.21。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00253", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602189"></a>
# 6 **交易平台信息资源库**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00254", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 435"]} -->
信息资源库采集整合的要素信息，仅限于政府有关网站、平台公布的信息和电子招标投标系统上记录并经过验证、交换、公布的信息，主要是电子招标投标交易平台上成交的项目及其相关主体的要素信息。除上述来源以外采集的信息和投标人在投标文件中提供的以纸质形式完成招标投标的中标项目业绩信誉、从业人员业绩信誉等信息，仅限于该招标项目中一次使用，禁止转入交易平台信息资源库分类集合，也不得用于对外查询、公布、交换及统计。但是，交易平台可以另行建立辅助信息资源库集中此类非可靠信息，仅限于内部交换和参考，且应当注明信息采集来源和相关责任人员。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00255", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602190"></a>
## 6.1 **招标项目信息库**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00256", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 437"]} -->
招标项目信息库管理应满足如下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00257", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 81", "document order / paragraph 221", "document order / paragraph 222", "document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 285"]} -->
1. 应具备招标项目信息的建立和维护的功能。数据项应包括项目名称、项目编号、项目行业分类代码、项目所在行政区域代码、法定代表人、招标交易平台代码、招标项目编号、招标项目名称、招标内容与范围和招标方案说明及附件、招标人代码、招标代理机构代码，以及进行信息交换的公共服务平台标识码等。
2. 应具备标段（包）与中标信息建立和维护的功能。数据项应包括标段（包）编号、标段（包）内容、标段（包）分类代码、投标人资格条件、中标人代码、中标价格、项目负责人、项目质量要求、项目工期（交货期）、中标通知书编号、合同订立价格，合同结算价格、合同验收质量、合同履行期限等。
3. 应具备招标项目相关时间信息的建立和维护功能。数据项应包括招标项目建立时间、公告发布时间、开标时间、中标候选人公示时间、中标通知时间、签约时间、合同完成时间等。
4. 数据项格式详见附录A.1.1、A.1.2、A.1.3、A.1.4、A.1.18、A.1.20。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00258", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602191"></a>
## 6.2 **招标人信息库**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00259", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 443"]} -->
招标人信息库管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00260", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 444", "document order / paragraph 445", "document order / paragraph 446"]} -->
1. 应具备招标人信息建立和维护的功能。数据项应包括招标人代码、招标人名称、负责人、国别/地区、行业代码、营业执照号码、CA证书编号、组织机构代码、税务登记号、开户银行、基本账户账号、注册资本、币种、信息申报责任人、联系电话、联系地址、邮政编码、电子邮箱等信息。
2. 应具备招标人招标业绩、奖惩、履约记录等信息管理的功能。
3. 应具备招标人信息的检索和统计分析的功能。
4. 数据项格式详见附录A.2.1, A.2.3、A.2.8、A.1.20。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00261", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602192"></a>
## 6.3 **招标代理机构信息库**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00262", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 449"]} -->
招标代理机构信息库管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00263", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 450", "document order / paragraph 451", "document order / paragraph 452"]} -->
1. 应具备招标代理机构信息建立和维护的功能。数据项应包括代理机构代码、代理机构名称、负责人、国别/地区、资质类别、资质等级、营业执照号码、CA证书编号、组织机构代码、税务登记号、开户银行、基本账户、注册资本、信息申报责任人、联系电话、联系地址、邮政编码、电子邮箱等信息。
2. 应具备招标代理机构电子招标业绩、奖惩记录和履约记录等信息管理的功能。
3. 应具备招标职业资格人员的相关信息管理的功能。数据项包括姓名、性别、身份证件类型、身份证件号码、出生年月、所在行政区域代码、最高学历、联系电话、通讯地址、邮政编码、所在单位、职务、职业证书编号、注册登记证书编号、从业年限、项目业绩、奖惩记录等信息。
4. 应具备招标代理机构信息的检索和统计分析的功能。
5. 数据项格式详见附录A.2.1、A.2.2、A.2.3、A.2.4、A.2.5、A.2.6、A.2.8、A.1.20。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00264", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602193"></a>
## 6.4 **投标人信息库**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00265", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 456"]} -->
投标人信息库管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00266", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 285", "document order / paragraph 306", "document order / paragraph 457", "document order / paragraph 458"]} -->
1. 应具备投标人信息建立和维护的功能。数据项按不同主体应相应包括：投标人代码、投标人名称、负责人、国别/地区、资质序列、资质等级、资信等级、奖惩记录、营业执照号码、CA证书编号、组织机构代码、税务登记号、开户银行、基本账户账号、注册资本、注册资本币种、信息申报和变更责任人、联系电话、联系地址、邮政编码、电子邮箱等信息。
2. 应具备投标人中标业绩明细数据、奖惩与履约等信息归集的功能。
3. 应具备投标人信息的检索和统计分析的功能。
4. 应具备投标人黑名单的建立和管理的功能。
5. 应具备投标人专业职业资格人员（注册建造师、注册监理工程师等）的相关信息管理的功能。数据项包括姓名、性别、身份证件类型、身份证件号码、出生年月、所在行政区域代码、最高学历、联系电话、通讯地址、邮政编码、所在单位、职务、技术职称、职业资格序列、职业资格等级、职业证书编号、从业经历、从业年限、项目业绩、奖惩记录等信息。
6. 数据项格式详见附录A.2.1、A.2.2、A.2.4、A.2.5、A.2.6、A.2.7、A.2.8、A.1.20。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00267", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602194"></a>
## 6.5 **专家信息库**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00268", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 464"]} -->
必要时可建立交易平台专家信息库。专家信息库管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00269", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 465", "document order / paragraph 466", "document order / paragraph 467"]} -->
1. 应具备专家信息建立和维护的功能。数据项应包括：专家编号、姓名、性别、身份证件类型、身份证件号码、出生年月、所在行政区域代码、最后毕业院校、最高学历、联系电话、通讯地址、邮政编码、所在单位、是否在职、职务、工作简历、专业分类、技术职称、职业资格序列、职业资格等级、从业年限、奖惩记录等信息。
2. 应具备记录专家信息入库、变更和审核验证的时间以及责任人的功能。
3. 应具备专家回避情形和单位列表建立和维护的功能。
4. 应具备按地区、专业等随机抽取和记录专家的功能。
5. 应具备专家审核、入库、培训、考核、暂停、退出等功能。
6. 宜具备专家自荐入库的功能。
7. 宜具备向公共服务平台专家库推荐专家入库的功能。
8. 数据项格式详见附录A.2.8、A.2.11。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00270", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602195"></a>
## 6.6 **价格信息库**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00271", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 474"]} -->
价格信息库管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00272", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 475", "document order / paragraph 476", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 49 / row 3 / column 1"]} -->
1. 应具备工程、货物、服务分类分项单价信息的收集、整理、维护和查询的功能。
2. 宜具备价格统计分析的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00273", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602196"></a>
# 7 **交易平台的系统接口**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00274", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 478"]} -->
系统接口是指交易平台与公共服务平台、行政监督平台以及专业工具软件之间根据电子招标投标流程及有关规定应具有的数据交换功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00275", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602197"></a>
## 7.1 **公共服务平台的接口**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00276", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc335806652"></a>
### 7.1.1 **交易平台注册登记**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00277", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 481"]} -->
交易平台应选择任一公共服务平台注册登记和按规定对接交互信息。在全国公共服务平台体系形成前，交易平台选择注册登记和对接交换公共服务平台应同时满足行政监督信息交换的需要。登记的数据信息应包括：交易平台名称、运营机构代码、运营机构名称、CA证书编号、系统访问地址、检测和认证报告附件等，数据项格式详见附录A3。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00278", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc335806653"></a>
### 7.1.2 **与公共服务平台的接口**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00279", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 483"]} -->
交易平台与公共服务平台的数据接口应符合《公共服务平台和行政监督平台技术规范》和相关公共服务平台公布的数据接口要求。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00280", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602198"></a>
## 7.2 **与行政监督平台的接口**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00281", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 416", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 49 / row 3 / column 1", "document order / table 50 / row 2 / column 1"]} -->
交易平台可以选择公共服务平台的监督通道与行政监督平台交换信息，其数据接口应符合7.1.2的规定。交易平台也可以选择直接与行政监督平台交换信息，与行政监督平台的数据接口应符合《公共服务平台和行政监督平台技术规范》和相关行政监督平台公布的数据接口要求。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00282", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602199"></a>
## 7.3 **与专业工具软件的接口**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00283", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 487"]} -->
交易平台与专业工具软件的数据接口应符合本技术规范和国家有关计价规范要求，并在交易平台公布。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00284", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602200"></a>
# 8 **交易平台技术支撑与保障要求**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00285", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602201"></a>
## 8.1 **接口技术要求**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00286", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801402"></a>
### 8.1.1 **基本要求**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00287", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 491"]} -->
接口技术基本要求如下：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00288", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 492", "document order / paragraph 493", "document order / paragraph 494", "document order / paragraph 495", "document order / paragraph 496", "document order / paragraph 497", "document order / paragraph 498", "document order / paragraph 587"]} -->
1. 应对数据交互提供企业级的支持，在系统高并发和大容量的基础上提供安全可靠的交互。
2. 应提供完善的信息安全机制，以实现对信息的全面保护，保证系统的正常运行.应防止大量访问以及大量占用资源的情况发生，保证系统的健壮性。
3. 应提供有效的、系统的可监控机制，以使接口的运行情况可监控，以便及时发现错误及排除故障。
4. 在充分利用系统资源的前提下，应实现系统平滑的移植和扩展，同时在系统并发增加时提供系统资源的动态扩展，以保证系统的稳定性。
5. 在进行扩容、新业务扩展时，应能提供快速、方便和准确的实现方式。
6. 接口技术实现方式应当保持中立性。
7. 应提供信息交换中自动标记输入和输出来源出处的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00289", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801403"></a>
### 8.1.2 **通信方式**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00290", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 500"]} -->
接口应通过基于主流的通信协议，并满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00291", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 501", "document order / paragraph 502", "document order / paragraph 503", "document order / paragraph 586", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1"]} -->
1. 数据传输应具备可控制性，提供数据重发功能。
2. 数据传输应具备可靠性，确保数据不会丢失，并进行充分的数据校验。
3. 大数据传输应具备断点续传的功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00292", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801404"></a>
### 8.1.3 **接口方式**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00293", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 505"]} -->
接口方式管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00294", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 506", "document order / paragraph 507", "document order / paragraph 508", "document order / paragraph 509", "document order / table 1 / row 1 / column 4", "document order / table 2 / row 1 / column 4", "document order / table 3 / row 1 / column 4", "document order / table 4 / row 1 / column 4"]} -->
1. 信息交换方式应符合XML数据交换标准。
2. 交互操作服务接口应符合Web Services标准。
3. 系统交互模式支持同步与异步方式。
4. 交互数据应支持各种数据类型。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00295", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801405"></a>
### 8.1.4 **接口模型**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00296", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 511"]} -->
数据接口模型应由数据结构、数据集、附件集组成：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00297", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 512", "document order / paragraph 513", "document order / paragraph 514", "document order / paragraph 515", "document order / paragraph 671", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1"]} -->
1. 数据结构用来描述接口的结构信息，是可选元素。
2. 数据集是用来封装结构化数据，是可选元素。
3. 附件集是用来表述非结构化数据，是可选元素。
4. 数据集和附件集可以并存或单独出现。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00298", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801406"></a>
### 8.1.5 **安全认证**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00299", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 517"]} -->
为了保证数据的安全性，各种接口方式都应该保证其接入的安全性：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00300", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 516", "document order / paragraph 518", "document order / paragraph 519", "document order / paragraph 520", "document order / paragraph 521", "document order / paragraph 522", "document order / paragraph 529", "document order / paragraph 544"]} -->
1. 应通过接口实现技术上的安全控制，做到对安全事件的可知、可控、可预测。
2. 应制定专门的安全技术实施策略，保证接口的数据传输和数据处理的安全性。
3. 系统应在接入点的网络边界实施接口安全控制。
4. 接口的安全控制在逻辑上应包括：安全评估、访问控制、入侵检测、口令认证、安全审计、防恶意代码、加密等内容。
5. 数据接口访问应进行双方身份安全认证，确保接口访问的安全性。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00301", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801407"></a>
### 8.1.6 **传输控制**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00302", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 524"]} -->
传输控制应利用如下高速数据通道技术实现将前端的大数据量并发请求分发到后端，从而保证应用系统在大量客户端同时请求服务时，能够保持快速、稳定的工作状态：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00303", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 523", "document order / paragraph 525", "document order / paragraph 526", "document order / paragraph 527", "document order / paragraph 528", "document order / paragraph 591", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1"]} -->
1. 系统应采用传输控制手段降低接口网络负担，提高接口吞吐能力，保证系统的整体处理能力。
2. 为了确保接口服务吞吐量最大，接口宜自动地在系统中完成动态负载均衡调度。
3. 系统宜提供自动伸缩管理方式或动态配置管理方式实现队列管理、存取资源管理，以及接口应用的恢复处理等。
4. 在双方接口之间宜设置多个网络通道，实现接口的多数据通道和容错性，保证在出现一个网络通道通讯失败时，进行自动的切换，实现接口连接的自动恢复。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00304", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602202"></a>
## 8.2 **安全性**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00305", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801416"></a>
### 8.2.1 **身份标识与鉴别**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00306", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 531"]} -->
应对招标人、招标代理机构、投标人、授权评标专家等登录用户进行身份标识与鉴别，并提供身份标识唯一性检查功能。应采用以下措施，确保用户身份不易被冒用：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00307", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 302", "document order / paragraph 307", "document order / paragraph 376", "document order / paragraph 385", "document order / paragraph 530", "document order / paragraph 532", "document order / paragraph 533"]} -->
1. 应提供鉴别信息复杂度检查功能。
2. 应对身份标识与鉴别异常提供保护措施。
3. 应使用有关部门认可的合法电子认证服务机构提供的CA数字证书对交易主体身份标识与鉴别，需要进行身份标识与鉴别的电子招标投标交易行为包括：递交资格预审申请文件、递交投标文件、递交投标保证金、撤回投标文件、确认开标记录、递交回执、发出中标通知书、签订合同（协议书）等需要招标投标主体承担相应法律责任的电子招标投标行为。
4. 宜采用两种或两种以上上述措施组合的鉴别技术。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00308", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801417"></a>
### 8.2.2 **电子签名**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00309", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 537"]} -->
电子签名管理要求应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00310", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 238", "document order / paragraph 248", "document order / paragraph 257", "document order / paragraph 267", "document order / paragraph 285", "document order / paragraph 307", "document order / paragraph 324", "document order / paragraph 348"]} -->
1. 应通过电子签名来确保数据电文的完整性和不可抵赖性，电子签名应用的数字证书应采用合法的电子认证服务机构颁发的CA证书。
2. 应使用电子签名的数据电文包括：招标公告（资格预审公告）、投标邀请书、资格预审文件（澄清和修改）、资格预审申请文件（澄清和修改）、资格审查报告、招标文件（澄清和修改）、投标文件（补充、修改、撤回、澄清）、开标记录、评标报告、中标通知书、合同（协议书）及相关文件的签收回执等具有法律约束力的文件。
3. 应提供按照国家授时中心的标准时间源对需要电子签名的数据电文生成时间戳的功能。
4. 应执行统一规范的数据接口标准，并可通过公共服务平台协议联机等方式，支持不同的合法电子认证服务机构颁发的CA数字证书的兼容互认。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00311", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801418"></a>
### 8.2.3 **电子加密和解密**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00312", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 543"]} -->
应使用合法的电子认证服务机构颁发的数字证书，并能够根据招标文件选择确定的操作方式和责任主体，对需要保密的数据电文进行加密和解密，以确保数据电文的保密性。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00313", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801419"></a>
### 8.2.4 **访问控制**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00314", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 545"]} -->
访问控制管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00315", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 546", "document order / paragraph 547", "document order / paragraph 548", "document order / paragraph 549", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1"]} -->
1. 应具备用户功能使用、数据访问的权限及其时限控制功能。
2. 应能够识别对系统的非授权访问并提供相应的处理方法。应具备禁止同一帐户多处同时登录的功能。
3. 用户的管理权限应按照边界清晰，且权限唯一性和最小化原则设置。实施系统开发权、系统管理权和业务权的责任人应相互分离、相互监控，同时，系统应具有自动警示超权限异常操作的功能。
4. 宜提供对重要信息资源设置敏感标记的功能，并根据安全策略严格控制用户对有敏感标记重要信息资源的操作。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00316", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801420"></a>
### 8.2.5 **通信安全**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00317", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 551"]} -->
通信安全管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00318", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 552", "document order / paragraph 553", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 48 / row 4 / column 2", "document order / table 49 / row 2 / column 1"]} -->
1. 应能够检测传输过程中数据电文的完整性，在检测到完整性错误时，应提示用户采取必要的措施。
2. 应采用加密或其它有效措施实现数据传输的保密性。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00319", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801421"></a>
### 8.2.6 **存储安全**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00320", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 555"]} -->
存储安全管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00321", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 556", "document order / paragraph 557", "document order / paragraph 558", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 44 / row 4 / column 2", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1"]} -->
1. 应采用加密或其他保护措施实现鉴别信息存储的保密性。
2. 宜采用加密或其他保护措施确保重要数据存储的保密性。
3. 宜对重要数据存储过程中的完整性进行检测，在检测到完整性错误时，应提示用户采取相应的措施。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00322", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801422"></a>
### 8.2.7 **资源控制**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00323", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 560"]} -->
资源控制管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00324", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 561", "document order / paragraph 562", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 49 / row 3 / column 1"]} -->
1. 应该能够对单个帐户的多重并发会话进行限制，并能够对系统的最大并发会话连接数进行限制。
2. 宜对一个时间段内可能的并发会话连接数进行限制。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00325", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801423"></a>
### 8.2.8 **数据安全及备份恢复**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00326", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 564"]} -->
数据安全及备份恢复管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00327", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 565", "document order / paragraph 566", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 49 / row 3 / column 1"]} -->
1. 应对关键数据提供自动定时本地备份与恢复功能。
2. 宜提供异地数据定期备份功能和异地灾备功能。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00328", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801424"></a>
### 8.2.9 **安全缺陷防范**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00329", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 568"]} -->
安全缺陷防范管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00330", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 569", "document order / paragraph 570", "document order / paragraph 571", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 2 / column 1"]} -->
1. 不应存在可能引起安全缺陷的语句、命令。
2. 应能够识别和屏蔽非法访问。
3. 宜加强系统安全防范，能够识别和抵御程序恶意攻击。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00331", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801425"></a>
### 8.2.10 **安全审计**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00332", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 573"]} -->
安全审计管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00333", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 81", "document order / paragraph 572", "document order / paragraph 574", "document order / paragraph 575", "document order / paragraph 576", "document order / paragraph 577", "document order / paragraph 578", "document order / table 44 / row 2 / column 1"]} -->
1. 应提供安全审计功能。安全审计范围应覆盖系统中的每个用户及系统中的所有重要安全事件，如登录事件、关键数据变更等。
2. 审计记录的内容应包括事件的日期、时间、发起者信息、类型、描述和结果等。
3. 应提供审计记录数据的查询、统计、分析功能。
4. 安全审计人员不能同时兼任系统管理员。
5. 安全审计系统设备宜独立部署，以确保数据不被篡改。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00334", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602203"></a>
## 8.3 **性能**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00335", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801427"></a>
### 8.3.1 **响应时间**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00336", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 581"]} -->
响应时间管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00337", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 580", "document order / paragraph 582", "document order / paragraph 583", "document order / paragraph 585", "document order / paragraph 659", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1"]} -->
1. 应满足主要功能在单点操作下响应时间少于5秒。
2. 典型功能在50人并发情况下，响应时间应少于15秒。
3. 应支持大文件传输功能。支持100MB以内的文件稳定上传。服务器端接收上传文件的最大吞吐量应不低于10M bit/S。
4. 投标文件集中解密功能模块的系统处理能力应保证每分钟文件解密应大于100个或大于1GB。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00338", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602204"></a>
## 8.4 **可靠性**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00339", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801430"></a>
### 8.4.1 **稳定性**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00340", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 588"]} -->
系统稳定性管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00341", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 589", "document order / paragraph 590", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 49 / row 3 / column 1"]} -->
1. 应保证在高负荷状态下能提供不间断的可靠服务，系统运行稳定。
2. 在容量到达规定及超出规定的极限时，系统不能因为崩溃、异常退出等原因而导致数据错误或丢失。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00342", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801431"></a>
### 8.4.2 **容错性**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00343", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 592"]} -->
系统容错性管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00344", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 593", "document order / paragraph 594", "document order / paragraph 595", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 2 / column 1"]} -->
1. 应提供数据有效性检验功能，对无效数据应给出简洁、准确的提示信息。
2. 应提供数据一致性校验机制。
3. 应能识别和屏蔽可能引起系统崩溃、异常退出的用户输入或用户误操作，并给出提示。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00345", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602205"></a>
## 8.5 **易用性**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00346", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801433"></a>
### 8.5.1 **易理解性**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00347", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 598"]} -->
系统易理解性管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00348", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 599", "document order / paragraph 600", "document order / paragraph 601", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 2 / column 1"]} -->
1. 应通过适当的术语、释义、图形、背景信息和操作帮助，协助用户理解和使用系统的各项功能。
2. 应对平台功能操作错误的原因和纠正信息加以提示。
3. 宜提供在线帮助。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00349", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801434"></a>
### 8.5.2 **易浏览性**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00350", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 603"]} -->
系统易浏览性管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00351", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 604", "document order / paragraph 605", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 49 / row 3 / column 1"]} -->
1. 应显示系统当前处理状态。
2. 应规范化设计屏幕提示、输入和输出。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00352", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602206"></a>
## 8.6 **运行环境**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00353", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801436"></a>
### 8.6.1 **机房要求**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00354", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 608"]} -->
机房管理应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00355", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 86", "document order / paragraph 115", "document order / paragraph 118", "document order / paragraph 529", "document order / paragraph 609", "document order / paragraph 610", "document order / paragraph 611", "document order / table 44 / row 2 / column 1"]} -->
1. 应满足《GB/T50311-2007综合布线系统工程设计规范》、《GB 2887-2011计算机场地通用规范》、《GB 50174-2008 电子信息系统机房设计规范》标准。
2. 应采用UPS不间断电源，UPS电源提供不低于2小时后备供电能力。UPS功率大小应根据设备功率进行计算，并留有30%的余量。
3. 宜设计物理屏障，通过门禁、安全制度等技术和管理措施保证机房环境物理安全性。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00356", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801437"></a>
### 8.6.2 **网络要求**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00357", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 613"]} -->
网络带宽应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00358", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 614", "document order / paragraph 615", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 49 / row 3 / column 1"]} -->
1. 接入互联网的独享带宽应不小于10Mbps。
2. 接入互联网的实际带宽应根据峰值流量进行计算确定。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00359", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 616"]} -->
网络安全应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00360", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 88", "document order / paragraph 617", "document order / paragraph 618", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 44 / row 4 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1"]} -->
1. 网络安全等级应通过《GB17859-1999 计算机信息系统安全保护等级划分准则》中第二级“系统审计保护级”的评测。
2. 网络安全等级宜通过《GB17859-1999 计算机信息系统安全保护等级划分准则》中第三级 “安全标记保护级”的评测。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00361", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801438"></a>
### 8.6.3 **主机要求**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00362", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
#### 8.6.3.1 **服务器要求**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00363", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 621"]} -->
服务器应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00364", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 529", "document order / paragraph 579", "document order / paragraph 586", "document order / paragraph 622", "document order / paragraph 623", "document order / paragraph 624", "document order / paragraph 632", "document order / table 44 / row 2 / column 1"]} -->
1. 应满足系统对可靠性、安全性和性能的要求。
2. 关键部件应采用冗余配置。
3. 服务器时间应与国家授时中心时间同步。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00365", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
#### 8.6.3.2 **主机安全要求**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00366", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 626"]} -->
主机安全应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00367", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 88", "document order / paragraph 627", "document order / paragraph 628", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 44 / row 4 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1"]} -->
1. 主机安全等级应通过《GB17859-1999 计算机信息系统安全保护等级划分准则》中第二级“系统审计保护级”的评测。
2. 主机安全等级宜通过《GB17859-1999 计算机信息系统安全保护等级划分准则》中第三级“安全标记保护级”的评测。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00368", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
#### 8.6.3.3 **存储要求**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00369", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 630"]} -->
存储应满足以下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00370", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 81", "document order / paragraph 587", "document order / paragraph 623", "document order / paragraph 631", "document order / paragraph 632", "document order / paragraph 633", "document order / paragraph 634", "document order / paragraph 635"]} -->
1. 宜采用独立磁盘存储设备进行核心数据存储。
2. 关键部件应采用冗余配置。
3. 应采用主流存储技术，实现存储设备的冗余和可靠接入，保证存储稳定性。
4. 应根据在线数据规模计算存储空间，并保留不少于20%的冗余。
5. 应具有扩展性，可按需增加存储空间，应对系统应用范围的扩展。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00371", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc262801439"></a>
### 8.6.4 **系统软件要求**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00372", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 637"]} -->
系统软件应满足如下要求：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00373", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 638", "document order / paragraph 639", "document order / paragraph 640", "document order / paragraph 641", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1"]} -->
1. 应用服务器和数据库服务器应物理分离。
2. 应支持主流数据库。
3. 宜支持集群部署，实现负载均衡。
4. 宜同时支持包括但不仅限于Unix、Linux、Windows等操作系统。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00374", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602207"></a>
# 9 **数据项的基本要求**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00375", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602208"></a>
## 9.1 **业务对象**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00376", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.1 **项目**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00377", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 1"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>项目编号</p></th><th></th><th><p>附录B.3.2项目编号</p></th><th><p>字符型</p></th><th><p>C..17</p></th></tr><tr><th><p>项目名称</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..200</p></th></tr><tr><th><p>项目所在行政区域代码</p></th><th></th><th><p>采用GB/T 2260-2007《中华人民共和国行政区划代码》的市级代码</p></th><th><p>字符型</p></th><th><p>C6</p></th></tr><tr><th><p>项目地址</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..200</p></th></tr><tr><th><p>项目法人</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>项目行业分类</p></th><th></th><th><p>GB/T 4754-2011，取1位行业门类字母码+2位大类数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>资金来源</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..1000</p></th></tr><tr><th><p>项目规模</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..1000</p></th></tr><tr><th><p>联系人</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>联系方式</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00378", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.2 **招标项目**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00379", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 2"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>项目编号</p></th><th></th><th><p>附录B.3.2项目编号</p></th><th><p>字符型</p></th><th><p>C17</p></th></tr><tr><th><p>招标项目编号</p></th><th></th><th><p>附录B.3.4招标项目编号</p></th><th><p>字符型</p></th><th><p>C20</p></th></tr><tr><th><p>招标项目名称</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>招标内容与范围及招标方案说明</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表中1-n个附件记录</p></th><th><p>附录B.3.7	附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>招标人</p><p>代码</p></th><th><p>组织机构代码</p></th><th><p>采用GB 11714-1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>招标代理机构代码</p></th><th><p>组织机构代码</p></th><th><p>采用GB 11714-1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>招标方式</p></th><th></th><th><p>附录B.3.8	招标方式代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>招标组织形式</p></th><th></th><th><p>附录B.3.3	招标组织形式代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>招标项目建立时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>监督部门代码</p></th><th></th><th><p>采用GB 11714-1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>监督部门名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>审核部门代码</p></th><th></th><th><p>采用GB 11714-1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>审核部门名称</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>交换公共服务平台标识码</p></th><th></th><th><p>附录B3.23公共服务平台标识代码</p></th><th><p>字符型</p></th><th><p>C10</p></th></tr><tr><th><p>申报责任人</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..100</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00380", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.3 **标段（包）**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00381", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 3"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>招标项目编号</p></th><th></th><th><p>附录B.3.4招标项目编号</p></th><th><p>字符型</p></th><th><p>C20</p></th></tr><tr><th><p>标段（包）编号</p></th><th><p>由招标项目编号和标段（包）序列号组成</p></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>标段（包）名称</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..200</p></th></tr><tr><th><p>标段（包）内容</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>标段（包）分类代码</p></th><th></th><th><p>附录B.3.6标段（包）分类代码</p></th><th><p>字符型</p></th><th><p>C7</p></th></tr><tr><th><p>标段合同估算价</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>标段合同估算价币种代码</p></th><th></th><th><p>采用GB/T 12406-2008《表示货币和资金的代码》的数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>标段合同估算价单位</p></th><th></th><th><p>附录B.3.25金额单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>投标人资格条件</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00382", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.4 **招标公告与资格预审公告**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00383", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 4"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>招标项目编号</p></th><th></th><th><p>附录B.3.4招标项目编号</p></th><th><p>字符型</p></th><th><p>C20</p></th></tr><tr><th><p>公告性质</p></th><th></th><th><p>附录B.3.9公告性质代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>公告类型</p></th><th></th><th><p>附录B.3.10公告类型代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>招标文件/资格预审文件获取时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>招标文件/资格预审文件获取方法</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>投标文件/资格预审申请文件递交截止时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>投标文件/资格预审申请文件递交方法</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>公告内容文本</p></th><th><p>应包括标段名称、标段编号及投标资格等信息</p></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>公告发布时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>公告附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>相关标段（包）编号</p></th><th><p>由多个标段（包）编号组成，半角分号隔开</p></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>公告结束日期</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>公告发布责任人</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>交易平台验证责任人</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>公告发布媒体</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..1000</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00384", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.5 **投标邀请书**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00385", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 5"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>投标资格</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>投标文件/资格预审申请文件获取时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>招标文件/资格预审文件获取方法</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>投标文件/资格预审申请文件递交截止时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>投标文件/资格预审申请文件递交方法</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>回复截止时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>投标邀请发出时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00386", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 267", "document order / paragraph 653", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 4 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 4 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 49 / row 4 / column 1"]} -->
### 9.1.6 **资格预审文件/资格预审文件澄清与修改**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00387", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 6"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>文件编号</p></th><th><p>资格预审文件/澄清与修改文件编号</p></th><th><p>附录B.3.11资格预审文件/招标文件/澄清与修改文件编号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>申请资格</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>申请有效期</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..200</p></th></tr><tr><th><p>申请文件递交截止时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>申请文件递交方法</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>文件开启时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>文件开启方式</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>评审办法</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>对文件澄清与修改的主要内容</p></th><th><p>文件修改的章节、条款等信息</p></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>递交时间</p></th><th><p>资格预审文件、澄清与修改文件的递交时间</p></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00388", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.7 **资格预审申请文件**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00389", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 7"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段(包)编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>申请人代码</p></th><th></th><th><p>采用GB11714-1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>投标资格条件</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>投标单位项目负责人</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>申请递交时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00390", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.8 **资格预审结果文件**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00391", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 8"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>通过资格预审的申请人名单</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>资格评审结果生成时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00392", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 656", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 4 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 4 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 49 / row 4 / column 1"]} -->
### 9.1.9 **招标文件/招标文件澄清与修改**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00393", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 9"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>文件编号</p></th><th><p>招标文件/澄清与修改文件编号</p></th><th><p>附录B.3.11资格预审文件/招标文件/澄清与修改文件编号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>投标资格</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>投标有效期</p></th><th><p>单位：天</p></th><th></th><th><p>数值型</p></th><th><p>N..3</p></th></tr><tr><th><p>投标文件递交截止时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>投标文件递交方法</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>投标保证金金额</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..10,2</p></th></tr><tr><th><p>投标保证金币种代码</p></th><th></th><th><p>采用GB/T 12406-2008《表示货币和资金的代码》的数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>投标保证金单位</p></th><th></th><th><p>附录B.3.25金额单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>评标办法</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>开标时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>开标方式</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>资格审查方式</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>答疑澄清时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>对文件澄清与修改的主要内容</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>递交时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00394", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.10 **现场踏勘通知**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00395", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 10"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>通知内容</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>通知发出时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00396", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.11 **现场踏勘记录**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00397", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 11"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>踏勘单位名称</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..200</p></th></tr><tr><th><p>踏勘单位代表姓名</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..200</p></th></tr><tr><th><p>踏勘时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00398", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.12 **投标文件**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00399", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 12"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>投标人代码</p></th><th><p>组织机构代码</p></th><th><p>采用GB11714-1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>投标文件附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>投标报价金额</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>投标报价币种代码</p></th><th></th><th><p>采用GB/T 12406-2008《表示货币和资金的代码》的数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>投标报价单位</p></th><th></th><th><p>附录B.3.25金额单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>工期（交货期）</p></th><th><p>单位：天</p></th><th></th><th><p>数值型</p></th><th><p>N..4</p></th></tr><tr><th><p>投标保证金形式</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>投标保证金金额</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>投标保证金币种代码</p></th><th></th><th><p>采用GB/T 12406-2008《表示货币和资金的代码》的数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>投标保证金单位</p></th><th></th><th><p>附录B.3.25金额单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>投标单位项目负责人</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>投标有效期</p></th><th><p>单位：天</p></th><th></th><th><p>数值型</p></th><th><p>N..3</p></th></tr><tr><th><p>投标时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>投标排序</p></th><th><p>按投标时间</p><p>排序</p></th><th></th><th><p>数值型</p></th><th><p>N..2</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00400", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.13 **投标保证金记录**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00401", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 13"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>投标人代码</p></th><th><p>组织机构代码</p></th><th><p>采用GB11714-1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>投标人名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>保证金支付形式</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>保证金金额</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>保证金币种代码</p></th><th></th><th><p>采用GB/T 12406-2008《表示货币和资金的代码》的数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>保证金单位</p></th><th></th><th><p>附录B.3.25金额单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>保证金凭证接收时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>保证金到账时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>保证金退还时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00402", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.14 **开标记录**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00403", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 14"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>开标参与人</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..500</p></th></tr><tr><th><p>开标记录内容</p></th><th><p>包括投标人名称、报价、工期（交货期）、投标保证金额、投标文件递交时间等招标文件所规定的唱标内容</p></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>开标时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00404", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.15 **评标报告**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00405", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 15"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>评标报告正文</p></th><th><p>包含中标候选人名称及排名、投标价格、评分结果或评标价格、中标价格等内容</p></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>评标报告各附件资料，关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>提交时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00406", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.16 **中标候选人**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00407", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 16"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>中标候选人名称</p></th><th><p>每个中标候选人一条记录</p></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>中标候选人代码</p></th><th></th><th><p>采用GB11714 -1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>中标候选人排名</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..10</p></th></tr><tr><th><p>投标价格</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>评分结果</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>评标价格</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>中标价格</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>价格币种代码</p></th><th></th><th><p>采用GB/T 12406-2008《表示货币和资金的代码》</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>价格单位</p></th><th></th><th><p>附录B.3.25金额单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00408", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 664"]} -->
注：每个中标候选人都应在此表中对应一条独立的数据记录。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00409", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.17 **中标候选人公示**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00410", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 17"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>公示类型</p></th><th></th><th><p>附录B.3.13公示类型代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>公示开始时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>公示结束时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>公示内容</p></th><th><p>多个中标候选人一并显示</p></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>公示提交时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00411", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.18 **中标/招标结果通知书**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00412", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 18"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>通知书类型</p></th><th></th><th><p>附录B.3.26通知书类型代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>中标/招标结果通知书编号</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>中标人/未中标人名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>中标人/未中标人代码</p></th><th></th><th><p>采用GB11714 -1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>中标/投标价格</p></th><th><p>对中标人，填入中标价格；对未中标人，填入投标价格</p></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>价格币种代码</p></th><th></th><th><p>采用GB/T 12406-2008《表示货币和资金的代码》的数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>价格单位</p></th><th></th><th><p>附录B.3.25金额单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>通知书文本</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>发出时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00413", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.19 **资格预审结果通知书**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00414", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 19"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>资格预审通过单位名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>资格预审通过单位代码</p></th><th></th><th><p>采用GB11714 -1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>通知书文本</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>发出时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00415", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.20 **合同和履行**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00416", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 20"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>招标人代码</p></th><th></th><th><p>采用GB11714 -1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>中标人代码</p></th><th></th><th><p>采用GB11714 -1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>合同金额</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>金额币种代码</p></th><th></th><th><p>采用GB/T 12406-2008《表示货币和资金的代码》的数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>金额单位</p></th><th></th><th><p>附录B.3.25金额单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>合同期限</p></th><th><p>单位：天</p></th><th></th><th><p>数值型</p></th><th><p>N..4</p></th></tr><tr><th><p>质量要求</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>合同主要内容</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>合同签署时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>合同结算金额</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>履约变更内容</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>合同完成时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>实际履约期限</p></th><th><p>单位：天</p></th><th></th><th><p>数值型</p></th><th><p>N..4</p></th></tr><tr><th><p>履约信息递交时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00417", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.21 **异议与投诉**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00418", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 21"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>异议或投诉人代码</p></th><th></th><th><p>采用GB11714 -1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>异议或投诉人名称</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>依据和理由</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>异议与投诉内容</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>提交时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>异议或投诉受理人</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..20</p></th></tr><tr><th><p>受理时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>处理结果</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>反馈时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00419", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.22 **招标异常情况报告**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00420", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 22"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>异常情况描述</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>提交时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>审批或核准结果</p></th><th><p>由招标项目表中描述的核准机构进行核准</p></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>审批或核准时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00421", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.23 **附件**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00422", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 23"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>附件关联标识号</p></th><th></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>上传时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>附件名称</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>附件内容</p></th><th></th><th></th><th><p>二进制型</p></th><th><p>BY</p></th></tr><tr><th><p>附件电子签名</p></th><th><p>无须电子签名的附件，此字段可忽略</p></th><th></th><th><p>二进制型</p></th><th><p>BY</p></th></tr><tr><th><p>签名证书的公钥</p></th><th><p>用于验证文件签名, 无须电子签名的附件，此字段可忽略</p></th><th></th><th><p>二进制型</p></th><th><p>BY</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00423", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.24 **开标签到**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00424", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 24"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>投标人名称</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>签到时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00425", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.25 **招标委托代理**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00426", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 25"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>招标项目编号</p></th><th></th><th><p>附录B.3.4招标项目编号</p></th><th><p>字符型</p></th><th><p>C20</p></th></tr><tr><th><p>招标代理机构代码</p></th><th><p>组织机构代码</p></th><th><p>采用GB11714 -1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>招标代理机构名称</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>招标代理资格分类代码</p></th><th></th><th><p>附录B.3.15资质代码</p></th><th><p>字符型</p></th><th><p>C6</p></th></tr><tr><th><p>招标代理资格分级代码</p></th><th></th><th><p>附录B.3.16资质等级代码</p></th><th><p>字符型</p></th><th><p>C6</p></th></tr><tr><th><p>招标代理内容与范围</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>招标代理权限</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>招标代理机构项目负责人信息</p></th><th><p>负责人姓名、职责权限及联系方式等</p></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00427", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.26 **招标项目计划**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00428", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 26"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>招标项目编号</p></th><th></th><th><p>附录B.3.4招标项目编号</p></th><th><p>字符型</p></th><th><p>C20</p></th></tr><tr><th><p>招标项目名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>相关标段（包）编号</p></th><th><p>由多个标段（包）编号组成，半角分号隔开</p></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>工作任务计划</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>项目团队成员组成与职责分工</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00429", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.27 **要求澄清的问题**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00430", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 27"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>文件编号</p></th><th><p>对应具体的资格预审文件/招标文件/澄清与修改文件</p></th><th><p>附录B.3.11资格预审文件/招标文件/澄清与修改文件编号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>要求澄清的问题</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>要求提交的时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>提交人代码</p></th><th></th><th><p>采用GB11714 -1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>提交人名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00431", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.28 **资格预审文件开启**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00432", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 28"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>开启参与单位名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..500</p></th></tr><tr><th><p>开启时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>开启内容</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00433", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.1.29 **中标结果公告**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00434", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 29"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>标段（包）名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..200</p></th></tr><tr><th><p>中标人名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>中标人代码</p></th><th></th><th><p>采用GB11714-1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>中标价格</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>价格币种代码</p></th><th></th><th><p>采用GB/T 12406-2008《表示货币和资金的代码》的数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>价格单位</p></th><th></th><th><p>附录B.3.25金额单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>其他说明</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..1000</p></th></tr><tr><th><p>附件关联标识号</p></th><th><p>关联到附件表的多条记录</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00435", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602209"></a>
## 9.2 **招投标主体**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00436", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.2.1 **招投标主体基本信息表**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00437", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 30"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>主体代码</p></th><th><p>采用组织机构代码</p></th><th><p>采用GB 11714-1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>主体名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>负责人</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>国别/地区</p></th><th><p>按国标编码</p></th><th><p>采用GB/T 2659-2000 中的3位数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>单位性质</p></th><th></th><th><p>GB/T 12402《经济类型分类与代码》。</p></th><th><p>字符型</p></th><th><p>C..20</p></th></tr><tr><th><p>行政区域代码</p></th><th></th><th><p>采用GB/T 2260-2007中的市级代码</p></th><th><p>字符型</p></th><th><p>C6</p></th></tr><tr><th><p>行业代码</p></th><th></th><th><p>采用GB/T 4754《国民经济行业分类》中的门类和大类</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>营业执照号码</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>CA证书编号</p></th><th><p>取CA证书的唯一编号</p></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>税务登记号</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>资信等级</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>开户银行</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>基本账户账号</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>注册资本</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>注册资本币种</p></th><th></th><th><p>采用GB/T 12406-2008《表示货币和资金的代码》的数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>注册资本单位</p></th><th></th><th><p>附录B.3.25价格单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>信息申报责任人</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>联系电话</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>联系地址</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>邮政编码</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C6</p></th></tr><tr><th><p>电子邮箱</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>主体类型</p></th><th><p>多个不同的主体类型用半角分号隔开</p></th><th><p>附录B.3.14主体角色类型代码</p></th><th><p>字符型</p></th><th><p>C..10</p></th></tr><tr><th><p>交易平台验证人员</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>交易平台验证时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00438", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.2.2 **主体经营资质信息表**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00439", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 31"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>主体代码</p></th><th><p>组织机构代码</p></th><th><p>采用GB11714 -1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>资质序列、行业和专业类别</p></th><th></th><th><p>附录B.3.15资质序列、行业和专业类别</p></th><th><p>字符型</p></th><th><p>C6</p></th></tr><tr><th><p>资质等级</p></th><th></th><th><p>附录B.3.16 资质等级代码</p></th><th><p>字符型</p></th><th><p>C2</p></th></tr><tr><th><p>资质证书编号</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>信息申报责任人</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00440", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 697", "document order / table 44 / row 3 / column 1", "document order / table 44 / row 4 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 48 / row 4 / column 1", "document order / table 49 / row 3 / column 1", "document order / table 49 / row 4 / column 1", "document order / table 50 / row 3 / column 1"]} -->
### 9.2.3 **招标人/招标代理机构电子招标业绩**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00441", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 32"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>招标人/招标代理机构代码</p></th><th><p>招标人/招标代理机构组织机构代码</p></th><th><p>采用GB11714 -1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>招标项目编号</p></th><th></th><th><p>附录B.3.4招标项目编号</p></th><th><p>字符型</p></th><th><p>C20</p></th></tr><tr><th><p>招标项目名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>招标人代码</p></th><th></th><th><p>采用GB11714 -1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>招标人名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>招标项目合同总金额</p></th><th></th><th></th><th></th><th></th></tr><tr><th><p>招标项目代理收费金额</p></th><th><p>仅招标代理机构需要填写</p></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>金额币种代码</p></th><th></th><th><p>采用GB/T 12406-2008《表示货币和资金的代码》的数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>金额单位</p></th><th></th><th><p>附录B.3.25价格单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>招标项目合同签署时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00442", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 698"]} -->
注：业绩仅限于在电子招投标交易平台上成交的项目。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00443", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.2.4 **职业人员基本信息**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00444", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 33"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>职业人员代码</p></th><th><p>取身份证号码</p></th><th><p>采用GB 11643－1999《公民身份号码》</p></th><th><p>字符型</p></th><th><p>C18</p></th></tr><tr><th><p>姓名</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>性别</p></th><th></th><th><p>采用GB/T 2261.1-2003《个人基本信息分类与代码 第1部分 人的性别代码》</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>出生年月</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDD</p></th></tr><tr><th><p>所在行政区域代码</p></th><th><p> </p></th><th><p>采用GB/T 2260-2007《中华人民共和国行政区划代码》的市级代码</p></th><th><p>字符型</p></th><th><p>C6</p></th></tr><tr><th><p>最高学历</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>联系电话</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>通讯地址</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>邮政编码</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C6</p></th></tr><tr><th><p>所在单位代码</p></th><th></th><th><p>采用GB 11714-1997《全国组织机构代码编制规则》</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>所在单位名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>是否在职</p></th><th></th><th><p>附录B.3.12是否代码</p></th><th><p>字符型</p></th><th><p>C..10</p></th></tr><tr><th><p>职务</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>技术职称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>从业经历</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>从业年限</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..2</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00445", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.2.5 **人员职业资格信息**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00446", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 34"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>职业人员代码</p></th><th></th><th><p>采用GB 11643－1999《公民身份号码》</p></th><th><p>字符型</p></th><th><p>C18</p></th></tr><tr><th><p>职业资格序列</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>职业资格等级</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>资格资格证书编号</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>注册登记证书编号</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00447", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.2.6 **人员业绩信息**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00448", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 35"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>职业人员代码</p></th><th></th><th><p>采用GB 11643－1999《公民身份号码》</p></th><th><p>字符型</p></th><th><p>C18</p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>标段（包）名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>招标人代码</p></th><th></th><th><p>采用GB 11714-1997中的代码编制规则</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>招标人名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>合同金额</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>结算金额</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>金额币种代码</p></th><th></th><th><p>采用GB/T 12406-2008中的数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>金额单位</p></th><th></th><th><p>附录B.3.25价格单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>合同签署时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>合同完成时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00449", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 702", "document order / paragraph 705"]} -->
备注：业绩仅限于在电子招投标交易平台上成交的项目。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00450", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.2.7 **投标人业绩**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00451", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 36"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>投标人代码</p></th><th><p>组织机构代码</p></th><th><p>采用GB 11714-1997中的代码编制规则</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>中标项目的标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>中标项目和标段（包）名称</p></th><th><p>按照招标项目和标段（包）的名称</p></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>招标人代码</p></th><th><p>组织机构代码</p></th><th><p>采用GB 11714-1997中的代码编制规则</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>招标人名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>中标金额</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>合同金额</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>合同结算金额</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..20,2</p></th></tr><tr><th><p>合同期限</p></th><th><p>单位：天</p></th><th></th><th><p>数值型</p></th><th><p>N..4</p></th></tr><tr><th><p>实际履行期限</p></th><th><p>单位：天</p></th><th></th><th><p>数值型</p></th><th><p>N..4</p></th></tr><tr><th><p>金额币种代码</p></th><th></th><th><p>采用GB/T 12406-2008中的数字码</p></th><th><p>字符型</p></th><th><p>C3</p></th></tr><tr><th><p>金额单位</p></th><th></th><th><p>附录B.3.25价格单位代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>合同签署时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00452", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 702", "document order / paragraph 705"]} -->
备注：业绩仅限于在电子招投标交易平台上成交的项目。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00453", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.2.8 **奖惩记录**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00454", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 37"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>奖惩对象代码</p></th><th><p>单位取组织机构代码；个人取身份证号码</p></th><th><p>采用GB 11714-1997中的代码编制规则和GB 11643－1999《公民身份号码》</p></th><th><p>字符型</p></th><th><p>C..18</p></th></tr><tr><th><p>奖惩对象类型</p></th><th></th><th><p>附录B.3.18奖惩对象类型代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>奖惩时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>奖惩内容</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>奖惩类型</p></th><th></th><th><p>附录B.3.19奖惩类型代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00455", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 708", "document order / table 44 / row 3 / column 1", "document order / table 44 / row 4 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 48 / row 4 / column 1", "document order / table 49 / row 3 / column 1"]} -->
### 9.2.9 **资格审查委员会/评标委员会组建申请**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00456", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 38"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>组建申请编号</p></th><th></th><th><p>附录B.3.22评标委员会组建申请编号</p></th><th><p>字符型</p></th><th><p>C..20</p></th></tr><tr><th><p>标段（包）编号</p></th><th></th><th><p>附录B.3.5标段（包）编号</p></th><th><p>字符型</p></th><th><p>C23</p></th></tr><tr><th><p>专家库名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..500</p></th></tr><tr><th><p>专家抽取要求</p></th><th><p>包含专业分类代码、行政区域代码、专家人数、专家等级、回避条件等抽取说明</p></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>评审时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>评审地点</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>抽取时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>抽取人姓名</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00457", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 710", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 44 / row 4 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1"]} -->
### 9.2.10 **资格审查委员会/评标委员会成员**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00458", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 39"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>组建申请编号</p></th><th></th><th><p>附录B.3.20评标委员会组建申请编号</p></th><th><p>字符型</p></th><th><p>C..20</p></th></tr><tr><th><p>专家编号</p></th><th><p>如果是专家库成员，需要有此编号</p></th><th><p>附录B.3.22专家编号</p></th><th><p>字符型</p></th><th><p>C17</p></th></tr><tr><th><p>专家姓名</p></th><th><p>如果是招标人代表，填入姓名</p></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>专家类型</p></th><th></th><th><p>附录B.3.21专家类型代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>通知方式</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>通知时间</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDDhhmmss</p></th></tr><tr><th><p>专家考核记录</p></th><th></th><th><p>自由文本</p></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00459", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 9.2.11 **评标专家**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00460", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 40"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>专家编号</p></th><th></th><th><p>附录B.3.22专家编号</p></th><th><p>字符型</p></th><th><p>C17</p></th></tr><tr><th><p>姓名</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>性别</p></th><th></th><th><p>采用GB/T 2261.1-2003中人的性别代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>身份证件类型</p></th><th></th><th><p>附录B.3.16身份证件类型代码</p></th><th><p>字符型</p></th><th><p>C2</p></th></tr><tr><th><p>身份证件号码</p></th><th></th><th><p>采用GB 11643－1999《公民身份号码》</p></th><th><p>字符型</p></th><th><p>C18</p></th></tr><tr><th><p>出生年月</p></th><th></th><th></th><th><p>日期时间型</p></th><th><p>YYYYMMDD</p></th></tr><tr><th><p>所在行政区域代码</p></th><th><p> </p></th><th><p>采用GB/T 2260-2007中的市级代码</p></th><th><p>字符型</p></th><th><p>C6</p></th></tr><tr><th><p>最后毕业院校</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>最高学历</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..30</p></th></tr><tr><th><p>联系电话</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>通讯地址</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>邮政编码</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C6</p></th></tr><tr><th><p>所在单位名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>是否在职</p></th><th></th><th><p>附录B.3.12是否代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>职务</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>工作简历</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..ul</p></th></tr><tr><th><p>专业分类</p></th><th></th><th><p>采用《评标专家专业分类标准（试行）》中约定的代码</p></th><th><p>字符型</p></th><th><p>C6</p></th></tr><tr><th><p>技术职称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>职业资格序列</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>职业资格等级</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>从业年限</p></th><th></th><th></th><th><p>数值型</p></th><th><p>N..2</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00461", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602210"></a>
## 9.3 **交易平台或公共服务平台**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00462", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 41"]} -->
<table><thead><tr><th><p><strong>名称</strong></p></th><th><p><strong>说明</strong></p></th><th><p><strong>值域</strong></p></th><th><p><strong>数据</strong></p><p><strong>类型</strong></p></th><th><p><strong>数据</strong></p><p><strong>格式</strong></p></th></tr><tr><th><p>交易平台或公共服务平台代码</p></th><th></th><th><p>附录B.3.1交易平台标识代码；</p><p>附录B.3.23公共服务平台标识代码</p></th><th><p>字符型</p></th><th><p>C11</p></th></tr><tr><th><p>平台类型</p></th><th></th><th><p>附录B.3.24平台类型代码</p></th><th><p>字符型</p></th><th><p>C1</p></th></tr><tr><th><p>平台名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>运营机构代码</p></th><th></th><th><p>采用GB 11714-1997中的代码编制规则</p></th><th><p>字符型</p></th><th><p>C9</p></th></tr><tr><th><p>运营机构名称</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..100</p></th></tr><tr><th><p>CA证书编号</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..50</p></th></tr><tr><th><p>系统访问地址</p></th><th></th><th></th><th><p>字符型</p></th><th><p>C..200</p></th></tr><tr><th><p>检测和认证报告附件关联标识号</p></th><th><p>关联到附件表</p></th><th><p>附录B.3.7附件关联标识号</p></th><th><p>字符型</p></th><th><p>C..50</p></th></tr></thead></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00463", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602211"></a>
## 9.4 **数据项术语说明**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00464", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc121213891"></a>
### 9.4.1 **值域**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00465", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 718"]} -->
值域是指数据项的有效取值范围。一般分为自由文本型、枚举型、代码型等。自由文本型表示没有特别规定的内容类型；枚举型指元数据元素有可枚举的取值；代码型指元数据元素能对应到某个代码表的代码列或名称列。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00466", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc121213889"></a>
### 9.4.2 **数据类型和数据格式**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00467", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 720"]} -->
数据项允许值的数据类型及表示格式。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00468", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 42"]} -->
<table><tr><td><p><strong>数据类型</strong></p></td><td><p><strong>说明</strong></p></td><td><p><strong>数据格式</strong></p></td></tr><tr><td><p>字符型</p></td><td><p>一切可以显示打印的字符，包括汉字、字母、数字、各种符号、空格等，不具有计算能力。</p></td><td><p>以大写字母“C”代表字符型：</p><p>CX:表示定长为“X”的字符型数据元值；</p><p>C..X:表示最长为“X”的字符型数据元值；</p><p>C..ul:表示长度不确定的字符型数据元值。</p></td></tr><tr><td><p>数值型</p></td><td><p>可以进行数学运算的数据。</p></td><td><p>以大写字母“N”代表数值型：</p><p>N..X:表示最长为“X”的数值型数据元值；</p><p>N..X,y:表示总长度为“X”位、其中小数点后为“y”位的数值型数据元值。</p></td></tr><tr><td><p>日期时间型</p></td><td><p>用以表示日期及时间的数据。</p></td><td><p>采用GB/T 7408《数据元和交换格式 信息交换 日期和时间表示法》的规定。</p></td></tr><tr><td><p>二进制型</p></td><td><p>图象、音频、视频等二进制数据。</p></td><td><p>以大写字母“BY”代表二进制型：</p><p>BY-X:表示媒体格式为“X”的二进制型数据元值。</p></td></tr><tr><td><p>布尔型</p></td><td><p>两个且只有两个表明条件的值，如On/Off、True/False。</p></td><td><p>以大写字母“B”代表布尔型。</p></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00469", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602212"></a>
# 10 **编码总体规则**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00470", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602213"></a>
## 10.1 **编码总体规则说明**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00471", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 724"]} -->
<a id="_Toc535137015"></a>
信息分类与编码是建设电子招标投标系统不可或缺的部分，是支撑电子招标投标系统信息交换、共享的主要技术手段。电子招标投标信息分类与编码主要用于表示数据项的值域。当数据项是代码型数据项时，其值域指向了相应的信息分类与编码信息，如果有相应的国家标准，则优先采用国家标准信息。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00472", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 725"]} -->
用于电子招标投标系统建设信息分类和编码的基本原则有：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00473", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 726"]} -->
实用性：在对事物或概念进行分类编码时，既要保证科学合理，又要立足于电子招标投标的实际管理需求，满足电子招标投标业务管理和电子招标投标系统建设的需求。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00474", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 727"]} -->
稳定性：宜选择事物或概念相对稳定的属性或特征作为分类依据，代码不宜频繁变动和修改，以避免造成人、财、物的浪费。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00475", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 728"]} -->
<a id="_Toc535137017"></a>
唯一性：在一个分类编码标准中，一个编码对象只能有一个代码，一个代码只能唯一表示一个编码对象，即编码对象与代码间是一一对应的关系。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00476", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 729"]} -->
可扩展性：在进行分类编码时，通常要设置收容类目（其他类），为新增加的编码对象留有足够的可扩充的备用码，以保证增加新的事物或概念时，不必打乱已建立的分类体系。同时，还应为分类的进一步延拓细化创造条件，并充分考虑电子招标投标改革与可持续发展的需要。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00477", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 730"]} -->
<a id="_Toc535137018"></a>
兼容性：应与相关的国家标准及相关行业标准协调一致。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00478", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 731"]} -->
电子招标投标系统建设用信息编码的常用方法包括：顺序码、缩写码、层次码、组合码。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00479", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 732"]} -->
依据信息分类编码标准化的一般要求，结合电子招标投标系统建设的实际需要和特点，电子招标投标信息分类与编码信息主要通过2个属性来描述：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00480", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 733", "document order / paragraph 734", "document order / table 43 / row 1 / column 1", "document order / table 44 / row 1 / column 1", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 1 / column 1", "document order / table 48 / row 2 / column 1"]} -->
1. 编码规则：描述代码的分类原则和编码方法。
2. 码值：代码对应的代码表。代码表有3个字段，“名

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00481", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 735"]} -->
称”字段表示编码对象的中文名称；“代码”字段表示编码对象的代码，可以是数字码、字母码或数字字母混合码；“说明”字段表示需要特殊说明的内容。其中，“名称”和“代码”是必选字段，“说明”是可选字段。如下表所示：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00482", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 43"]} -->
<table><tr><td><p>代码</p></td><td><p>名称</p></td><td><p>说明</p></td></tr><tr><td></td><td></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00483", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602214"></a>
## 10.2 **通用编码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00484", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 738"]} -->
本技术规范中引用到的信息分类编码国家标准包括：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00485", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 87", "document order / paragraph 95", "document order / paragraph 97", "document order / paragraph 98", "document order / paragraph 99", "document order / paragraph 119", "document order / paragraph 123", "document order / paragraph 324"]} -->
1. GB/T 4754-2011 国民经济行业分类
2. GB 11714-1997 全国组织机构代码编制规则
3. GB/T 12406-2008 表示货币和资金的代码
4. GB/T 2659-2000 世界各国和地区名称代码
5. GB/T 2260-2007 中华人民共和国行政区划代码
6. GB 11643－1999公民身份号码
7. GB/T 2261.1-2003个人基本信息分类与代码 第1部分：人的性别代码
8. 评标专家专业分类标准（试行）（发改法规[2010]1538号）

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00486", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
<a id="_Toc347602215"></a>
## 10.3 **业务编码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00487", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 749"]} -->
结合数据项中的有关代码字段（在值域中有相关描述）进行编码说明。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00488", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.1 **交易平台标识代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00489", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 751"]} -->
编码规则：采用组合码，编码长度为11位。排列顺序从左至右依次为：1位行业门类字母码、6位行政区域代码，以及4位全国交易平台序列号。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00490", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 752"]} -->
其中行业门类字母码采用《GB/T 4754-2011 国民经济行业分类GB/T 4754 国民经济行业分类》的门类。行政区域代码采用《GB/T 2260-2007 中华人民共和国行政区划代码GB/T 2260 中华人民共和国行政区划代码》的6位数字码。全国交易平台序列号的取值从0001-9999，按照其在国家公共服务平台注册登记或交换登记信息时间排序。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00491", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.2 **项目编号**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00492", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 754"]} -->
编码规则：采用组合码，编码长度为17位。排列顺序从左至右依次为：前11位由交易平台标识代码组成，后6位由项目序列号组成，项目序列号的取值从000001-999999。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00493", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.3 **招标组织形式代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00494", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 756", "document order / paragraph 774", "document order / paragraph 777", "document order / paragraph 785"]} -->
编码规则：采用1位顺序码表示。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00495", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00496", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 44"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>1</p></td><td><p>自行招标</p></td><td></td></tr><tr><td><p>2</p></td><td><p>委托招标</p></td><td></td></tr><tr><td><p>9</p></td><td><p>其他</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00497", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.4 **招标项目编号**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00498", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 759"]} -->
编码规则：采用组合码，编码长度为20位。排列顺序从左至右依次为：前17位由项目编号组成，后3位由招标项目在项目中的序列号组成，招标项目序列号的取值从001-999。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00499", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.5 **标段（包）编号**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00500", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 761"]} -->
编码规则：采用组合码，编码长度为23位。排列顺序从左至右依次为：前20位由招标项目编号组成，后3位由标段（包）在招标项目中的序列号组成，标段（包）序列号的取值从001-999。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00501", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.6 **标段（包）分类代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00502", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 763"]} -->
编码规则：采用组合码，编码长度7位。此编码参考了《评标专家专业分类标准（试行）》（发改法规[2010]1538号），并在此基础上进行了扩展，排列顺序从左至右依次为：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00503", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 764"]} -->
（1）第一级1位，A -工程、B-货物、C-服务、D-产权、E-土地；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00504", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 765"]} -->
（2）第二级2位，对应《评标专家专业分类标准》中的一级类别;

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00505", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 45"]} -->
<table><tr><td><p><strong>一级类别</strong></p></td><td><p><strong>二级类别</strong></p></td></tr><tr><td><p>A-工程</p></td><td><p>01 规划</p><p>02 投资策划与决策</p><p>03 勘察</p><p>04 设计</p><p>05 监理</p><p>06 工程造价</p><p>07 项目管理(含代建)</p><p>08 工程施工</p><p>09 其他工程</p></td></tr><tr><td><p>B-货物</p></td><td><p>01 机械、设备类</p><p>02 医疗器械</p><p>03 金属材料</p><p>04 石油及其制品</p><p>05 煤炭煤层气及其制品</p><p>06 化工材料及其制品</p><p>07 建筑材料</p><p>08 药品</p><p>其他 ……</p></td></tr><tr><td><p>C-服务</p></td><td><p>01 勘查与调查</p><p>02 公共咨询</p><p>03 经济管理</p><p>04 工商管理</p><p>05 金融</p><p>06 法律</p><p>07 修理</p><p>08 租赁</p><p>09 交通运输与物流</p><p>10 节能服务</p><p>11 高新技术服务</p><p>12 其他服务</p><p>13 招标代理服务（备注：新增）</p></td></tr><tr><td><p>D-产权</p></td><td><p>另行制定</p></td></tr><tr><td><p>E-土地</p></td><td><p>另行制定</p></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00506", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 766"]} -->
（3）第三级2位，对应《评标专家专业分类标准》的二级类别，并新增以下类别：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00507", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 46"]} -->
<table><tr><td><p><strong>一级</strong></p><p><strong>类别</strong></p></td><td><p><strong>二级类别</strong></p></td><td><p><strong>三级类别</strong></p></td></tr><tr><td><p>C-服务</p></td><td><p>13 招标代理服务</p></td><td><p>01 工程类代理</p><p>02 货物类代理</p><p>03 服务类代理</p><p>04 产权类代理</p><p>05 土地类代理</p></td></tr><tr><td><p>D-产权</p></td><td><p>另行制定</p></td><td><p>另行制定</p></td></tr><tr><td><p>E-土地</p></td><td><p>另行制定</p></td><td><p>另行制定</p></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00508", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 767"]} -->
（4）第四级2位，对应《评标专家专业分类标准》的三级类别，如果没有四级类别可以使用00补充，例如：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00509", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 47"]} -->
<table><tr><td><p><strong>一级</strong></p><p><strong>类别</strong></p></td><td><p><strong>二级类别</strong></p></td><td><p><strong>三级类别</strong></p></td><td><p><strong>四级类别</strong></p></td></tr><tr><td><p>C-服务</p></td><td><p>13 招标代理服务</p></td><td><p>01 工程类代理</p><p>02 货物类代理</p><p>03 服务类代理</p><p>04 产权类代理</p><p>05 土地类代理</p></td><td><p>01中央投资项目</p><p>02 政府采购项目</p><p>03机电国际招标项目</p><p>04 通讯建设项目</p><p>05 其他</p><p>如果没有四级类别，可以用00补足</p></td></tr><tr><td><p>D-产权</p></td><td><p>另行制定</p></td><td><p>另行制定</p></td><td><p>另行制定</p></td></tr><tr><td><p>E-土地</p></td><td><p>另行制定</p></td><td><p>另行制定</p></td><td><p>另行制定</p></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00510", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.7 **附件关联标识号**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00511", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 769", "document order / paragraph 810"]} -->
编码规则：采用全球唯一标识符（GUID）表示，格式为“xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx”，其中每个 x 是 0-9 或 a-f 范围内的一个32位十六进制数。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00512", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.8 **招标方式代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00513", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 771", "document order / paragraph 782", "document order / paragraph 804", "document order / paragraph 812", "document order / paragraph 823", "document order / paragraph 826"]} -->
编码规则：采用1位顺序码。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00514", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00515", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 48"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>1</p></td><td><p>公开招标</p></td><td></td></tr><tr><td><p>2</p></td><td><p>邀请招标</p></td><td></td></tr><tr><td><p>9</p></td><td><p>其它</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00516", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.9 公告性质代码

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00517", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 756", "document order / paragraph 774", "document order / paragraph 777", "document order / paragraph 785"]} -->
编码规则：采用1位顺序码表示。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00518", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00519", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 49"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>1</p></td><td><p>正常公告</p></td><td></td></tr><tr><td><p>2</p></td><td><p>更正公告</p></td><td></td></tr><tr><td><p>9</p></td><td><p>其他</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00520", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.10 **公告类型代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00521", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 756", "document order / paragraph 774", "document order / paragraph 777", "document order / paragraph 785"]} -->
编码规则：采用1位顺序码表示。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00522", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00523", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 50"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>1</p></td><td><p>招标公告</p></td><td></td></tr><tr><td><p>2</p></td><td><p>资格预审公告</p></td><td></td></tr><tr><td><p>9</p></td><td><p>其他</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00524", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 267", "document order / paragraph 277", "document order / table 6 / row 3 / column 1", "document order / table 9 / row 3 / column 1", "document order / table 9 / row 3 / column 2", "document order / table 27 / row 3 / column 1", "document order / table 44 / row 2 / column 1"]} -->
### 10.3.11 **资格预审文件/招标文件/澄清与修改文件编号**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00525", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 780"]} -->
编码规则：采用组合码，编码长度为26位。排列顺序从左至右依次为：前23位由标段（包）编号组成；1位表示文件类型，Y表示资格预审文件，Z表示招标文件， 2位表示文件版本号，资格预审文件/招标文件从01开始编号，此后的答疑澄清与修改文件每次版本号递增1，取值范围从01-99。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00526", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.12 **是否代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00527", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 771", "document order / paragraph 782", "document order / paragraph 804", "document order / paragraph 812", "document order / paragraph 823", "document order / paragraph 826"]} -->
编码规则：采用1位顺序码。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00528", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00529", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 51"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>0</p></td><td><p>否</p></td><td></td></tr><tr><td><p>1</p></td><td><p>是</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00530", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.13 **公示类型代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00531", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 756", "document order / paragraph 774", "document order / paragraph 777", "document order / paragraph 785"]} -->
编码规则：采用1位顺序码表示。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00532", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00533", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 52"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>1</p></td><td><p>正常</p></td><td></td></tr><tr><td><p>2</p></td><td><p>更正</p></td><td></td></tr><tr><td><p>9</p></td><td><p>其他</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00534", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.14 **主体角色类型代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00535", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 789"]} -->
编码规则：用1位字母码表示。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00536", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00537", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 53"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>T</p></td><td><p>招标人</p></td><td></td></tr><tr><td><p>B</p></td><td><p>投标人</p></td><td></td></tr><tr><td><p>A</p></td><td><p>招标代理机构</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00538", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / table 31 / row 3 / column 1", "document order / table 43 / row 1 / column 1", "document order / table 44 / row 1 / column 1", "document order / table 44 / row 2 / column 1", "document order / table 48 / row 1 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 49 / row 1 / column 1", "document order / table 49 / row 2 / column 1"]} -->
### 10.3.15 **资质序列、行业和专业类别代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00539", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 792"]} -->
编码规则：用6位数字层次码表示。第一层1、2两位表示资质序列；第二层3、4两位表示行业分类，00表示不分行业；第三层5、6位表示专业类别，00表示不分专业类别。各层次的资质编码均按有关部门颁发的资质标准排序。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00540", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 793"]} -->
1、第一层（1-2位）资质序列：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00541", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 54"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>01</p></td><td><p>工程咨询</p></td><td></td></tr><tr><td><p>02</p></td><td><p>工程规划</p></td><td></td></tr><tr><td><p>03</p></td><td><p>工程勘察</p></td><td></td></tr><tr><td><p>04</p></td><td><p>工程设计</p></td><td></td></tr><tr><td><p>05</p></td><td><p>施工总承包</p></td><td></td></tr><tr><td><p>06</p></td><td><p>施工专业分包</p></td><td></td></tr><tr><td><p>07</p></td><td><p>施工劳务分包</p></td><td></td></tr><tr><td><p>08</p></td><td><p>工程监理</p></td><td></td></tr><tr><td><p>09</p></td><td><p>招标代理</p></td><td></td></tr><tr><td><p>10</p></td><td><p>工程造价</p></td><td></td></tr><tr><td><p>11</p></td><td><p>工程检测</p></td><td></td></tr><tr><td><p>12</p></td><td><p>房地产开发</p></td><td></td></tr><tr><td><p>13</p></td><td><p>房地产评估</p></td><td></td></tr><tr><td><p>14</p></td><td><p>拆迁</p></td><td></td></tr><tr><td><p>15</p></td><td><p>园林</p></td><td></td></tr><tr><td><p>16</p></td><td><p>设计施工一体化</p></td><td></td></tr><tr><td><p>…99</p></td><td><p>其他</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00542", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 794"]} -->
2、第二层（3-4位）资质行业：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00543", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 55"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>00</p></td><td><p>不分行业</p></td><td><p>如果资质没有行业区分，第二层编码就使用00。</p></td></tr><tr><td><p>01</p></td><td><p>房屋建筑</p></td><td></td></tr><tr><td><p>02</p></td><td><p>公路</p></td><td></td></tr><tr><td><p>03</p></td><td><p>铁路</p></td><td></td></tr><tr><td><p>04</p></td><td><p>港口与航道</p></td><td></td></tr><tr><td><p>05</p></td><td><p>水利水电</p></td><td></td></tr><tr><td><p>06</p></td><td><p>电力</p></td><td></td></tr><tr><td><p>07</p></td><td><p>矿山</p></td><td></td></tr><tr><td><p>08</p></td><td><p>冶炼</p></td><td></td></tr><tr><td><p>09</p></td><td><p>化工石油</p></td><td></td></tr><tr><td><p>10</p></td><td><p>市政公用</p></td><td></td></tr><tr><td><p>11</p></td><td><p>通信</p></td><td></td></tr><tr><td><p>12</p></td><td><p>机电安装</p></td><td></td></tr><tr><td><p>…99</p></td><td><p>其他</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00544", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 795"]} -->
3、第三层（5-6位）资质专业：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00545", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 56"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>00</p></td><td><p>不分专业</p></td><td><p>如果没有专业区分，第三层编码就使用00。</p></td></tr><tr><td><p>01</p></td><td><p>地基与基础工程</p></td><td></td></tr><tr><td><p>02</p></td><td><p>土石方工程</p></td><td></td></tr><tr><td><p>03</p></td><td><p>建筑装修装饰</p></td><td></td></tr><tr><td><p>04</p></td><td><p>建筑幕墙工程</p></td><td></td></tr><tr><td><p>05</p></td><td><p>预拌商品混凝土</p></td><td></td></tr><tr><td><p>06</p></td><td><p>混凝土预制构件</p></td><td></td></tr><tr><td><p>07</p></td><td><p>园林古建筑工程</p></td><td></td></tr><tr><td><p>08</p></td><td><p>钢结构工程</p></td><td></td></tr><tr><td><p>09</p></td><td><p>高耸构筑物工程</p></td><td></td></tr><tr><td><p>10</p></td><td><p>电梯安装工程</p></td><td></td></tr><tr><td><p>11</p></td><td><p>消防设施工程</p></td><td></td></tr><tr><td><p>12</p></td><td><p>建筑防水工程</p></td><td></td></tr><tr><td><p>13</p></td><td><p>防腐保温工程</p></td><td></td></tr><tr><td><p>14</p></td><td><p>附着升降脚手架</p></td><td></td></tr><tr><td><p>15</p></td><td><p>金属门窗工程</p></td><td></td></tr><tr><td><p>16</p></td><td><p>预应力工程</p></td><td></td></tr><tr><td><p>17</p></td><td><p>起重设备安装工程</p></td><td></td></tr><tr><td><p>18</p></td><td><p>机电设备安装工程</p></td><td></td></tr><tr><td><p>19</p></td><td><p>爆破与拆除工程</p></td><td></td></tr><tr><td><p>20</p></td><td><p>建筑智能化工程</p></td><td></td></tr><tr><td><p>21</p></td><td><p>环保工程</p></td><td></td></tr><tr><td><p>22</p></td><td><p>电信工程</p></td><td></td></tr><tr><td><p>23</p></td><td><p>电子工程</p></td><td></td></tr><tr><td><p>24</p></td><td><p>桥梁工程</p></td><td></td></tr><tr><td><p>25</p></td><td><p>隧道工程</p></td><td></td></tr><tr><td><p>26</p></td><td><p>公路路面工程</p></td><td></td></tr><tr><td><p>27</p></td><td><p>公路路基工程</p></td><td></td></tr><tr><td><p>28</p></td><td><p>公路交通工程</p></td><td></td></tr><tr><td><p>29</p></td><td><p>铁路电务工程</p></td><td></td></tr><tr><td><p>30</p></td><td><p>铁路铺轨架梁工程</p></td><td></td></tr><tr><td><p>31</p></td><td><p>铁路电气化工程</p></td><td></td></tr><tr><td><p>32</p></td><td><p>机场场道工程</p></td><td></td></tr><tr><td><p>33</p></td><td><p>机场空管工程及航站楼弱电系统工程</p></td><td></td></tr><tr><td><p>34</p></td><td><p>机场目视助航工程</p></td><td></td></tr><tr><td><p>35</p></td><td><p>港口与海岸工程</p></td><td></td></tr><tr><td><p>36</p></td><td><p>港口装卸设备安装工程</p></td><td></td></tr><tr><td><p>37</p></td><td><p>航道工程</p></td><td></td></tr><tr><td><p>38</p></td><td><p>通航建筑工程</p></td><td></td></tr><tr><td><p>39</p></td><td><p>通航设备安装工程</p></td><td></td></tr><tr><td><p>40</p></td><td><p>水上交通管制工程</p></td><td></td></tr><tr><td><p>41</p></td><td><p>水工建筑物基础处理工程</p></td><td></td></tr><tr><td><p>42</p></td><td><p>水工金属结构制作与安装工程</p></td><td></td></tr><tr><td><p>43</p></td><td><p>水利水电机电设备安装工程</p></td><td></td></tr><tr><td><p>44</p></td><td><p>河湖整治工程</p></td><td></td></tr><tr><td><p>45</p></td><td><p>堤防工程</p></td><td></td></tr><tr><td><p>46</p></td><td><p>水工大坝工程</p></td><td></td></tr><tr><td><p>47</p></td><td><p>水工隧洞工程</p></td><td></td></tr><tr><td><p>48</p></td><td><p>火电设备安装工程</p></td><td></td></tr><tr><td><p>49</p></td><td><p>送变电工程</p></td><td></td></tr><tr><td><p>50</p></td><td><p>核工程</p></td><td></td></tr><tr><td><p>51</p></td><td><p>炉窑工程</p></td><td></td></tr><tr><td><p>52</p></td><td><p>冶炼机电设备安装工程</p></td><td></td></tr><tr><td><p>53</p></td><td><p>化工石油设备管道安装工程</p></td><td></td></tr><tr><td><p>54</p></td><td><p>管道工程</p></td><td></td></tr><tr><td><p>55</p></td><td><p>无损检测</p></td><td></td></tr><tr><td><p>56</p></td><td><p>海洋石油工程</p></td><td></td></tr><tr><td><p>57</p></td><td><p>城市轨道交通工程</p></td><td></td></tr><tr><td><p>58</p></td><td><p>城市及道路照明工程</p></td><td></td></tr><tr><td><p>59</p></td><td><p>体育场地设施工程</p></td><td></td></tr><tr><td><p>60</p></td><td><p>特种专业工程</p></td><td></td></tr><tr><td><p>61</p></td><td><p>工程建设项目招标代理</p></td><td></td></tr><tr><td><p>62</p></td><td><p>中央投资项目招标代理</p></td><td></td></tr><tr><td><p>63</p></td><td><p>政府采购招标代理</p></td><td></td></tr><tr><td><p>64</p></td><td><p>机电产品国际招标代理</p></td><td></td></tr><tr><td><p>65</p></td><td><p>通讯建设项目招标代理</p></td><td></td></tr><tr><td></td><td><p>…</p></td><td></td></tr><tr><td><p>99 </p></td><td><p>其他</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00546", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 796"]} -->
例如：房屋建筑工程施工总承包企业资质对应的代码是050100（05-施工总承包序列；01-房屋建筑行业；00-不分专业）；工程建设项目招标代理资格的代码是090061。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00547", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.16 **资质等级代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00548", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 798"]} -->
编码规则：采用2位顺序码表示。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00549", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00550", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 57"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>01</p></td><td><p>特级</p></td><td></td></tr><tr><td><p>02</p></td><td><p>一级</p></td><td></td></tr><tr><td><p>03</p></td><td><p>二级</p></td><td></td></tr><tr><td><p>04</p></td><td><p>三级</p></td><td></td></tr><tr><td><p>05</p></td><td><p>四级</p></td><td></td></tr><tr><td><p>06</p></td><td><p>甲级</p></td><td></td></tr><tr><td><p>07</p></td><td><p>乙级</p></td><td></td></tr><tr><td><p>08</p></td><td><p>丙级</p></td><td></td></tr><tr><td><p>09</p></td><td><p>丁级</p></td><td></td></tr><tr><td><p>10</p></td><td><p>暂定级（预乙级）</p></td><td></td></tr><tr><td><p>11</p></td><td><p>初级</p></td><td></td></tr><tr><td><p>12</p></td><td><p>中级</p></td><td></td></tr><tr><td><p>13</p></td><td><p>高级</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00551", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.17 **身份证件类型代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00552", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 801"]} -->
编码规则：参考公安部制定的《常用证件代码》（GA/T517-2004），采用2位顺序码。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00553", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00554", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 58"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>01</p></td><td><p>居民身份证</p></td><td></td></tr><tr><td><p>02</p></td><td><p>军官证</p></td><td></td></tr><tr><td><p>03</p></td><td><p>武警警官证</p></td><td></td></tr><tr><td><p>04</p></td><td><p>士兵证</p></td><td></td></tr><tr><td><p>05</p></td><td><p>军队离退休干部证</p></td><td></td></tr><tr><td><p>06</p></td><td><p>残疾人证</p></td><td></td></tr><tr><td><p>07</p></td><td><p>残疾军人证（1-8级）</p></td><td></td></tr><tr><td><p>08</p></td><td><p>护照</p></td><td></td></tr><tr><td><p>09</p></td><td><p>港澳同胞回乡证</p></td><td></td></tr><tr><td><p>10</p></td><td><p>港澳居民来往内地通行证</p></td><td></td></tr><tr><td><p>11</p></td><td><p>中华人民共和国往来港澳通行证</p></td><td></td></tr><tr><td><p>12</p></td><td><p>台湾居民来往大陆通行证</p></td><td></td></tr><tr><td><p>13</p></td><td><p>大陆居民往来台湾通行证</p></td><td></td></tr><tr><td><p>14</p></td><td><p>外国人居留证</p></td><td></td></tr><tr><td><p>15</p></td><td><p>外交官证</p></td><td></td></tr><tr><td><p>16</p></td><td><p>领事馆证</p></td><td></td></tr><tr><td><p>17</p></td><td><p>海员证</p></td><td></td></tr><tr><td><p>18</p></td><td><p>香港身份证</p></td><td></td></tr><tr><td><p>19</p></td><td><p>台湾身份证</p></td><td></td></tr><tr><td><p>20</p></td><td><p>澳门身份证</p></td><td></td></tr><tr><td><p>21</p></td><td><p>外国人身份证件</p></td><td></td></tr><tr><td><p>22</p></td><td><p>高校毕业生自主创业证</p></td><td></td></tr><tr><td><p>23</p></td><td><p>就业失业登记证</p></td><td></td></tr><tr><td><p>24</p></td><td><p>台胞证</p></td><td></td></tr><tr><td><p>25</p></td><td><p>退休证</p></td><td></td></tr><tr><td><p>26</p></td><td><p>离休证</p></td><td></td></tr><tr><td><p>99</p></td><td><p>其他证件</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00555", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.18 **奖惩对象类型代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00556", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 771", "document order / paragraph 782", "document order / paragraph 804", "document order / paragraph 812", "document order / paragraph 823", "document order / paragraph 826"]} -->
编码规则：采用1位顺序码。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00557", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00558", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 59"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>1</p></td><td><p>招标人</p></td><td></td></tr><tr><td><p>2</p></td><td><p>招标代理机构</p></td><td></td></tr><tr><td><p>3</p></td><td><p>招标代理人员</p></td><td></td></tr><tr><td><p>4</p></td><td><p>投标人</p></td><td><p>含工程、货物、服务投标人</p></td></tr><tr><td><p>5</p></td><td><p>设计和施工项目经理</p></td><td></td></tr><tr><td><p>6</p></td><td><p>总监理工程师</p></td><td></td></tr><tr><td><p>7</p></td><td><p>评标专家</p></td><td></td></tr><tr><td><p>9</p></td><td><p>其他</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00559", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.19 **奖惩类型代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00560", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 807"]} -->
编码规则：采用2位顺序码。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00561", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00562", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 60"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>01</p></td><td><p>优良招标投标主体</p></td><td></td></tr><tr><td><p>02</p></td><td><p>优良交易对象</p></td><td></td></tr><tr><td><p>03</p></td><td><p>优良从业人员</p></td><td></td></tr><tr><td><p>04</p></td><td><p>警告</p></td><td></td></tr><tr><td><p>05</p></td><td><p>罚款</p></td><td></td></tr><tr><td><p>06</p></td><td><p>没收非法所得、没收非法财物</p></td><td></td></tr><tr><td><p>07</p></td><td><p>责令停产停业</p></td><td></td></tr><tr><td><p>08</p></td><td><p>暂扣或吊销许可证、执照</p></td><td></td></tr><tr><td><p>09</p></td><td><p>行政拘留</p></td><td></td></tr><tr><td><p>10</p></td><td><p>降低资质等级</p></td><td></td></tr><tr><td><p>11</p></td><td><p>暂停、取消职业资格证书</p></td><td></td></tr><tr><td><p>12-99</p></td><td><p>其他行政处罚或不良行为记录</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00563", "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / table 38 / row 2 / column 1", "document order / table 39 / row 2 / column 1", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1"]} -->
### 10.3.20 **评标委员会组建申请编号**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00564", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 769", "document order / paragraph 810"]} -->
编码规则：采用全球唯一标识符（GUID）表示，格式为“xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx”，其中每个 x 是 0-9 或 a-f 范围内的一个32位十六进制数。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00565", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.21 **专家类型代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00566", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 771", "document order / paragraph 782", "document order / paragraph 804", "document order / paragraph 812", "document order / paragraph 823", "document order / paragraph 826"]} -->
编码规则：采用1位顺序码。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00567", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00568", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 61"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>1</p></td><td><p>招标人代表</p></td><td></td></tr><tr><td><p>2</p></td><td><p>专家库成员</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00569", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.22 **专家编号**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00570", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 815"]} -->
编码规则：采用组合码，编码长度为17。排列顺序从左至右依次为：10位公共服务平台标识代码，1位专家库在公共服务平台中的序列号，6位是专家在专家库中的序列号（根据登记入库的先后自动排序）。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00571", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.23 **公共服务平台标识代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00572", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 817"]} -->
编码规则：采用组合码，编码长度为10位。排列顺序从左至右依次为：6位行政区域代码，以及4位全国公共服务平台序列号。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00573", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 818"]} -->
行政区域代码采用《GB/T 2260-2007 中华人民共和国行政区划代码》的6位数字码。全国公共服务平台序列号的取值从001-999，按照其在国家公共服务平台注册登记或交换登记信息时间排序。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00574", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.24 **平台类型代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00575", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 820"]} -->
编码规则：采用1位字母码。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00576", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00577", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 62"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>P</p></td><td><p>公共服务平台</p></td><td></td></tr><tr><td><p>E</p></td><td><p>交易平台</p></td><td></td></tr><tr><td><p>G</p></td><td><p>行政监督平台</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00578", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.25 **金额单位代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00579", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 771", "document order / paragraph 782", "document order / paragraph 804", "document order / paragraph 812", "document order / paragraph 823", "document order / paragraph 826"]} -->
编码规则：采用1位顺序码。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00580", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00581", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 63"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>1</p></td><td><p>元</p></td><td></td></tr><tr><td><p>2</p></td><td><p>万元</p></td><td></td></tr></table>

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00582", "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
### 10.3.26 **通知书类型代码**

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00583", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 771", "document order / paragraph 782", "document order / paragraph 804", "document order / paragraph 812", "document order / paragraph 823", "document order / paragraph 826"]} -->
编码规则：采用1位顺序码。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00584", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 757", "document order / paragraph 772", "document order / paragraph 775", "document order / paragraph 778", "document order / paragraph 783", "document order / paragraph 786", "document order / paragraph 790", "document order / paragraph 799"]} -->
码值内容见下表。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00585", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 64"]} -->
<table><tr><td><p><strong>代码</strong></p></td><td><p><strong>名称</strong></p></td><td><p><strong>说明</strong></p></td></tr><tr><td><p>1</p></td><td><p>中标通知书</p></td><td></td></tr><tr><td><p>2</p></td><td><p>招标结果通知书</p></td><td></td></tr></table>
