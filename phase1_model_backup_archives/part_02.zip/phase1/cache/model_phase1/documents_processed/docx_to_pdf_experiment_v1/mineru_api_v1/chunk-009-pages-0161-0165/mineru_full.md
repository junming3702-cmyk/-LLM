<table><tr><td rowspan=1 colspan=1>22</td><td rowspan=1 colspan=1>高校毕业生自主创业证</td></tr><tr><td rowspan=1 colspan=1>23</td><td rowspan=1 colspan=1>就业失业登记证</td></tr><tr><td rowspan=1 colspan=1>24</td><td rowspan=1 colspan=1>台胞证</td></tr><tr><td rowspan=1 colspan=1>25</td><td rowspan=1 colspan=1>退休证</td></tr><tr><td rowspan=1 colspan=1>26</td><td rowspan=1 colspan=1>离休证</td></tr><tr><td rowspan=1 colspan=1>99</td><td rowspan=1 colspan=1>其他证件</td></tr></table>

B.3.18 奖惩对象类型代码

编码规则：采用 1 位顺序码。

码值内容见下表。

<table><tr><td colspan="1" rowspan="1">代码</td><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">招标人</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">招标代理机构</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">招标代理人员</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">投标人</td><td colspan="1" rowspan="1">含工程、货物、服务投标人</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">设计和施工项目经理</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">总监理工程师</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">评标专家</td><td colspan="1" rowspan="1"></td></tr><tr><td></td><td></td><td></td></tr><tr><td>9</td><td>其他</td><td></td></tr></table>

## B.3.19 奖惩类型代码

编码规则：采用 2 位顺序码。

码值内容见下表。

<table><tr><td colspan="1" rowspan="1">代码</td><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td></tr><tr><td colspan="1" rowspan="1">01</td><td colspan="1" rowspan="1">优良招标投标主体</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">02</td><td colspan="1" rowspan="1">优良交易对象</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">03</td><td colspan="1" rowspan="1">优良从业人员</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">04</td><td colspan="1" rowspan="1">警告</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">05</td><td colspan="1" rowspan="1">罚款</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">06</td><td colspan="1" rowspan="1">没收非法所得、没收非法财物</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">07</td><td colspan="1" rowspan="1">责令停产停业</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">08</td><td colspan="1" rowspan="1">暂扣或吊销许可证、执照</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">09</td><td colspan="1" rowspan="1">行政拘留</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">10</td><td colspan="1" rowspan="1">降低资质等级</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">11</td><td colspan="1" rowspan="1">暂停、取消职业资格证书</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">12-99</td><td colspan="1" rowspan="1">其他行政处罚或不</td><td colspan="1" rowspan="1"></td></tr><tr><td></td><td>良行为记录</td><td></td></tr></table>

## B.3.20 评标委员会组建申请编号

编码规则：采用全球唯一标识符（GUID）表示，格式为“xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx”，其中每个 x是 0-9 或 a-f 范围内的一个 32 位十六进制数。

## B.3.21专家类型代码

编码规则：采用 1 位顺序码。

码值内容见下表。

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>招标人代表</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>专家库成员</td><td rowspan=1 colspan=1></td></tr></table>

## B.3.22 专家编号

编码规则：采用组合码，编码长度为 17。排列顺序从左至右依次为：10 位公共服务平台标识代码，1 位专家库在公共服务平台中的序列号，6 位是专家在专家库中的序列号（根据登记入库的先后自动排序）。

## B.3.23 公共服务平台标识代码

编码规则：采用组合码，编码长度为 10 位。排列顺序从左至右依次为：6 位行政区域代码，以及 4 位全国公共服务

平台序列号。

行政区域代码采用《GB/T 2260-2007 中华人民共和国行政区划代码》的 6 位数字码。全国公共服务平台序列号的取值从 001-999，按照其在国家公共服务平台注册登记或交换登记信息时间排序。

## B.3.24 平台类型代码

编码规则：采用 1 位字母码。

码值内容见下表。

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>P</td><td rowspan=1 colspan=1>公共服务平台</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>E</td><td rowspan=1 colspan=1>交易平台</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>G</td><td rowspan=1 colspan=1>行政监督平台</td><td rowspan=1 colspan=1></td></tr></table>

## B.3.25金额单位代码

编码规则：采用 1 位顺序码。

码值内容见下表。

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>元</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>万元</td><td rowspan=1 colspan=1></td></tr></table>

## B.3.26通知书类型代码

编码规则：采用 1 位顺序码。

码值内容见下表。

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>中标通知书</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>招标结果通知书</td><td rowspan=1 colspan=1></td></tr></table>