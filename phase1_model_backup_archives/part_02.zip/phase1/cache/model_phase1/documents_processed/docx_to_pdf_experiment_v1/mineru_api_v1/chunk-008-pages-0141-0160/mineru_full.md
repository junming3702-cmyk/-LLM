<table><tr><td rowspan=1 colspan=1>数值型</td><td rowspan=1 colspan=1>可以进行数学运算的数据。</td><td rowspan=1 colspan=1>以大写字母“N”代表数值型:N..X:表示最长为“X&quot;的数值型数据元值;N..X,y:表示总长度为&quot;X&quot;位、其中小数点后为“y”位的数值型数据元值。</td></tr><tr><td rowspan=1 colspan=1>型</td><td rowspan=1 colspan=1>日期时间|用以表示日期及时间的数据。</td><td rowspan=1 colspan=1>采用GB/T7408《数据元和交换格式 信息交换 日期和时间表示法》的规定。</td></tr><tr><td rowspan=1 colspan=1>二进制型</td><td rowspan=1 colspan=1>图象、音频、视频等二进制数据。</td><td rowspan=1 colspan=1>以大写字母“BY”代表二进制型:BY-X:表示媒体格式为“X&quot;的二进制型数据元值。</td></tr><tr><td rowspan=1 colspan=1>布尔型</td><td rowspan=1 colspan=1>两个且只有两个表明条件的值，如 On/Off、True/False。</td><td rowspan=1 colspan=1>以大写字母&quot;B&quot;代表布尔型。</td></tr></table>

## 附录B 编码总体规则

## B.1 编码总体规则说明

信息分类与编码是建设电子招标投标系统不可或缺的部分，是支撑电子招标投标系统信息交换、共享的主要技术手段。电子招标投标信息分类与编码主要用于表示数据项的值域。当数据项是代码型数据项时，其值域指向了相应的信息分类与编码信息，如果有相应的国家标准，则优先采用国家标准信息。

用于电子招标投标系统建设信息分类和编码的基本原则有：

实用性：在对事物或概念进行分类编码时，既要保证科学合理，又要立足于电子招标投标的实际管理需求，满足电子招标投标业务管理和电子招标投标系统建设的需求。

稳定性：宜选择事物或概念相对稳定的属性或特征作为分类依据，代码不宜频繁变动和修改，以避免造成人、财、物的浪费。

唯一性：在一个分类编码标准中，一个编码对象只能有一个代码，一个代码只能唯一表示一个编码对象，即编码对象与代码间是一一对应的关系。

可扩展性：在进行分类编码时，通常要设置收容类目（其他类），为新增加的编码对象留有足够的可扩充的备用码，以保证增加新的事物或概念时，不必打乱已建立的分类体系。

同时，还应为分类的进一步延拓细化创造条件，并充分考虑电子招标投标改革与可持续发展的需要。

兼容性：应与相关的国家标准及相关行业标准协调一致。

电子招标投标系统建设用信息编码的常用方法包括：顺序码、缩写码、层次码、组合码。

依据信息分类编码标准化的一般要求，结合电子招标投标系统建设的实际需要和特点，电子招标投标信息分类与编码信息主要通过 2 个属性来描述：

1、编码规则：描述代码的分类原则和编码方法。

2、码值：代码对应的代码表。代码表有 3 个字段，“名称”字段表示编码对象的中文名称；“代码”字段表示编码对象的代码，可以是数字码、字母码或数字字母混合码；“说明”字段表示需要特殊说明的内容。其中，“名称”和“代码”是必选字段，“说明”是可选字段。如下表所示：

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

## B.2 通用编码

本技术规范中引用到的信息分类编码国家标准包括：

1. GB/T 4754-2011 国民经济行业分类

2. GB 11714-1997 全国组织机构代码编制规则

3. GB/T 12406-2008 表示货币和资金的代码

4. GB/T 2659-2000 世界各国和地区名称代码

5. GB/T 2260-2007 中华人民共和国行政区划代码

6. GB 11643－1999 公民身份号码

7. GB/T 2261.1-2003 个人基本信息分类与代码 第 1部分：人的性别代码

8. 评标专家专业分类标准（试行）（发改法规[2010]1538号）

## B.3 业务编码

结合数据项中的有关代码字段（在值域中有相关描述）进行编码说明。

## B.3.1 交易平台标识代码

编码规则：采用组合码，编码长度为 11 位。排列顺序从左至右依次为：1 位行业门类字母码、6 位行政区域代码，以及 4 位全国交易平台序列号。

其中行业门类字母码采用《GB/T 4754-2011 国民经济行业分类 GB/T 4754 国民经济行业分类》的门类。行政区域代码采用《GB/T 2260-2007 中华人民共和国行政区划代码GB/T 2260 中华人民共和国行政区划代码》的 6 位数字码。全国交易平台序列号的取值从 0001-9999，按照其在国家公共服务平台注册登记或交换登记信息时间排序。

## B.3.2 项目编号

编码规则：采用组合码，编码长度为 17 位。排列顺序从左至右依次为：前 11 位由交易平台标识代码组成，后 6 位由项目序列号组成，项目序列号的取值从 000001-999999。

## B.3.3 招标组织形式代码

编码规则：采用 1 位顺序码表示。

码值内容见下表。

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>自行招标</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>委托招标</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1></td></tr></table>

## B.3.4 招标项目编号

编码规则：采用组合码，编码长度为 20 位。排列顺序从左至右依次为：前 17 位由项目编号组成，后 3 位由招标项目在项目中的序列号组成，招标项目序列号的取值从 001-999。

## B.3.5 标段（包）编号

编码规则：采用组合码，编码长度为 23 位。排列顺序从左至右依次为：前 20 位由招标项目编号组成，后 3 位由标段（包）在招标项目中的序列号组成，标段（包）序列号的取值从 001-999。

## B.3.6 标段（包）分类代码

编码规则：采用组合码，编码长度 7 位。此编码参考了《评标专家专业分类标准（试行）》（发改法规[2010]1538 号），并在此基础上进行了扩展，排列顺序从左至右依次为：

（1）第一级 1 位，A -工程、B-货物、C-服务、D-产权、E-土地；

（2）第二级 2 位，对应《评标专家专业分类标准》中的一级类别;

（3）第三级 2 位，对应《评标专家专业分类标准》的二
<table><tr><td>一级类别</td><td>二级类别</td></tr><tr><td>A-工程</td><td>01规划</td></tr><tr><td rowspan="9"></td><td>02投资策划与决策</td></tr><tr><td>03勘察</td></tr><tr><td>04设计</td></tr><tr><td>05监理</td></tr><tr><td>06 工程造价</td></tr><tr><td>07 1 项目管理(含代建)</td></tr><tr><td>08 工程施工</td></tr><tr><td>09 其他工程</td></tr><tr><td></td></tr><tr><td rowspan="4">B-货物</td><td>01 机械、设备类</td></tr><tr><td>02医疗器械</td></tr><tr><td>03金属材料</td></tr><tr><td>04 石油及其制品</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">05 煤炭煤层气及其制品06 化工材料及其制品07 建筑材料08药品其他</td></tr><tr><td colspan="1" rowspan="1">C-服务</td><td colspan="1" rowspan="1">01勘查与调查02 公共咨询03经济管理04 工商管理05金融06 法律07修理08租赁09交通运输与物流10 节能服务11高新技术服务12 其他服务13招标代理服务（备注：新增)</td></tr><tr><td colspan="1" rowspan="1">D-产权</td><td colspan="1" rowspan="1">另行制定</td></tr><tr><td colspan="1" rowspan="1">E-土地</td><td colspan="1" rowspan="1">另行制定</td></tr></table>

级类别，并新增以下类别：

<table><tr><td rowspan=1 colspan=1>一级类别</td><td rowspan=1 colspan=1>二级类别</td><td rowspan=1 colspan=1>三级类别</td></tr><tr><td rowspan=1 colspan=1>C-服务</td><td rowspan=1 colspan=1>13招标代理服务</td><td rowspan=1 colspan=1>01工程类代理02货物类代理03月服务类代理04产权类代理05土地类代理</td></tr><tr><td rowspan=1 colspan=1>D-产权</td><td rowspan=1 colspan=1>另行制定</td><td rowspan=1 colspan=1>另行制定</td></tr><tr><td rowspan=1 colspan=1>E-土地</td><td rowspan=1 colspan=1>另行制定</td><td rowspan=1 colspan=1>另行制定</td></tr></table>

（4）第四级 2 位，对应《评标专家专业分类标准》的三级类别，如果没有四级类别可以使用 00 补充，例如：

<table><tr><td colspan="1" rowspan="1">一级类别</td><td colspan="1" rowspan="1">二级类别</td><td colspan="1" rowspan="1">三级类别</td><td colspan="1" rowspan="1">四级类别</td></tr><tr><td colspan="1" rowspan="1">C-服务</td><td colspan="1" rowspan="1">13招标代理服务</td><td colspan="1" rowspan="1">01 工程类代|01中央投资理02 货物类代理03服务类代理04产权类代理</td><td colspan="1" rowspan="1">01 工程类代|01中央投资项目02 政府采购项目代03机电国际招标项目04通讯建设项目</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">05土地类代理</td><td colspan="1" rowspan="1">05其他如果没有四级类别，可以用00补足</td></tr><tr><td colspan="1" rowspan="1">D-产权</td><td colspan="1" rowspan="1">另行制定</td><td colspan="1" rowspan="1">另行制定</td><td colspan="1" rowspan="1">另行制定</td></tr><tr><td colspan="1" rowspan="1">E-土地</td><td colspan="1" rowspan="1">另行制定</td><td colspan="1" rowspan="1">另行制定</td><td colspan="1" rowspan="1">另行制定</td></tr></table>

## B.3.7 附件关联标识号

编码规则：采用全球唯一标识符（GUID）表示，格式为“xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx”，其中每个 x是 0-9 或 a-f 范围内的一个 32 位十六进制数。

## B.3.8 招标方式代码

编码规则：采用 1 位顺序码。

码值内容见下表。

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>公开招标</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>邀请招标</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>其它</td><td rowspan=1 colspan=1></td></tr></table>

## B.3.9 公告性质代码

编码规则：采用 1 位顺序码表示。

码值内容见下表。

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>正常公告</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>更正公告</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1></td></tr></table>

B.3.10 公告类型代码

编码规则：采用 1 位顺序码表示。

码值内容见下表。

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>招标公告</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>资格预审公告</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1></td></tr></table>

B.3.11 资格预审文件/招标文件/澄清与修改文件编号

编码规则：采用组合码，编码长度为 26 位。排列顺序从左至右依次为：前 23 位由标段（包）编号组成；1 位表示文件类型，Y 表示资格预审文件，Z 表示招标文件， 2 位表示文件版本号，资格预审文件/招标文件从 01 开始编号，此后的答疑澄清与修改文件每次版本号递增 1，取值范围从 01-99。

## B.3.12 是否代码

编码规则：采用 1 位顺序码。

码值内容见下表。

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>0</td><td rowspan=1 colspan=1>否</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>是</td><td rowspan=1 colspan=1></td></tr></table>

## B.3.13 公示类型代码

编码规则：采用 1 位顺序码表示。

码值内容见下表。

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>正常</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>更正</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1></td></tr></table>

## B.3.14 主体角色类型代码

编码规则：用 1 位字母码表示。

码值内容见下表。

<table><tr><td colspan="1" rowspan="1">代码</td><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td></tr><tr><td colspan="1" rowspan="1">T</td><td colspan="1" rowspan="1">招标人</td><td colspan="1" rowspan="1"></td></tr><tr><td>B</td><td>投标人</td><td></td></tr><tr><td>A</td><td>招标代理机构</td><td></td></tr></table>

## B.3.15 资质序列、行业和专业类别代码

编码规则：用 6 位数字层次码表示。第一层 1、2 两位表示资质序列；第二层 3、4 两位表示行业分类，00 表示不分行业；第三层 5、6 位表示专业类别，00 表示不分专业类别。各层次的资质编码均按有关部门颁发的资质标准排序。

## 1、第一层（1-2 位）资质序列：

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>01</td><td rowspan=1 colspan=1>工程咨询</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>02</td><td rowspan=1 colspan=1>工程规划</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>03</td><td rowspan=1 colspan=1>工程勘察</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>04</td><td rowspan=1 colspan=1>工程设计</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>05</td><td rowspan=1 colspan=1>施工总承包</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>06</td><td rowspan=1 colspan=1>施工专业分包</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>07</td><td rowspan=1 colspan=1>施工劳务分包</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>08</td><td rowspan=1 colspan=1>工程监理</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>09</td><td rowspan=1 colspan=1>招标代理</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>工程造价</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>工程检测</td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>房地产开发</td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>房地产评估</td></tr><tr><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>拆迁</td></tr><tr><td rowspan=1 colspan=1>15</td><td rowspan=1 colspan=1>园林</td></tr><tr><td rowspan=1 colspan=1>16</td><td rowspan=1 colspan=1>设计施工一体化</td></tr><tr><td rowspan=1 colspan=1>...9</td><td rowspan=1 colspan=1>其他</td></tr></table>

## 2、第二层（3-4 位）资质行业：

<table><tr><td colspan="1" rowspan="1">代码</td><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td></tr><tr><td colspan="1" rowspan="1">00</td><td colspan="1" rowspan="1">不分行业</td><td colspan="1" rowspan="1">如果资质没有行业区分，第二层编码就使用00。</td></tr><tr><td colspan="1" rowspan="1">01</td><td colspan="1" rowspan="1">房屋建筑</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">02</td><td colspan="1" rowspan="1">公路</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">03</td><td colspan="1" rowspan="1">铁路</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">04</td><td colspan="1" rowspan="1">港口与航道</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">05</td><td colspan="1" rowspan="1">水利水电</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">06</td><td colspan="1" rowspan="1">电力</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">07</td><td colspan="1" rowspan="1">矿山</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">08</td><td colspan="1" rowspan="1">冶炼</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">09</td><td colspan="1" rowspan="1">化工石油</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">10</td><td colspan="1" rowspan="1">市政公用</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">11</td><td colspan="1" rowspan="1">通信</td><td colspan="1" rowspan="1"></td></tr><tr><td>12</td><td>机电安装</td><td></td></tr><tr><td>...99</td><td>其他</td><td></td></tr></table>

## 3、第三层（5-6 位）资质专业：

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>00</td><td rowspan=1 colspan=1>不分专业</td><td rowspan=1 colspan=1>如果没有专业区分，第三层编码就使用00。</td></tr><tr><td rowspan=1 colspan=1>01</td><td rowspan=1 colspan=1>地基与基础工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>02</td><td rowspan=1 colspan=1>土石方工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>03</td><td rowspan=1 colspan=1>建筑装修装饰</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>04</td><td rowspan=1 colspan=1>建筑幕墙工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>05</td><td rowspan=1 colspan=1>预拌商品混凝土</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>06</td><td rowspan=1 colspan=1>混凝土预制构件</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>07</td><td rowspan=1 colspan=1>园林古建筑工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>08</td><td rowspan=1 colspan=1>钢结构工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>09</td><td rowspan=1 colspan=1>高耸构筑物工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>电梯安装工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>消防设施工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>建筑防水工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>防腐保温工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>附着升降脚手架</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>15</td><td rowspan=1 colspan=1>金属门窗工程</td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td colspan="1" rowspan="1">16</td><td colspan="1" rowspan="1">预应力工程</td></tr><tr><td colspan="1" rowspan="1">17</td><td colspan="1" rowspan="1">起重设备安装工程</td></tr><tr><td colspan="1" rowspan="1">18</td><td colspan="1" rowspan="1">机电设备安装工程</td></tr><tr><td colspan="1" rowspan="1">19</td><td colspan="1" rowspan="1">爆破与拆除工程</td></tr><tr><td colspan="1" rowspan="1">20</td><td colspan="1" rowspan="1">建筑智能化工程</td></tr><tr><td colspan="1" rowspan="1">21</td><td colspan="1" rowspan="1">环保工程</td></tr><tr><td colspan="1" rowspan="1">22</td><td colspan="1" rowspan="1">电信工程</td></tr><tr><td colspan="1" rowspan="1">23</td><td colspan="1" rowspan="1">电子工程</td></tr><tr><td colspan="1" rowspan="1">24</td><td colspan="1" rowspan="1">桥梁工程</td></tr><tr><td colspan="1" rowspan="1">25</td><td colspan="1" rowspan="1">隧道工程</td></tr><tr><td colspan="1" rowspan="1">26</td><td colspan="1" rowspan="1">公路路面工程</td></tr><tr><td colspan="1" rowspan="1">27</td><td colspan="1" rowspan="1">公路路基工程</td></tr><tr><td colspan="1" rowspan="1">28</td><td colspan="1" rowspan="1">公路交通工程</td></tr><tr><td colspan="1" rowspan="1">29</td><td colspan="1" rowspan="1">铁路电务工程</td></tr><tr><td colspan="1" rowspan="1">30</td><td colspan="1" rowspan="1">铁路铺轨架梁工程</td></tr><tr><td colspan="1" rowspan="1">31</td><td colspan="1" rowspan="1">铁路电气化工程</td></tr><tr><td colspan="1" rowspan="1">32</td><td colspan="1" rowspan="1">机场场道工程</td></tr><tr><td colspan="1" rowspan="1">33</td><td colspan="1" rowspan="1">机场空管工程及航站楼弱电系统工程</td></tr><tr><td colspan="1" rowspan="1">34</td><td colspan="1" rowspan="1">机场目视助航工程</td></tr><tr><td colspan="1" rowspan="1">35</td><td colspan="1" rowspan="1">港口与海岸工程</td></tr><tr><td colspan="1" rowspan="1">36</td><td colspan="1" rowspan="1">港口装卸设备安装工程</td></tr><tr><td colspan="1" rowspan="1">37</td><td colspan="1" rowspan="1">航道工程</td></tr><tr><td colspan="1" rowspan="1">38</td><td colspan="1" rowspan="1">通航建筑工程</td></tr><tr><td colspan="1" rowspan="1">39</td><td colspan="1" rowspan="1">通航设备安装工程</td></tr><tr><td colspan="1" rowspan="1">40</td><td colspan="1" rowspan="1">水上交通管制工程</td></tr><tr><td colspan="1" rowspan="1">41</td><td colspan="1" rowspan="1">水工建筑物基础处理工程</td></tr><tr><td colspan="1" rowspan="1">42</td><td colspan="1" rowspan="1">水工金属结构制作与安装工程</td></tr><tr><td colspan="1" rowspan="1">43</td><td colspan="1" rowspan="1">水利水电机电设备安装工程</td></tr><tr><td colspan="1" rowspan="1">44</td><td colspan="1" rowspan="1">河湖整治工程</td></tr><tr><td colspan="1" rowspan="1">45</td><td colspan="1" rowspan="1">堤防工程</td></tr><tr><td colspan="1" rowspan="1">46</td><td colspan="1" rowspan="1">水工大坝工程</td></tr><tr><td colspan="1" rowspan="1">47</td><td colspan="1" rowspan="1">水工隧洞工程</td></tr><tr><td colspan="1" rowspan="1">48</td><td colspan="1" rowspan="1">火电设备安装工程</td></tr><tr><td colspan="1" rowspan="1">49</td><td colspan="1" rowspan="1">送变电工程</td></tr><tr><td colspan="1" rowspan="1">50</td><td colspan="1" rowspan="1">核工程</td></tr><tr><td colspan="1" rowspan="1">51</td><td colspan="1" rowspan="1">炉窑工程</td></tr><tr><td colspan="1" rowspan="1">52</td><td colspan="1" rowspan="1">冶炼机电设备安装工程</td></tr><tr><td colspan="1" rowspan="1">53</td><td colspan="1" rowspan="1">化工石油设备管道安装工程</td></tr><tr><td colspan="1" rowspan="1">54</td><td colspan="1" rowspan="1">管道工程</td></tr><tr><td colspan="1" rowspan="1">55</td><td colspan="1" rowspan="1">无损检测</td></tr><tr><td colspan="1" rowspan="1">56</td><td colspan="1" rowspan="1">海洋石油工程</td></tr><tr><td colspan="1" rowspan="1">57</td><td colspan="1" rowspan="1">城市轨道交通工程</td></tr><tr><td colspan="1" rowspan="1">58</td><td colspan="1" rowspan="1">城市及道路照明工程</td></tr><tr><td colspan="1" rowspan="1">59</td><td colspan="1" rowspan="1">体育场地设施工程</td></tr><tr><td colspan="1" rowspan="1">60</td><td colspan="1" rowspan="1">特种专业工程</td></tr><tr><td colspan="1" rowspan="1">61</td><td colspan="1" rowspan="1">工程建设项目招标代理</td></tr><tr><td colspan="1" rowspan="1">62</td><td colspan="1" rowspan="1">中央投资项目招标代理</td></tr><tr><td colspan="1" rowspan="1">63</td><td colspan="1" rowspan="1">政府采购招标代理</td></tr><tr><td colspan="1" rowspan="1">64</td><td colspan="1" rowspan="1">机电产品国际招标代理</td></tr><tr><td colspan="1" rowspan="1">65</td><td colspan="1" rowspan="1">通讯建设项目招标代理</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">99</td><td colspan="1" rowspan="1">其他</td></tr></table>

例如：房屋建筑工程施工总承包企业资质对应的代码是050100（05-施工总承包序列；01-房屋建筑行业；00-不分专业）；工程建设项目招标代理资格的代码是 090061。

## B.3.16 资质等级代码

编码规则：采用 2 位顺序码表示。

码值内容见下表。
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>01</td><td rowspan=1 colspan=1>特级</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>02</td><td rowspan=1 colspan=1>一级</td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=1 colspan=1>03</td><td rowspan=1 colspan=1>二级</td></tr><tr><td rowspan=1 colspan=1>04</td><td rowspan=1 colspan=1>三级</td></tr><tr><td rowspan=1 colspan=1>05</td><td rowspan=1 colspan=1>四级</td></tr><tr><td rowspan=1 colspan=1>06</td><td rowspan=1 colspan=1>甲级</td></tr><tr><td rowspan=1 colspan=1>07</td><td rowspan=1 colspan=1>乙级</td></tr><tr><td rowspan=1 colspan=1>08</td><td rowspan=1 colspan=1>丙级</td></tr><tr><td rowspan=1 colspan=1>09</td><td rowspan=1 colspan=1>丁级</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>暂定级 (预乙级)</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>初级</td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>中级</td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>高级</td></tr></table>

## B.3.17 身份证件类型代码

编码规则： 参 考公安部制定 的《常用证件 代码》（GA/T517-2004），采用 2 位顺序码。

码值内容见下表。

<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>01</td><td rowspan=1 colspan=1>居民身份证</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>02</td><td rowspan=1 colspan=1>军官证</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>03</td><td rowspan=1 colspan=1>武警警官证</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>04</td><td rowspan=1 colspan=1>士兵证</td><td rowspan=1 colspan=1></td></tr></table>

<table><tr><td rowspan=1 colspan=1>05</td><td rowspan=1 colspan=1>军队离退休干部证</td></tr><tr><td rowspan=1 colspan=1>06</td><td rowspan=1 colspan=1>残疾人证</td></tr><tr><td rowspan=1 colspan=1>07</td><td rowspan=1 colspan=1>残疾军人证（1-8级）</td></tr><tr><td rowspan=1 colspan=1>08</td><td rowspan=1 colspan=1>护照</td></tr><tr><td rowspan=1 colspan=1>09</td><td rowspan=1 colspan=1>港澳同胞回乡证</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>港澳居民来往内地通行证</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>中华人民共和国往来港澳通行证</td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>台湾居民来往大陆通行证</td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>大陆居民往来台湾通行证</td></tr><tr><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>外国人居留证</td></tr><tr><td rowspan=1 colspan=1>15</td><td rowspan=1 colspan=1>外交官证</td></tr><tr><td rowspan=1 colspan=1>16</td><td rowspan=1 colspan=1>领事馆证</td></tr><tr><td rowspan=1 colspan=1>17</td><td rowspan=1 colspan=1>海员证</td></tr><tr><td rowspan=1 colspan=1>18</td><td rowspan=1 colspan=1>香港身份证</td></tr><tr><td rowspan=1 colspan=1>19</td><td rowspan=1 colspan=1>台湾身份证</td></tr><tr><td rowspan=1 colspan=1>20</td><td rowspan=1 colspan=1>澳门身份证</td></tr><tr><td rowspan=1 colspan=1>21</td><td rowspan=1 colspan=1>外国人身份证件</td></tr></table>