# MinerU formatted-PDF branch with original DOCX locators

<!-- The formatted PDF is a derived parsing aid; original DOCX remains source authority. -->

## chunk-002-pages-0021-0040.pdf — original pages 21-40

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00001", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 245"]} -->
c) 应具备招标公告和资格预审公告同步递交到指定媒介发布的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00002", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 246"]} -->
d) 应具备向公共服务平台同步提供招标公告和资格预审公告的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00003", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 247", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / table 44 / row 2 / column 1", "document order / table 48 / row 2 / column 1"]} -->
e) 招标公告和资格预审公告的数据项格式详见附录 A.1.4。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00004", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.3.2 投标邀请书

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00005", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 249"]} -->
投标邀请书管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00006", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 250", "document order / paragraph 285", "document order / paragraph 455", "document order / table 5 / row 3 / column 1", "document order / table 7 / row 4 / column 1", "document order / table 9 / row 4 / column 1", "document order / table 53 / row 3 / column 2", "document order / table 53 / row 4 / column 1"]} -->
a) 应具备从投标人信息库中获取满足投标资格条件或特定条件的潜在投标人的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00007", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 238", "document order / paragraph 248", "document order / paragraph 251", "document order / paragraph 285", "document order / paragraph 652", "document order / table 53 / row 3 / column 1"]} -->
b) 应具备投标邀请书的编辑和发出功能。数据项应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00008", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 252"]} -->
采用邀请招标的数据项包括标段（包）编号、标段（包）名称、投标资格、招标文件获取时间及获取方法、投标文件递交截止时间及递交方法、回复截止时间、投标邀请发出时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00009", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 253"]} -->
采用资格预审的项目投标邀请书（代资格预审结果通知书）数据项包括标段（包）编号、标段（包）名称、招标文件获取时间及获取方法、投标文件递交截止时间及递交方法、回复截止时间、投标邀请发出时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00010", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 238", "document order / paragraph 254", "document order / paragraph 285"]} -->
c) 应具备被邀请人接受和拒绝投标邀请的回复功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00011", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 数据项格式详见附录 A.1.5。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00012", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.4 发标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00013", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.4.1 招标文件

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00014", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 258"]} -->
招标文件管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00015", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 259", "document order / paragraph 285", "document order / paragraph 302", "document order / paragraph 307", "document order / paragraph 324", "document order / paragraph 649", "document order / table 3 / row 3 / column 1"]} -->
a) 应具备招标文件的编辑、提交、审核、确认、备案、发出功能。数据项应包括标段（包）编号、投标资格、投标有效期、投标保证金、投标文件递交截止时间、投标文件递交方法、开标时间、开标方式、评标办法、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00016", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 260", "document order / table 53 / row 3 / column 1"]} -->
b) 应具备按照标准文件或示范文本生成招标文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00017", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 261", "document order / paragraph 285", "document order / paragraph 659"]} -->
c) 应具备设定投标文件主要内容、格式要求的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00018", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 262", "document order / paragraph 285", "document order / paragraph 307", "document order / table 9 / row 6 / column 1", "document order / table 9 / row 13 / column 1", "document order / paragraph 659", "document order / table 14 / row 6 / column 1"]} -->
d) 应具备设定投标文件递交截止时间（开标时间）及其控制的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00019", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 263", "document order / table 62 / row 3 / column 1"]} -->
e) 应具备记录招标文件下载人、下载时间、下载次数的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00020", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 264", "document order / paragraph 671"]} -->
f) 宜具备将招标文件多个不同格式附件组合打包生成一个文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00021", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 265", "document order / table 62 / row 2 / column 2", "document order / table 62 / row 4 / column 1"]} -->
g) 应具备向公共服务平台提供招标文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00022", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
h) 数据项格式详见附录 A.1.9。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00023", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.4.2 资格预审文件

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00024", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 268"]} -->
资格预审文件的管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00025", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 267", "document order / paragraph 649", "document order / table 3 / row 3 / column 1", "document order / table 5 / row 2 / column 1", "document order / table 6 / row 2 / column 1", "document order / table 6 / row 4 / column 1", "document order / table 6 / row 5 / column 1", "document order / table 7 / row 2 / column 1"]} -->
a) 资格预审文件的管理应满足 5.4.1 的规定。资格预审文件数据项应包括标段（包）编号、申请资格、申请有效期、

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00026", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 269", "document order / paragraph 335", "document order / table 6 / row 6 / column 1", "document order / table 6 / row 7 / column 1", "document order / table 6 / row 10 / column 1", "document order / paragraph 671", "document order / table 28 / row 4 / column 1"]} -->
申请文件递交截止时间、申请文件递交方法、开启时间、开启方式、评审办法、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00027", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 数据项格式详见附录 A.1.6。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00028", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.4.3 踏勘现场

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00029", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 272"]} -->
踏勘现场管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00030", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 273", "document order / paragraph 645", "document order / table 1 / row 2 / column 1", "document order / paragraph 647", "document order / table 2 / row 2 / column 1", "document order / table 2 / row 3 / column 1", "document order / paragraph 649"]} -->
a) 应具备现场踏勘通知的编辑、发出功能。数据项应包括招标项目编号、标段（包）编号、踏勘通知内容、踏勘发出时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00031", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 274", "document order / paragraph 285", "document order / paragraph 657", "document order / table 11 / row 5 / column 1", "document order / table 53 / row 3 / column 1", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 5 / column 2"]} -->
b) 应具备按招标文件约定的时间，向所有已获取招标文件的潜在投标人发出现场踏勘通知和提示现场踏勘时间的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00032", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 275", "document order / paragraph 645", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 2 / column 1", "document order / paragraph 647", "document order / table 2 / row 1 / column 1", "document order / table 2 / row 2 / column 1"]} -->
c) 应具备现场踏勘信息的记录功能。数据项应包括招标项目编号、标段（包）编号、踏勘单位名称及其代表姓名、踏勘时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00033", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / table 44 / row 2 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 49 / row 2 / column 1"]} -->
d) 数据项格式详见附录 A.1.10、A.1.11。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00034", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 267", "document order / paragraph 277", "document order / table 56 / row 46 / column 1", "document order / table 56 / row 56 / column 1", "document order / table 59 / row 5 / column 1", "document order / table 59 / row 6 / column 1"]} -->
## 5.4.4 资格预审文件/招标文件澄清与修改

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00035", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 267", "document order / table 56 / row 46 / column 1", "document order / table 56 / row 56 / column 1", "document order / table 59 / row 5 / column 1", "document order / table 59 / row 6 / column 1"]} -->
资格预审文件/招标文件（5.4.4 中统称“文件”）澄清与修改管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00036", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / table 53 / row 4 / column 1"]} -->
a) 应具备文件澄清问题的编辑、递交功能。数据项应包括标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00037", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 279", "document order / table 6 / row 3 / column 1", "document order / table 9 / row 3 / column 1", "document order / paragraph 671", "document order / paragraph 685", "document order / table 27 / row 3 / column 1", "document order / table 27 / row 4 / column 1"]} -->
段（包）编号、文件编号、要求澄清的问题、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00038", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 280", "document order / paragraph 285", "document order / table 53 / row 3 / column 1", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 5 / column 2"]} -->
b) 应具备符合法律法规规章规定和招标文件约定的由资格预审申请人/投标人递交澄清问题的时间控制功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00039", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 281", "document order / paragraph 649", "document order / table 3 / row 3 / column 1", "document order / table 5 / row 2 / column 1", "document order / table 6 / row 2 / column 1", "document order / table 6 / row 3 / column 1", "document order / table 6 / row 12 / column 1", "document order / table 7 / row 2 / column 1"]} -->
c) 应具备招标人对文件的澄清与修改进行编辑、审核、发出的功能。数据项应包括标段（包）编号、澄清与修改文件编号、对文件澄清与修改的内容、澄清与修改递交时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00040", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 282", "document order / paragraph 285", "document order / table 53 / row 2 / column 2", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 2 / column 2", "document order / table 59 / row 5 / column 2"]} -->
d) 应具备符合法律法规规章规定和招标文件约定的招标人递交澄清答复的时间控制功能，以及向所有已获取文件的潜在资格预审申请人/投标人发送通知，并以醒目方式公告澄清与修改内容的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00041", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 283", "document order / paragraph 285", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 5 / column 2", "document order / table 62 / row 3 / column 1"]} -->
e) 应具备潜在资格预审申请人/投标人下载澄清与修改文件，并递交回执的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00042", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 257", "document order / paragraph 266", "document order / paragraph 267", "document order / paragraph 270", "document order / paragraph 306", "document order / table 44 / row 2 / column 1"]} -->
f) 文件澄清问题的数据项格式详见附录 A.1.27，对资格预审文件的澄清与修改的数据项格式详见附录 A.1.6，对招标文件的澄清与修改的数据项格式详见附录 A.1.9。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00043", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.5 投标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00044", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.5.1 资格预审申请文件/投标文件

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00045", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 286", "document order / paragraph 654", "document order / paragraph 659", "document order / table 44 / row 2 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 50 / row 2 / column 1"]} -->
资格预审申请文件/投标文件（在 5.5.1 中统称“文件”）管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00046", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / table 53 / row 4 / column 1"]} -->
a) 应具备在线或离线编辑和制作文件的功能，主要包括文件导入、文件内容编辑、工程量清单（如有）导入、版式文件转换、电子签章、文件生成、校验以及加密等功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00047", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 288", "document order / paragraph 302", "document order / paragraph 645", "document order / paragraph 649", "document order / table 3 / row 3 / column 1", "document order / table 5 / row 2 / column 1", "document order / table 6 / row 2 / column 1"]} -->
投标文件数据项应包括标段（包）编号、投标人代码、投标报价、工期（交货期）、投标有效期、投标保证金形式、投标保证金金额、投标单位项目负责人、投标时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00048", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 288", "document order / paragraph 645", "document order / paragraph 649", "document order / table 3 / row 3 / column 1", "document order / table 5 / row 2 / column 1", "document order / table 5 / row 3 / column 1", "document order / table 6 / row 2 / column 1"]} -->
资格预审申请文件数据项应包括标段（包）编号、申请人代码、投标资格条件、项目负责人、申请时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00049", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 289", "document order / table 53 / row 3 / column 1"]} -->
b) 应具备通过网络对文件递交、修改和撤回功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00050", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 290"]} -->
c) 应具备按照招标文件中的递交截止时间控制文件递交、补充、修改和撤回的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00051", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 291", "document order / table 6 / row 12 / column 1", "document order / table 9 / row 18 / column 1", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 5 / column 2"]} -->
d) 应具备递交时间截止后，拒绝资格预审申请人/投标人递交、修改和撤回文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00052", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 292", "document order / table 6 / row 12 / column 1", "document order / table 9 / row 18 / column 1", "document order / table 62 / row 3 / column 1"]} -->
e) 应具备拒绝接收递交时间截止时尚未完成传输的文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00053", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 293"]} -->
f) 应具备对文件的主要数据项内容和格式进行校验的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00054", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
g) 应具备文件防篡改的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00055", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 285", "document order / paragraph 295", "document order / paragraph 649", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 5 / column 2"]} -->
h) 应具备投标人按照招标文件约定的加密方式选择按标段（包）分段或整体加密、递交文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00056", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 296"]} -->
i) 应具备文件接收、校验、按接收时间排序和回执递交功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00057", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 297"]} -->
j) 应具备拒收未按法律法规规章规定和招标文件要求递交的文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00058", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 298", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 5 / column 2"]} -->
k) 应具备禁止除资格预审申请人/投标人外的任何人在投标截止前解密、提取文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00059", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 299"]} -->
l) 截止时间应使用国家授时中心标准时间。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00060", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 300"]} -->
m) 宜动态显示国家授时中心当前时间。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00061", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 285", "document order / paragraph 306", "document order / paragraph 654", "document order / paragraph 659"]} -->
n) 投标文件数据项格式详见附录A.1.12, 资格预审申请文件数据项格式详见附录 A.1.7。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00062", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.5.2 投标保证金

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00063", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 302", "document order / paragraph 303", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / paragraph 649", "document order / table 3 / row 1 / column 1", "document order / table 3 / row 3 / column 1"]} -->
a) 应具备记录和提示投标保证金接收、退还信息的功能。数据项应包括标段（包）编号、投标人代码、投标人名称、保证金金额、保证金支付形式、保证金凭证接收时间、保证金到账时间和保证金退还时间等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00064", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 302", "document order / paragraph 304", "document order / table 53 / row 3 / column 1"]} -->
b) 宜具备投标保证金接收情况展示的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00065", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 285", "document order / paragraph 302", "document order / paragraph 305", "document order / table 13 / row 5 / column 1"]} -->
c) 宜具备按照招标文件要求对投标保证金支付形式、资金到账时间、金额、接收凭证等进行符合性校验的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00066", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 数据项格式详见附录 A.1.13。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00067", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.6 开标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00068", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.6.1 签到记录

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00069", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 309"]} -->
应具备参加开标的人员通过网络远程办理电子签到的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00070", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.6.2 开标唱标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00071", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 311"]} -->
开标唱标管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00072", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 307", "document order / paragraph 312", "document order / table 51 / row 2 / column 2", "document order / table 51 / row 3 / column 2", "document order / table 53 / row 4 / column 1"]} -->
a) 应具备开标时验证投标单位是否达到和显示法定数量,并 可以根据实际情况启动开标或取消开标的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00073", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 307", "document order / paragraph 313", "document order / paragraph 659", "document order / table 53 / row 3 / column 1"]} -->
b) 应具备开标时验证并公布投标文件不被篡改、不遗漏及其投标过程记录的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00074", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 307", "document order / paragraph 314", "document order / table 9 / row 13 / column 1", "document order / paragraph 659", "document order / table 14 / row 6 / column 1"]} -->
c) 应具备按开标时间规定控制投标文件解密并记录解密过程的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00075", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 285", "document order / paragraph 315", "document order / paragraph 659", "document order / table 53 / row 2 / column 2", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 2 / column 2", "document order / table 59 / row 5 / column 2"]} -->
d) 应具备招标人和投标人按照招标文件约定的解密方式解密投标文件以及解密失败时按规定补救方式执行的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00076", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 285", "document order / paragraph 302", "document order / paragraph 316", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / paragraph 649", "document order / table 3 / row 1 / column 1"]} -->
e) 应具备投标文件数据读取、记录、展示的功能。展示内容中应包括标段（包）编号、投标人名称、报价、工期（交货期）、投标保证金额、投标保证金到账时间、投标文件递交时间等招标文件所确定的唱标内容。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00077", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 307", "document order / paragraph 317", "document order / paragraph 536", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / paragraph 649", "document order / table 3 / row 1 / column 1", "document order / table 3 / row 3 / column 1"]} -->
f) 应具备开标过程信息的记录、编辑、参与单位电子签名确认和递交功能。数据项应包括标段（包）编号、开标参与单位名称、开标展示内容等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00078", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 307", "document order / paragraph 318", "document order / paragraph 536", "document order / paragraph 661", "document order / table 62 / row 2 / column 2", "document order / table 62 / row 3 / column 2", "document order / table 62 / row 4 / column 1"]} -->
g) 应具备开标记录经过电子签名确认后，通过交易平台向社会公众和公共服务平台同步交换、公布的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00079", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 307", "document order / paragraph 319", "document order / paragraph 661"]} -->
h) 宜具备开标记录模板的编辑、修改、管理的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00080", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 307", "document order / paragraph 320"]} -->
i) 招标项目开标记录的数据项格式详见附录 A.1.14。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00081", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.6.3 资格预审文件的开启

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00082", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 267", "document order / paragraph 321", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / paragraph 649", "document order / table 3 / row 1 / column 1", "document order / table 3 / row 3 / column 1", "document order / table 4 / row 1 / column 1"]} -->
a) 资格预审文件的开启管理要求应符合 5.6.2 的规定。资格预审文件开启记录的数据项应包括标段（包）编号开启参与单位名称、开启时间、开启内容等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00083", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 267", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 323", "document order / paragraph 687"]} -->
b) 资格预审文件开启数据项格式详见附录 A.1.28。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00084", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.7 评标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00085", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.7.1 评标委员会

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00086", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 326"]} -->
评标委员会管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00087", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 327", "document order / paragraph 649", "document order / table 3 / row 3 / column 1", "document order / table 5 / row 2 / column 1", "document order / table 6 / row 2 / column 1", "document order / table 7 / row 2 / column 1"]} -->
a) 应具备申请依法组建评标委员会的功能。数据项应包括标段（包）编号、专家人数、行政区域代码、专业、等级、回避条件等组建要求。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00088", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 328", "document order / table 53 / row 3 / column 1"]} -->
b) 应具备连接依法建立的专家库的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00089", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 329", "document order / table 62 / row 2 / column 2"]} -->
c) 应具备通过公共服务平台连接的专家库通知评标委员会成员报到时间、地点的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00090", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 330", "document order / table 33 / row 3 / column 1", "document order / table 39 / row 3 / column 1", "document order / table 39 / row 4 / column 1", "document order / table 39 / row 6 / column 1", "document order / table 39 / row 7 / column 1"]} -->
d) 应具备接收专家库反馈抽取评标专家名单，并据此设置评标委员会职责分工的功能，相关数据项应包括专家编号、专家姓名、通知时间、通知方式等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00091", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 331", "document order / table 62 / row 3 / column 1"]} -->
e) 应具备评标委员会成员帐号生成、签到、身份确认、回避确认的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00092", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 332", "document order / paragraph 711", "document order / table 59 / row 8 / column 2", "document order / table 62 / row 2 / column 2"]} -->
f) 应具备评标专家行为考评记录，并递交到专家所属公共服务平台连接的专家库的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00093", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 333", "document order / table 62 / row 4 / column 1"]} -->
g) 应提供评标委员会名单在评标前的保密功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00094", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 324", "document order / paragraph 325", "document order / table 44 / row 2 / column 1"]} -->
h) 评标委员会数据项格式详见附录 A.2.9、A.2.10。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00095", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.7.2 评审

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00096", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 336"]} -->
评审管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00097", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 324", "document order / paragraph 335", "document order / paragraph 337", "document order / paragraph 645", "document order / table 53 / row 4 / column 1"]} -->
a) 应具备能够按招标文件约定的评标方法、评审因素和标准设置评审表格和评审项目的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00098", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 285", "document order / paragraph 324", "document order / paragraph 338", "document order / paragraph 659", "document order / table 53 / row 3 / column 1"]} -->
b) 应具备按招标文件约定的评标方法，对投标文件进行解析、对比，辅助评分或计算评标价的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00099", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 324", "document order / paragraph 339", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 5 / column 2"]} -->
c) 应具备汇总计算投标人综合评分或评标价并进行排序的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00100", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 340"]} -->
d) 应具备编辑和发出评标澄清问题的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00101", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 341", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 5 / column 2", "document order / table 62 / row 3 / column 1"]} -->
e) 应具备投标人编辑和递交投标澄清文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00102", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 335", "document order / paragraph 342", "document order / paragraph 645"]} -->
f) 应具备依评审权限设置评审项目访问、信息阅读的功能，确保无相应权限者无法查阅或操作相关数据。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00103", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
g) 宜具备以下评审功能：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00104", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 344"]} -->
按招标项目类型和评标办法设置、维护和管理评标模板。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00105", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 345"]} -->
依据招标项目清单、标底总价、分项单价与投标报价进行校验、对比，提示差异。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00106", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 346"]} -->
检测和辅助分析投标文件及异常投标行为。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00107", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 347"]} -->
评标委员会成员打分结果的检测和辅助分析。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00108", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.7.3 评标报告

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00109", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 349"]} -->
评标报告管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00110", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 324", "document order / paragraph 348", "document order / paragraph 350", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / paragraph 649", "document order / table 3 / row 1 / column 1"]} -->
a) 应具备评标报告编辑、阅读的权限设置、签署和提交功能。数据项应包括标段（包）编号、中标候选人名称及排名、投标价格、评分结果或评标价格、中标价格、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00111", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 348", "document order / paragraph 351", "document order / paragraph 416", "document order / paragraph 662", "document order / table 53 / row 3 / column 1", "document order / table 62 / row 2 / column 2"]} -->
b) 应具备向公共服务平台监督通道提供评标报告数据的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00112", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 324", "document order / paragraph 348", "document order / paragraph 662"]} -->
c) 评标报告的数据项格式详见附录 A.1.15、A.1.16。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00113", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.7.4 远程异地评标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00114", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 354"]} -->
宜按以下要求具备网络远程异地评标的功能：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00115", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 对评标委员会实现有效的监控。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00116", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 对评标时间和地点进行控制。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00117", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 评标委员会评标必需的沟通功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00118", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.7.5 资格预审申请文件的评审

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00119", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 335", "document order / table 44 / row 2 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 49 / row 2 / column 1", "document order / table 50 / row 2 / column 1", "document order / table 51 / row 3 / column 1", "document order / table 52 / row 2 / column 1", "document order / table 53 / row 4 / column 1"]} -->
a) 资格预审评审委员会的管理要求应符合 5.7.1 的规定。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00120", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 335", "document order / paragraph 358", "document order / paragraph 654", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 3 / column 1", "document order / table 50 / row 3 / column 1", "document order / table 52 / row 3 / column 1"]} -->
b) 资格预审申请文件的评审管理要求应符合 5.7.2 的规定，其中有关价格评审功能不适用于资格预审申请文件的评审。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00121", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 649", "document order / table 3 / row 3 / column 1", "document order / table 5 / row 2 / column 1", "document order / table 6 / row 2 / column 1", "document order / table 7 / row 2 / column 1", "document order / paragraph 655", "document order / table 8 / row 2 / column 1", "document order / table 8 / row 3 / column 1"]} -->
c) 资格预审结果文件的管理要求应符合 5.7.3 的规定。数据项应包括标段（包）编号、通过资格预审的申请人名单、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00122", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 335", "document order / paragraph 654", "document order / table 56 / row 59 / column 1", "document order / table 59 / row 5 / column 1", "document order / table 59 / row 6 / column 1", "document order / table 59 / row 8 / column 1"]} -->
d) 资格预审申请文件的远程异地评审的管理要求应符合5.7.4 的规定。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00123", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 363", "document order / paragraph 416", "document order / paragraph 655", "document order / table 62 / row 2 / column 2", "document order / table 62 / row 3 / column 1"]} -->
e) 应具备向公共服务平台监督通道提供资格预审结果文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00124", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 364", "document order / paragraph 655", "document order / table 44 / row 2 / column 1"]} -->
f) 资格预审结果文件的数据项格式详见附录 A.1.8

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00125", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8 定标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00126", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8.1 中标候选人公示

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00127", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 366", "document order / paragraph 367", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / paragraph 649", "document order / table 3 / row 1 / column 1", "document order / table 3 / row 3 / column 1"]} -->
a) 应具备中标候选人公示的编辑、提交审核、验证确认、备案、发布功能。数据项应包括：标段（包）编号、公示内容（含中标候选人名称及排序、投标价格、中标价格）、公示时间等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00128", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 366", "document order / paragraph 368", "document order / paragraph 663", "document order / paragraph 665", "document order / table 53 / row 3 / column 1", "document order / table 62 / row 2 / column 2"]} -->
b) 应具备向公共服务平台提供中标候选人公示数据的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00129", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 366", "document order / paragraph 369", "document order / paragraph 663"]} -->
c) 中标候选人公示的数据项格式详见附录 A.1.17。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00130", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 370", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 3 / column 1", "document order / table 50 / row 3 / column 1", "document order / table 52 / row 3 / column 1", "document order / table 56 / row 60 / column 1", "document order / table 59 / row 3 / column 1"]} -->
## 5.8.2 确认资格预审的申请人/确定中标人

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00131", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 371", "document order / table 53 / row 4 / column 1"]} -->
a) 应具备授权资格审查委员会确认通过资格预审的申请人/授权评标委员会确定中标人的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00132", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 372", "document order / table 53 / row 2 / column 2", "document order / table 53 / row 3 / column 1", "document order / table 59 / row 2 / column 2"]} -->
b) 应提供招标人确认通过资格预审的申请人/确定中标人的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00133", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8.3 中标结果公告

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00134", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 373", "document order / paragraph 374", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / paragraph 649", "document order / table 3 / row 1 / column 1", "document order / table 3 / row 3 / column 1", "document order / table 3 / row 4 / column 1"]} -->
a) 应具备编辑、提交审核、验证确认、备案、发布和向公共服务平台提供中标结果公告的功能。数据项应包括：标段（包）编号、标段（包）名称、中标人名称、中标价格、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00135", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 373", "document order / paragraph 375", "document order / paragraph 689"]} -->
b) 中标结果公告的数据项格式详见附录 A.1.29。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00136", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8.4 中标通知书

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00137", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 377"]} -->
中标通知书管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00138", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 376", "document order / paragraph 378", "document order / paragraph 645", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 3 / column 1", "document order / paragraph 647", "document order / table 2 / row 1 / column 1"]} -->
a) 应具备中标通知书和招标结果通知书的编辑、验证确认和递交的功能。数据项应包括：招标项目名称及其编号、标段（包）编号、中标人、中标价格、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00139", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 379", "document order / table 53 / row 3 / column 1"]} -->
b) 宜具备中标、未中标理由的编辑、确认、递交功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00140", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 376", "document order / paragraph 380", "document order / table 62 / row 2 / column 2", "document order / table 64 / row 2 / column 2", "document order / table 64 / row 3 / column 2"]} -->
c) 应具备向公共服务平台提供中标通知书和招标结果通知书的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00141", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 376", "document order / paragraph 381", "document order / table 44 / row 2 / column 1"]} -->
d) 中标通知书和招标结果通知的数据项格式详见附录A.1.18。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00142", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8.5 资格预审结果通知书

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00143", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 382", "document order / paragraph 645", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 3 / column 1", "document order / paragraph 647", "document order / table 2 / row 1 / column 1", "document order / table 2 / row 4 / column 1"]} -->
a) 资格预审结果通知书的管理应满足 5.8.4 中 a)、b)、c)的规定。数据项应包括：招标人、招标代理机构、招标项目名称及其编号、标段（包）编号、资格预审通过单位名称、资格预审通知书发出时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00144", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 382", "document order / paragraph 384", "document order / paragraph 667"]} -->
b) 资格预审结果通知书的数据项格式详见附录 A.1.19。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00145", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8.6 合同

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00146", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 386"]} -->
合同管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00147", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 385", "document order / paragraph 387", "document order / paragraph 645", "document order / paragraph 647", "document order / paragraph 649", "document order / table 53 / row 4 / column 1"]} -->
a) 应提供招标项目标段（包）与合同的关联关系。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00148", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 385", "document order / paragraph 388", "document order / table 53 / row 3 / column 1"]} -->
b) 应具备根据法律法规规章和招标文件约定的内容，编辑、形成、递交、验证确认和签署合同文本的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00149", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 385", "document order / paragraph 389", "document order / table 62 / row 2 / column 2"]} -->
c) 应具备向公共服务平台提供规定要求的合同信息的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00150", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 385", "document order / paragraph 390"]} -->
d) 宜具备按规定要求向相关主体和管理单位收集、记录和验证合同履行结果的相关信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00151", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 385", "document order / paragraph 391", "document order / table 44 / row 2 / column 1"]} -->
e) 合同的数据项格式详见附录 A.1.20。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00152", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.9 费用管理

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00153", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 393"]} -->
费用管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00154", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 394", "document order / table 53 / row 4 / column 1"]} -->
a) 应具备招投标过程中各类费用的支付结算、退还的信息管理及控制后续相关程序等管理功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00155", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 267", "document order / paragraph 285", "document order / paragraph 302", "document order / paragraph 324", "document order / paragraph 395", "document order / paragraph 711", "document order / table 53 / row 3 / column 1"]} -->
b) 费用类型包括资格预审文件费用、招标文件费用、图纸押金、投标保证金及其利息、履约保证金、招标代理服务费、交易服务费、评标专家咨询费等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00156", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 396"]} -->
c) 应具备选择多种支付结算方式的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00157", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 397"]} -->
d) 宜具备支持网上电子支付结算的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00158", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.10 异议

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00159", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 399"]} -->
异议管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00160", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 267", "document order / paragraph 285", "document order / paragraph 307", "document order / paragraph 324", "document order / paragraph 398", "document order / paragraph 400", "document order / table 53 / row 3 / column 2"]} -->
a) 应具备投标人对资格预审文件、招标文件、开标过程、资格预审结果、评标结果按规定的时间提出异议的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00161", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 398", "document order / paragraph 401", "document order / table 53 / row 2 / column 2", "document order / table 53 / row 3 / column 1", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 2 / column 2", "document order / table 59 / row 5 / column 2"]} -->
b) 应具备招标人在规定的时间内答复投标人异议的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00162", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 398", "document order / paragraph 402", "document order / table 44 / row 2 / column 1"]} -->
c) 异议的数据项格式详见附录 A.1.21。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00163", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.11 招标异常

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00164", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 404"]} -->
招标异常管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00165", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 405", "document order / table 53 / row 4 / column 1"]} -->
a) 应具备招标终止功能及招标终止公告的编辑、提交和发布功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00166", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 267", "document order / paragraph 406", "document order / table 50 / row 2 / column 2", "document order / table 50 / row 3 / column 2", "document order / table 53 / row 3 / column 1"]} -->
b) 宜具备重新发布招标公告或资格预审公告、资格预审文件或招标文件，并保留已完成招标程序的相关数据的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00167", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 407", "document order / paragraph 645", "document order / paragraph 647", "document order / table 2 / row 9 / column 1", "document order / table 44 / row 4 / column 2", "document order / table 49 / row 4 / column 2", "document order / table 50 / row 4 / column 2"]} -->
c) 宜具备招标项目按有关规定改用非招标方式后，记录其他交易方式和成交结果的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00168", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 403", "document order / paragraph 408", "document order / paragraph 670", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 49 / row 2 / column 1"]} -->
d) 招标异常情况报告的数据项格式详见 A.1.22。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00169", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.12 存档、归档

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00170", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 410"]} -->
存档、归档管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00171", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 285", "document order / paragraph 411", "document order / table 53 / row 4 / column 1"]} -->
a) 应具备按照有关规定和招标文件的要求对招标投标数据和文件、活动记录进行存档的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00172", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 412", "document order / table 53 / row 3 / column 1"]} -->
b) 应具备数据和文件的分类、整理和归档的功能。数据和文件的归档应符合国家有关电子档案的规定。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00173", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 413"]} -->
c) 应具备按权限查阅招标投标数据和文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00174", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 409", "document order / paragraph 414"]} -->
d) 应具备记录、备份、存档、归档电子招标投标中涉及的操作时间和人员的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00175", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 324", "document order / paragraph 415", "document order / table 9 / row 5 / column 1", "document order / table 12 / row 14 / column 1", "document order / table 44 / row 4 / column 1", "document order / table 48 / row 4 / column 1", "document order / table 49 / row 4 / column 1"]} -->
e) 应具备评标全过程录像自投标有效期结束之日起存档 90日以上的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00176", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.13 监督

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00177", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.13.1 接受监督

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00178", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 418"]} -->
按照招标投标法律法规规章和监督部门的要求，应具备通过公共服务平台的行政监督通道或直接通过行政监督平台，适时与监督部门交换相关数据和文件的功能，并满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00179", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 81", "document order / paragraph 222", "document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 645"]} -->
a) 提交招标人和招标项目的基本情况，以及经核准的招标内容与范围、招标方式、招标组织形式。数据项格式详见附录 A.1.1、A.1.2、A.1.3。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00180", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 238", "document order / paragraph 248", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 285", "document order / paragraph 306"]} -->
b) 提交资格预审公告、招标公告或者投标邀请书。数据项格式详见附录 A.1.4、A.1.5。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00181", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 257", "document order / paragraph 266", "document order / paragraph 267", "document order / paragraph 270", "document order / paragraph 306", "document order / table 44 / row 2 / column 1"]} -->
c) 提交资格预审文件、招标文件。数据项格式详见附录 A.1.6、A.1.9。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00182", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 44 / row 4 / column 1"]} -->
d) 提交资格审查委员会名单和资格预审结果报告。资格审查委员会数据项格式详见附录 A.2.9、A.2.10，资格预审结果数据项格式详见附录 A.1.8。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00183", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 307", "document order / paragraph 423", "document order / paragraph 659", "document order / paragraph 661", "document order / table 44 / row 2 / column 1", "document order / table 48 / row 2 / column 1", "document order / table 49 / row 2 / column 1"]} -->
e) 提交投标文件验证、解密及展示、投标人确认等开标过程和开标记录的信息。数据项格式详见 A.1.14。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00184", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 348"]} -->
f) 提交评标委员会名单、评标报告和中标候选人。数据项格式详见附录 A.2.9、A.2.10、A.1.15、A.1.16。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00185", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 366", "document order / paragraph 663", "document order / paragraph 665"]} -->
g) 提交中标候选人公示和中标结果。数据项格式详见附录A.1.17、A.1.29。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00186", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 385", "document order / paragraph 426", "document order / paragraph 668"]} -->
h) 提交合同和履行信息。数据项格式详见附录 A.1.20。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00187", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 403", "document order / paragraph 427", "document order / table 44 / row 2 / column 1"]} -->
i) 提交招标异常的有关情况。需要审批或核准的，提交相关审批或核准信息。数据项格式详见附录 A.1.22。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00188", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 416", "document order / paragraph 428"]} -->
j) 接收和执行有关行政监督部门监督指令的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00189", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.13.2 配合投诉处理

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00190", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 430"]} -->
配合投诉处理管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00191", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 431", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / paragraph 649", "document order / table 3 / row 1 / column 1", "document order / table 3 / row 3 / column 1", "document order / table 4 / row 1 / column 1", "document order / table 5 / row 1 / column 1"]} -->
a) 宜具备编辑、提交投诉事项有关信息、接收、查询投诉受理情况和处理结果的功能。投诉时限应满足相关规定的要求。投诉处理的数据项应包括标段（包）编号、投诉人代码、投诉人名称、投诉内容、理由和依据、投诉提交时间、投诉受理人、受理时间、处理结果、反馈时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00192", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 432", "document order / table 53 / row 3 / column 1", "document order / table 62 / row 2 / column 2"]} -->
b) 宜具备向公共服务平台提供投诉处理数据和文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00193", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / paragraph 433", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1"]} -->
c) 投诉处理的数据项格式详见附录 A.1.21。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00194", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 6 交易平台信息资源库

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00195", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 435"]} -->
信息资源库采集整合的要素信息，仅限于政府有关网站、平台公布的信息和电子招标投标系统上记录并经过验证、交换、公布的信息，主要是电子招标投标交易平台上成交的项目及其相关主体的要素信息。除上述来源以外采集的信息和投标人在投标文件中提供的以纸质形式完成招标投标的中标项目业绩信誉、从业人员业绩信誉等信息，仅限于该招标项目中一次使用，禁止转入交易平台信息资源库分类集合，也不得用于对外查询、公布、交换及统计。但是，交易平台可以另行建立辅助信息资源库集中此类非可靠信息，仅限于内部交换和参考，且应当注明信息采集来源和相关责任人员。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00196", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 6.1 招标项目信息库

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00197", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 437"]} -->
招标项目信息库管理应满足如下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00198", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 81", "document order / paragraph 221", "document order / paragraph 222", "document order / paragraph 438", "document order / paragraph 645", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 1 / column 2", "document order / table 1 / row 2 / column 1"]} -->
a) 应具备招标项目信息的建立和维护的功能。数据项应包括项目名称、项目编号、项目行业分类代码、项目所在行政区域代码、法定代表人、招标交易平台代码、招标项目编号、招标项目名称、招标内容与范围和招标方案说明及附件、招标人代码、招标代理机构代码，以及进行信息交换的公共服务平台标识码等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00199", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 376", "document order / paragraph 385", "document order / paragraph 439", "document order / paragraph 645", "document order / paragraph 649", "document order / table 3 / row 3 / column 1", "document order / table 3 / row 5 / column 1"]} -->
b) 应具备标段（包）与中标信息建立和维护的功能。数据项应包括标段（包）编号、标段（包）内容、标段（包）分类代码、投标人资格条件、中标人代码、中标价格、项目负责人、项目质量要求、项目工期（交货期）、中标通知书编号、合同订立价格，合同结算价格、合同验收质量、合同履行期限等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00200", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 307", "document order / paragraph 366", "document order / paragraph 385", "document order / paragraph 440", "document order / paragraph 645", "document order / paragraph 647", "document order / table 2 / row 11 / column 1"]} -->
c) 应具备招标项目相关时间信息的建立和维护功能。数据项应包括招标项目建立时间、公告发布时间、开标时间、中标候选人公示时间、中标通知时间、签约时间、合同完成时间等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00201", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1"]} -->
d) 数据项格式详见附录 A.1.1、A.1.2、A.1.3、A.1.4、A.1.18、A.1.20。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00202", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 6.2 招标人信息库

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00203", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 443"]} -->
招标人信息库管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00204", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 444", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / table 2 / row 7 / column 1", "document order / table 2 / row 7 / column 2", "document order / table 2 / row 8 / column 2", "document order / table 2 / row 17 / column 1", "document order / table 3 / row 1 / column 1"]} -->
a) 应具备招标人信息建立和维护的功能。数据项应包括招标人代码、招标人名称、负责人、国别/地区、行业代码、营业执照号码、CA 证书编号、组织机构代码、税务登记号、开户银行、基本账户账号、注册资本、币种、信息申报责任人、联系电话、联系地址、邮政编码、电子邮箱等信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00205", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 445", "document order / table 53 / row 2 / column 2", "document order / table 53 / row 3 / column 1", "document order / table 59 / row 2 / column 2"]} -->
b) 应具备招标人招标业绩、奖惩、履约记录等信息管理的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00206", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 446", "document order / table 53 / row 2 / column 2", "document order / table 59 / row 2 / column 2"]} -->
c) 应具备招标人信息的检索和统计分析的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00207", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1"]} -->
d) 数据项格式详见附录 A.2.1, A.2.3、A.2.8、A.1.20。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00208", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 6.3 招标代理机构信息库

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00209", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 449"]} -->
招标代理机构信息库管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00210", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 450", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / table 2 / row 7 / column 2", "document order / table 2 / row 8 / column 2", "document order / table 2 / row 17 / column 1", "document order / table 3 / row 1 / column 1", "document order / table 4 / row 1 / column 1"]} -->
a) 应具备招标代理机构信息建立和维护的功能。数据项应包括代理机构代码、代理机构名称、负责人、国别/地区、资质类别、资质等级、营业执照号码、CA 证书编号、组织机构代码、税务登记号、开户银行、基本账户、注册资本、信息申报责任人、联系电话、联系地址、邮政编码、电子邮箱等信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00211", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 451", "document order / paragraph 707", "document order / table 53 / row 3 / column 1", "document order / table 53 / row 4 / column 2", "document order / table 54 / row 10 / column 2", "document order / table 59 / row 3 / column 2"]} -->
b) 应具备招标代理机构电子招标业绩、奖惩记录和履约记录等信息管理的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00212", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 452", "document order / paragraph 645", "document order / table 30 / row 7 / column 1", "document order / table 30 / row 19 / column 1", "document order / table 30 / row 21 / column 1", "document order / table 33 / row 3 / column 1", "document order / table 33 / row 4 / column 1", "document order / table 33 / row 5 / column 1"]} -->
c) 应具备招标职业资格人员的相关信息管理的功能。数据项包括姓名、性别、身份证件类型、身份证件号码、出生年月、所在行政区域代码、最高学历、联系电话、通讯地址、邮政编码、所在单位、职务、职业证书编号、注册登记证书编号、从业年限、项目业绩、奖惩记录等信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00213", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 453", "document order / table 53 / row 4 / column 2", "document order / table 54 / row 10 / column 2", "document order / table 59 / row 3 / column 2"]} -->
d) 应具备招标代理机构信息的检索和统计分析的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00214", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1"]} -->
e) 数据项格式详见附录 A.2.1、A.2.2、A.2.3、A.2.4、A.2.5、A.2.6、A.2.8、A.1.20。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00215", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 6.4 投标人信息库

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00216", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 456"]} -->
投标人信息库管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00217", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 457", "document order / table 1 / row 1 / column 1", "document order / table 2 / row 1 / column 1", "document order / table 2 / row 7 / column 2", "document order / table 2 / row 8 / column 2", "document order / table 3 / row 1 / column 1", "document order / table 4 / row 1 / column 1"]} -->
a) 应具备投标人信息建立和维护的功能。数据项按不同主体应相应包括：投标人代码、投标人名称、负责人、国别/地区、资质序列、资质等级、资信等级、奖惩记录、营业执照号码、CA 证书编号、组织机构代码、税务登记号、开户银行、基本账户账号、注册资本、注册资本币种、信息申报和变更责任人、联系电话、联系地址、邮政编码、电子邮箱等信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00218", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 458", "document order / table 53 / row 3 / column 1", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 5 / column 2"]} -->
b) 应具备投标人中标业绩明细数据、奖惩与履约等信息归集的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00219", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 459", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 5 / column 2"]} -->
c) 应具备投标人信息的检索和统计分析的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00220", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 460", "document order / table 53 / row 3 / column 2", "document order / table 59 / row 5 / column 2"]} -->
d) 应具备投标人黑名单的建立和管理的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00221", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 461", "document order / paragraph 645", "document order / table 30 / row 7 / column 1", "document order / table 30 / row 19 / column 1", "document order / table 30 / row 21 / column 1", "document order / table 33 / row 3 / column 1", "document order / table 33 / row 4 / column 1"]} -->
e) 应具备投标人专业职业资格人员（注册建造师、注册监理工程师等）的相关信息管理的功能。数据项包括姓名、性别、身份证件类型、身份证件号码、出生年月、所在行政区域代码、最高学历、联系电话、通讯地址、邮政编码、所在单位、职务、技术职称、职业资格序列、职业资格等级、职业证书编号、从业经历、从业年限、项目业绩、奖惩记录等信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00222", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 237", "document order / paragraph 255", "document order / paragraph 266", "document order / paragraph 270", "document order / paragraph 306", "document order / table 44 / row 2 / column 1", "document order / table 44 / row 3 / column 1", "document order / table 48 / row 2 / column 1"]} -->
f) 数据项格式详见附录 A.2.1、A.2.2、A.2.4、A.2.5、A.2.6、A.2.7、A.2.8、A.1.20。

## chunk-005-pages-0081-0100.pdf — original pages 81-100

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00001", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.12 投标文件

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00002", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 12"]} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">投标人代码</td><td colspan="1" rowspan="1">组织机构代码</td><td colspan="1" rowspan="1">采                 用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">投标文件附件关联标识号</td><td colspan="1" rowspan="1">关联到附件表的多条记录</td><td colspan="1" rowspan="1">附录B.3.7附件关联标识号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">投标报价金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">投标报价币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">投标报价单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.25金额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">工期(交货期)</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..4</td></tr><tr><td colspan="1" rowspan="1">投标保证金形式</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">投标保证金金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">投标保证金币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">投标保证金单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.25金额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">投标单位项目负责人</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">投标有效期</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..3</td></tr><tr><td colspan="1" rowspan="1">投标时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">投标排序</td><td colspan="1" rowspan="1">按投标时间排序</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..2</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00003", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.13 投标保证金记录

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00004", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 13"]} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">投标人代码</td><td colspan="1" rowspan="1">组织机构代码</td><td colspan="1" rowspan="1">采                 用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">投标人名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">保证金支付形式</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">保证金金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">保证金币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">保证金单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.25金额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">保证金凭证接收时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">保证金到账时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">保证金退还时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00005", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 257", "document order / paragraph 285", "document order / paragraph 302", "document order / paragraph 307", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 1 / column 2", "document order / table 1 / row 1 / column 3", "document order / table 1 / row 1 / column 4"]} -->
A.1.14 开标记录
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>开标参与人</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.500</td></tr><tr><td rowspan=1 colspan=1>开标记录内容</td><td rowspan=1 colspan=1>包括投标人名称、报价、工期(交货期)、投标保证金额、投标文件递交时间等招标文件所规定的唱标内容</td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表的多条记录</td><td rowspan=1 colspan=1>附录 B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>开标时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00006", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 285", "document order / paragraph 324", "document order / paragraph 348", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 1 / column 2", "document order / table 1 / row 1 / column 3", "document order / table 1 / row 1 / column 4", "document order / table 1 / row 1 / column 5"]} -->
A.1.15 评标报告
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>评标报告正文</td><td rowspan=1 colspan=1>包含中标候选人名称及排名、投标价格、评分结果或评标价格、中标价格等内容</td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.ul</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>评标报告各附件资料，关联到附件表的多条记录</td><td rowspan=1 colspan=1>附录 B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>提交时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00007", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.16 中标候选人

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00008", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 87", "document order / paragraph 285", "document order / paragraph 324", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 1 / column 2", "document order / table 1 / row 1 / column 3", "document order / table 1 / row 1 / column 4", "document order / table 1 / row 1 / column 5"]} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">中标候选人名称</td><td colspan="1" rowspan="1">每个中标候选人一条记录</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">中标候选人代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">中标候选人排名</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..10</td></tr><tr><td colspan="1" rowspan="1">投标价格</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">评分结果</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">评标价格</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">中标价格</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">价格币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">价格单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.25金|字符型额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00009", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 664"]} -->
注：每个中标候选人都应在此表中对应一条独立的数据记录。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00010", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 366", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 1 / column 2", "document order / table 1 / row 1 / column 3", "document order / table 1 / row 1 / column 4", "document order / table 1 / row 1 / column 5", "document order / table 1 / row 2 / column 4", "document order / table 1 / row 3 / column 3"]} -->
A.1.17 中标候选人公示
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.5 标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>公示类型</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.13 公示类型代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C1</td></tr><tr><td rowspan=1 colspan=1>公示开始时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>公示结束时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>公示内容</td><td rowspan=1 colspan=1>多个中标候选人一并显示</td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>公示提交时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00011", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.18 中标/招标结果通知书

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00012", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 87", "document order / paragraph 285", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 1 / column 2", "document order / table 1 / row 1 / column 3", "document order / table 1 / row 1 / column 4", "document order / table 1 / row 1 / column 5", "document order / table 1 / row 2 / column 4"]} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">通知书类型</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.26通知书类型代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">中标/招标结果通知书编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.50</td></tr><tr><td colspan="1" rowspan="1">中标人/未中标人名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">中标人/未中标人代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">中标/投标价格</td><td colspan="1" rowspan="1">对中标人，填入中标价格；对未中标人，填入投标价格</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">价格币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用   GB/T字符型12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">GB/T字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">价格单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.25金额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">通知书文本</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">附件关联标识号</td><td colspan="1" rowspan="1">关联到附件表的多条记录</td><td colspan="1" rowspan="1">附录 B.3.7附件关联标识号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.50</td></tr><tr><td colspan="1" rowspan="1">发出时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00013", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 87", "document order / paragraph 382", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 1 / column 2", "document order / table 1 / row 1 / column 3", "document order / table 1 / row 1 / column 4", "document order / table 1 / row 1 / column 5", "document order / table 1 / row 2 / column 4"]} -->
A.1.19 资格预审结果通知书
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.5 标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>资格预审通过单位名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>资格预审通过单位代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>采用GB11714-1997《全国组织机构代码编制规则》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C9</td></tr><tr><td rowspan=1 colspan=1>通知书文本</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.ul</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表的多条记录</td><td rowspan=1 colspan=1>附录 B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>发出时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00014", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.20 合同和履行

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00015", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 20"]} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">招标人代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">中标人代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">合同金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">金额币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">金额单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.25金额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">合同期限</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N.4</td></tr><tr><td colspan="1" rowspan="1">质量要求</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">合同主要内容</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">合同签署时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">附件关联标识号</td><td colspan="1" rowspan="1">关联到附件表的多条记录</td><td colspan="1" rowspan="1">附录 B.3.7附件关联标识号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">合同结算金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">履约变更内容</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">合同完成时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">实际履约期限</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..4</td></tr><tr><td colspan="1" rowspan="1">履约信息递交时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00016", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.21 异议与投诉

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00017", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 87", "document order / paragraph 398", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 1 / column 2", "document order / table 1 / row 1 / column 3", "document order / table 1 / row 1 / column 4", "document order / table 1 / row 1 / column 5", "document order / table 1 / row 2 / column 4"]} -->
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>异议或投诉人代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>采用GB11714-1997《全国组织机构代码编制规则》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C9</td></tr><tr><td rowspan=1 colspan=1>异议或投诉人名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>依据和理由</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>异议与投诉内容</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表的多条记录</td><td rowspan=1 colspan=1>附录B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>提交时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>异议或投诉受理人</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..20</td></tr></table>

## chunk-007-pages-0121-0140.pdf — original pages 121-140

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00001", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.4 职业人员基本信息

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00002", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 33"]} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">职业人员代码</td><td colspan="1" rowspan="1">取身份证号码</td><td colspan="1" rowspan="1">采用 GB 11643 -1999《公民身份号码》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C18</td></tr><tr><td colspan="1" rowspan="1">姓名</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">性别</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用 GB/T 2261.1-2003《个人基本信息分类与代码第1部分人的性别代码》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">出生年月</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDD</td></tr><tr><td colspan="1" rowspan="1">所在行政区域代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用 GB/T 2260-2007《中华人民共和国行政区划代码》的市级代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">最高学历</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">联系电话</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">通讯地址</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.50</td></tr><tr><td colspan="1" rowspan="1">邮政编码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">所在单位代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">所在单位名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">是否在职</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.12是否代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..10</td></tr><tr><td colspan="1" rowspan="1">职务</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">技术职称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">从业经历</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.ul</td></tr><tr><td colspan="1" rowspan="1">从业年限</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..2</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00003", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.5 人员职业资格信息

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00004", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 34"]} -->
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>职业人员代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>采用     GB11643 - 1999《公民身份号码》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C18</td></tr><tr><td rowspan=1 colspan=1>职业资格序列</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>职业资格等级</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>资格资格证书编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>注册登记证书编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00005", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.6 人员业绩信息

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00006", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 95", "document order / paragraph 385", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 1 / column 2", "document order / table 1 / row 1 / column 3", "document order / table 1 / row 1 / column 4", "document order / table 1 / row 1 / column 5", "document order / table 1 / row 2 / column 4"]} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">职业人员代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用 GB11643 -1999《公民身份号码》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C18</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.5标段字符型（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">标段（包）名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">招标人代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用 GB 11714-1997中的代码编制规则</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">招标人名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">合同金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">结算金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">金额币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用 GB/T12406-2008中的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">金额单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.25价格单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">合同签署时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">合同完成时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00007", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 702", "document order / paragraph 705"]} -->
备注：业绩仅限于在电子招投标交易平台上成交的项目。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00008", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.7 投标人业绩

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00009", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 222", "document order / paragraph 285", "document order / paragraph 385", "document order / paragraph 645", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 1 / column 2", "document order / table 1 / row 1 / column 3", "document order / table 1 / row 1 / column 4"]} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">投标人代码</td><td colspan="1" rowspan="1">组织机构代码</td><td colspan="1" rowspan="1">采用    GB11714-1997中的代码编制规则</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">中标项目的标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">中标项目和标段（包）名称</td><td colspan="1" rowspan="1">按照招标项目和标段(包)的名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">招标人代码</td><td colspan="1" rowspan="1">组织机构代码</td><td colspan="1" rowspan="1">采用    GB11714-1997中的代码编制规则</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">招标人名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">中标金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">合同金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">合同结算金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">合同期限</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..4</td></tr><tr><td colspan="1" rowspan="1">实际履行期限</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..4</td></tr><tr><td colspan="1" rowspan="1">金额币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用（GB/T字符型12406-2008中的数字码</td><td colspan="1" rowspan="1">GB/T字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">金额单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.25价格单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">合同签署时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00010", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 702", "document order / paragraph 705"]} -->
备注：业绩仅限于在电子招投标交易平台上成交的项目。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00011", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.8 奖惩记录

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00012", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 37"]} -->
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>奖惩对象代码</td><td rowspan=1 colspan=1>单位取组织机构代码；个人取身份证号码</td><td rowspan=1 colspan=1>采用      GB11714-1997中的代码编制规则和GB11643 - 1999《公民身份号码》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..18</td></tr><tr><td rowspan=1 colspan=1>奖惩对象类型</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.18奖惩对象类型代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C1</td></tr><tr><td rowspan=1 colspan=1>奖惩时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>奖惩内容</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>奖惩类型</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.19奖惩类型代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C1</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00013", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / paragraph 708", "document order / table 44 / row 3 / column 1", "document order / table 44 / row 4 / column 1", "document order / table 48 / row 3 / column 1", "document order / table 48 / row 4 / column 1", "document order / table 49 / row 3 / column 1"]} -->
## A.2.9 资格审查委员会/评标委员会组建申请

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00014", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 38"]} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">组建申请编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.22评标委员会组建申请编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.20</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">专家库名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..500</td></tr><tr><td colspan="1" rowspan="1">专家抽取要求</td><td colspan="1" rowspan="1">包含专业分类代码、行政区域代码、专家人数、专家等级、回避条件等抽取说明</td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">评审时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">评审地点</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">抽取时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">抽取人姓名</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00015", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / paragraph 324", "document order / paragraph 325", "document order / table 1 / row 1 / column 1", "document order / table 1 / row 1 / column 2", "document order / table 1 / row 1 / column 3", "document order / table 1 / row 1 / column 4", "document order / table 1 / row 1 / column 5", "document order / table 1 / row 2 / column 4"]} -->
A.2.10 资格审查委员会/评标委员会成员
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>组建申请编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.20评标委员会组建申请编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..20</td></tr><tr><td rowspan=1 colspan=1>专家编号</td><td rowspan=1 colspan=1>如果是专家库成员，需要有此编号</td><td rowspan=1 colspan=1>附录B.3.22专字符型家编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>C17</td></tr><tr><td rowspan=1 colspan=1>专家姓名</td><td rowspan=1 colspan=1>如果是招标人代表，填入姓名</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>专家类型</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.21专字符型家类型代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C1</td></tr><tr><td rowspan=1 colspan=1>通知方式</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>通知时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>专家考核记录</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00016", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.11 评标专家

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00017", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 40"]} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">专家编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.22专家编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C17</td></tr><tr><td colspan="1" rowspan="1">姓名</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">性别</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用 GB/T 2261.1-2003 中人的性别代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">身份证件类型</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.16身份证件类型代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C2</td></tr><tr><td colspan="1" rowspan="1">身份证件号码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11643-1999《公民身份号码》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C18</td></tr><tr><td colspan="1" rowspan="1">出生年月</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDD</td></tr><tr><td colspan="1" rowspan="1">所在行政区域代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T 2260-2007中的市级代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">最后毕业院校</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">最高学历</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..30</td></tr><tr><td colspan="1" rowspan="1">联系电话</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">通讯地址</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">邮政编码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">所在单位名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">是否在职</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.12是否代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">职务</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">工作简历</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">专业分类</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用《评标专家专业分类标准 (试行)》中约定的代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">技术职称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">职业资格序列</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.50</td></tr><tr><td colspan="1" rowspan="1">职业资格等级</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">从业年限</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..2</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00018", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.3 交易平台或公共服务平台

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00019", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / table 41"]} -->
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>交易平台或公共服务平台代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.1交易平台标识代码；附录 B.3.23 公共服务平台标识代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C11</td></tr><tr><td rowspan=1 colspan=1>平台类型</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.24平台类型代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C1</td></tr><tr><td rowspan=1 colspan=1>平台名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>运营机构代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>采用    GB11714-1997中的代码编制规则</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C9</td></tr><tr><td rowspan=1 colspan=1>运营机构名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>CA证书编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.50</td></tr><tr><td rowspan=1 colspan=1>系统访问地址</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..200</td></tr><tr><td rowspan=1 colspan=1>检测和认证报告附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表</td><td rowspan=1 colspan=1>附录 B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00020", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.4 数据项术语说明

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00021", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.4.1 值域

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00022", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 718"]} -->
值域是指数据项的有效取值范围。一般分为自由文本型、枚举型、代码型等。自由文本型表示没有特别规定的内容类型；枚举型指元数据元素有可枚举的取值；代码型指元数据元素能对应到某个代码表的代码列或名称列。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00023", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.4.2 数据类型和数据格式

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00024", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 720"]} -->
数据项允许值的数据类型及表示格式。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00025", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "anchor_match", "confidence": 0.86, "source_locators": ["document order / table 1 / row 1 / column 2", "document order / table 1 / row 1 / column 4", "document order / table 1 / row 1 / column 5", "document order / table 1 / row 2 / column 4", "document order / table 1 / row 3 / column 4", "document order / table 1 / row 4 / column 4", "document order / table 1 / row 5 / column 4", "document order / table 1 / row 6 / column 4"]} -->
<table><tr><td>数据类型</td><td>说明</td><td>数据格式</td></tr><tr><td>字符型</td><td>一切可以显示打 印的字符，包括 汉字、字母、数 字、各种符号、空 格等，不具有计 算能力。</td><td>以大写字母&quot;C&quot;代表字符型: CX:表示定长为“X”的字符 型数据元值; C..X:表示最长为&quot;X&quot;的字符 型数据元值； C..ul:表示长度不确定的字符 型数据元值。</td></tr></table>
