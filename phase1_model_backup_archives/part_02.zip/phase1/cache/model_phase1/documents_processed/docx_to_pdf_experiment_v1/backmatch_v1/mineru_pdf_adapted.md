# MinerU formatted-PDF branch with original DOCX locators

<!-- The formatted PDF is a derived parsing aid; original DOCX remains source authority. -->

## chunk-001-pages-0001-0020.pdf — original pages 1-20

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00001", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
# 电子招标投标系统技术规范

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00002", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
第 1 部分：交易平台技术规范

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00003", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
2013 年

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00004", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 目 录

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00005", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "long_or_merged_block_without_baseline_match"} -->
1 范围 .. 6  
2 规范性引用文件 6  
3 术语和定义 . 9  
4 交易平台结构 15  
4.1 电子招标投标系统架构图 . 15  
4.2 交易平台结构图. 16  
5 交易平台基本功能要求 16  
5.1 用户注册..  
5.2 招标方案. 18  
5.3 投标邀请.. . 20  
5.4 发标.. . 22  
5.5 投标.. 24  
5.6 开标.. 26  
5.7 评标.. 2 8  
5.8 定标.. 31  
5.9 费用管理.. 3 3  
5.10 异议.. . 34  
5.11 招标异常.. 34  
5.12 存档、归档.. 34  
5.13 监督.. 35  
6 交易平台信息资源库 . 37  
6.1 招标项目信息库.. 37  
6.2 招标人信息库. 38  
6.3 招标代理机构信息库. 3 9  
6.4 投标人信息库. 3 9  
6.5 专家信息库.. 41  
6.6 价格信息库.. 41  
7 交易平台的系统接口 42  
7.1 公共服务平台的接口. 4 2  
7.2 与行政监督平台的接口 . 42  
7.3 与专业工具软件的接口 . 43  
8 交易平台技术支撑与保障要求 .. 43  
8.1 接口技术要求. 4 3  
8.2 安全性.. . 46  
8.3 性能... . 50  
8.4 可靠性.. 51  
8.5 易用性.. . 51  
8.6 运行环境.. 5 2  
附录 A 数据项的基本要求 . . 55  
A.1 业务对象.. . 55  
A.2 招投标主体.. 113  
A.3 交易平台或公共服务平台 . 138  
A.4 数据项术语说明.. 140  
附录 B 编码总体规则 ... 142  
B.1 编码总体规则说明.. . 142  
B.2 通用编码... .. 143  
B.3 业务编码..... .... 144

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00006", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 前 言

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00007", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
《电子招标投标系统技术规范》依据招标投标法律法规规章，规定了电子招标投标系统的架构、基本功能、信息交换体系和技术保障的要求，促进电子招标投标信息的互联互通，提高招标投标活动的便捷性、安全性、规范性和统一性。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00008", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
《电子招标投标系统技术规范》分为两部分：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00009", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
第1 部分 交易平台技术规范；

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00010", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
第 2 部分 公共服务平台和行政监督平台的技术规范。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00011", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
本规范为第 1 部分。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00012", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 电子招标投标系统技术规范

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00013", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
第 1 部分：交易平台技术规范

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00014", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 1 范围

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00015", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
本规范规定电子招标投标交易平台的结构、基本功能、信息资源库、系统接口、技术支撑和保障以及数据项格式等方面的要求。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00016", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
本规范适用于电子招标投标交易平台整体或局部研发、应用、检测、认证和运营维护。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00017", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 2 规范性引用文件

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00018", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
以下文件的相关条款通过引用而成为本规范的内容。凡是加注日期的引用文件，其随后所有的修改或修订版（勘误的内容除外）均不适用于本规范，但鼓励根据本规范达成协议的各方经协商一致适用以下文件的修订版本。凡是未加注日期的引用文件，其修订版本应自动适用于本规范。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00019", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB 2887-2011 计算机场地通用规范

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00020", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB 11714-1997 全国组织机构代码编制规则

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00021", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB 17859-1999 计算机信息系统安全保护等级划分准则

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00022", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB 2312-1980 信息交换用汉字编码字符集 基本集

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00023", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB 13000-2010 信息技术 通用多八位编码字符集（UCS）

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00024", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB 18030-2005 信息技术 中文编码字符集

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00025", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB 2887-2000 电子计算机场地通用规范

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00026", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB 6650-1986 计算机机房用活动地板技术条件

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00027", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB 50500-2013 建设工程工程量清单计价规范

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00028", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB 11643－1999 公民身份号码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00029", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 17539-1998 电子数据交换标准化应用指南

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00030", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 4754-2011 国民经济行业分类

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00031", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 2659-2000 世界各国和地区名称代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00032", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 2260-2007 中华人民共和国行政区划代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00033", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 12402 经济类型分类与代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00034", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 12406 表示货币和资金的代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00035", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 19487-2004 电子政务业务流程设计方法通用规范

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00036", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 19715.1-2005 信息技术 信息技术安全管理指南

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00037", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 19716-2005 信息技术 信息安全管理实用规则

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00038", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 20269-2006 信息安全技术 信息系统安全管理要

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00039", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00040", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 20270-2006 信息安全技术 网络基础安全技术要

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00041", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00042", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 20271-2006 信息安全技术 信息系统通用安全技

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00043", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
术要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00044", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 18018-2007 信息安全技术 路由器安全技术要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00045", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 21064-2007 电子政务系统总体设计要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00046", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 1988-1998 信息技术 信息交换用七位编码字符

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00047", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
集

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00048", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 11457-2006 信息技术软件工程术语

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00049", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 12345-1990 信息交换用汉字编码字符集 辅助集

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00050", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 16260-2006 软件工程产品质量

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00051", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 17539-1998 电子数据交换标准化应用指南

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00052", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB 50174-2008 电子信息系统机房设计规范

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00053", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 9361-2011 计算机场地安全要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00054", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
CAS 185-2009(C) 多 CA 联机认证服务系统应用规范

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00055", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 50311-2007 综合布线系统工程设计规范

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00056", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 2261.1-2003 个人基本信息分类与代码 第 1 部分：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00057", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 3304-1991 中国各民族名称的罗马字母拼写法和代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00058", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 4658-2008 学历代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00059", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
GB/T 8561-2001 专业技术职务代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00060", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
评标专家专业分类标准（试行）（发改法规[2010]1538 号）

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00061", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3 术语和定义

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00062", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
下列术语和定义适用于本规范。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00063", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.1 电子招标投标 e-bidding

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00064", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
根据招标投标相关法律法规规章，以数据电文为主要载体，应用信息技术完成招标投标活动的过程。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00065", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
数据电文是指以电子、光学、磁或者类似手段生成、发送、接收或者储存的信息。本规范中的“电子文件”是指按照特定用途和规定的内容格式要求编辑生成的数据电文。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00066", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.2 交易平台 transaction platform

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00067", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标投标当事人通过数据电文形式完成招标投标交易活动的信息平台。交易平台主要用于在线完成招标投标全部交易过程，编辑、生成、对接、交换和发布有关招标投标数据信息，为行政监督部门和监察机关依法实施监督、监察和受理投诉提供所需的信息通道。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00068", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.3 公共服务平台 public service platform

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00069", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
为满足各交易平台之间电子招标投标信息对接交换、资源共享的需要，并为市场主体、行政监督部门和社会公众提供信息交换、整合和发布的信息平台。公共服务平台具有招标投标相关信息对接交换、发布、资格信誉和业绩验证、行业统计分析、连接评标专家库、提供行政监督通道等服务功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00070", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.4 行政监督平台 administrative supervision platform

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00071", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
行政监督部门和监察机关在线监督电子招标投标活动并与交易平台、公共服务平台对接交换相关监督信息的信息平台。行政监督平台应当公布监督职责权限、监督环节、程序、时限和信息交换等要求。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00072", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.5 监督通道 supervision channel

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00073", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
交易平台、公共服务平台为行政监督部门和监察机关依法在线监督、监察电子招标投标活动提供的信息通道。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00074", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.6 项目 project

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00075", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
为实现一定功能价值目标，在特定约束条件下一次性组织实施任务的活动过程，可以分为工程、货物、服务等项目，包含一个或多个招标项目。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00076", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.7 招标项目 tendering project

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00077", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
项目中组织实施一次招标投标全流程的基本单元，可以包括一个或多个标段（包）。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00078", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.8 标段（包）bid section (package)

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00079", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
根据实际需要，依据一定的约束条件及标准，对招标项目构成内容进行合理划分，成为最基本的交易管理单元。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00080", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.9 数据项 data item

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00081", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
电子招标投标系统中为满足功能控制、数据交换、信息共享的需要，反映业务对象特征属性的结构化数据。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00082", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.10 信息资源库 information resource database

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00083", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
电子招标投标系统中反映相关业务对象特征属性的数据

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00084", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
项，按照对接交换、查询发布、统计分析等特定功能需要和标准进行分类集合的数据库。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00085", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.11 招标项目计划 tendering project plan

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00086", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标人或招标代理机构根据招标方案编制的用于指导和控制招标实际工作的执行文件，主要包括招标项目内容、范围、招标方式、招标组织形式、主要工作内容、人员职责分工、工作质量和时间进度要求等内容。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00087", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.12 发标 issue of bidding documents

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00088", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标人按资格预审公告、招标公告或者投标邀请书载明的时间、地点发出资格预审文件或者招标文件的活动。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00089", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.13 黑名单 blacklist

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00090", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
违反有关法律法规规章规定的招标投标当事人名单。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00091", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.14 电子开标 online bid-opening

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00092", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
通过交易平台在线完成投标文件拆封解密、展示唱标内容并形成开标记录的工作程序。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00093", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.15 电子签名 e-signature

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00094", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
运用电子密码技术，在数据电文中以电子形式所含，用于识别签名人身份并表明签名人认可其中内容的数据。本规范中的“签署”是指招标投标当事人对数据电文进行电子签名的行为。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00095", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.16 电子印章 e-stamp

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00096", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
模拟在纸质文件上加盖传统实物印章的外观和方式进行

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00097", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
电子签名的形式。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00098", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.17 开标记录 bid opening record

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00099", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
记录参加开标的单位、人员、开标过程以及展示唱标内容等相关信息并经电子签名的数据文件。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00100", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.18 电子签到 sign-in

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00101", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
参与电子开标活动的相关人员通过交易平台完成签名报到并形成电子记录文档的工作。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00102", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.19 电子评标 e-bidding evaluation

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00103", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标项目评标委员会通过交易平台的电子评标系统，按照招标文件约定的评标标准和方法，对电子投标文件评审，并形成评标报告电子文件的工作程序。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00104", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.20 回执 receipt

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00105", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
电子文件接收人通过交易平台向发送人反馈的数据电文形式的签收单据。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00106", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.21 存档 filing

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00107", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
按招标投标有关规定和招标人的要求，在交易平台中生成、整理、保存、移交招标投标过程中产生的数据电文的工作。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00108", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.22 归档 e-archiving

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00109", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
按国家档案管理部门电子档案管理要求整理、保存、移交招标投标过程中产生的数据电文的工作。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00110", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.23 编辑 edit

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00111", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
运用交易平台提供的功能编写、修改、生成电子文件，或者利用其他专业工具生成并导入电子文件的工作。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00112", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.24 提交 submission

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00113", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标投标当事人向有关行政监督部门、项目管理部门或者当事人内部管理部门发送数据电文的行为。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00114", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.25 发布 issue

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00115", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标人向不特定的受众公布招投标活动中相关数据电文的行为。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00116", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.26 发出 sending out

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00117", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标人向招标投标当事人、参与人发送数据电文的行为。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00118", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.27 递交 delivery

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00119", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标投标当事人之间发送数据电文的行为。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00120", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.28 版式文件 formatted document

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00121", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
运用数据电文编辑和格式转换技术，使得不同电子阅读软件及设备和阅读软件上显示内容、版面格式固定一致，防止篡改的数据电文。电子招标投标中的大多数电子文件需要采用版式文件。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00122", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.29 CA 证书 certification authority certificate

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00123", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
经过有关部门认可的电子认证服务机构基于 PKI 技术签发、认证和管理的数字证书。CA 证书具有数据电文交换中身份识别、电子签名、加密解密等功能。CA 证书主要内容包括：证书服务机构的名称、证书持有人的名称及其签名验证数据、证书序列号、有效期、服务机构签名等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00124", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.30 专业工具软件 utility software

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00125", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
与交易平台兼容对接，用于制作、生成招标项目工程量清单、投标工程量清单报价以及工程投标报价评标分析的工程计价系统软件。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00126", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.31 投标文件制作软件 bidding document creation software

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00127", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
投标人用于制作投标文件的专用客户端软件，是交易平台的组成部分，主要具备招标文件导入、投标文件内容编辑、文件格式转换、投标文件生成、分类整理等功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00128", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3.32 时间戳 time stamp

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00129", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
应用电子签名技术，对电子文件提供日期和时间信息的安全保护和证明。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00130", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 4 交易平台结构

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00131", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 4.1 电子招标投标系统架构图

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00132", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
电子招标投标系统由电子招标投标交易平台、电子招标投标公共服务平台、电子招标投标行政监督平台三个部分组成。三个平台的主要功能和架构关系如下图所示：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00133", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "non_text_block", "confidence": 0.0, "source_locators": [], "gate_block_reason": "non_text_block_without_text_locator"} -->
<!-- image-->

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00134", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 4.2 交易平台结构图

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00135", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
交易平台由基本功能、信息资源库、技术支撑与保障、公共服务接口、行政监督接口、专业工具接口、投标文件制作软件等构成，并通过接口与公共服务平台和行政监督平台相连接，其基本功能结构如下图所示。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00136", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "non_text_block", "confidence": 0.0, "source_locators": [], "gate_block_reason": "non_text_block_without_text_locator"} -->
<!-- image-->

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00137", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5 交易平台基本功能要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00138", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
交易平台基本功能应当按照招标投标业务流程要求设置，

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00139", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
包括用户注册、招标方案、投标邀请、资格预审、发标、投标、开标、评标、定标、费用管理、异议、监督、招标异常、归档（存档）等功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00140", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.1 用户注册

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00141", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.1.1 招标人注册

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00142", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标人注册管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00143", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 招标人注册信息数据项应满足 6.2 的要求。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00144", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备从公共服务平台公共信息资源数据库交换招标人注册信息的功能，并实现比对、排除重复，以及修正、验证确认、写入招标人信息库的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00145", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备记录注册信息的申报人员和交易平台验证人员的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00146", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备招标人绑定一个或多个 CA 证书的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00147", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应具备确定招标人唯一注册编码的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00148", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.1.2 招标代理机构注册

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00149", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标代理机构注册管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00150", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 招标代理机构注册信息数据项应满足 6.3 的要求。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00151", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备从公共服务平台公共信息资源数据库交换招标代理机构注册信息的功能，并实现比对、排除重复，以及修正、验证确认、写入招标代理机构信息库的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00152", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备记录注册信息的申报人员和交易平台验证人员的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00153", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备招标代理机构绑定一个或多个 CA 证书的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00154", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.1.3 投标人注册

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00155", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
投标人注册管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00156", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 投标人注册信息数据项应满足 6.4 的要求。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00157", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备从公共服务平台公共信息资源数据库交换投标人注册信息的功能，并实现比对、排除重复，以及修正、验证确认、写入投标人信息库的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00158", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备记录注册信息的申报人员和交易平台验证人员的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00159", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备投标人绑定一个或多个 CA 证书的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00160", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 宜具备投标人只能将电子印章绑定到一个 CA 证书的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00161", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.2 招标方案

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00162", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.2.1 招标项目

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00163", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标项目管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00164", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备项目相关信息的建立和递交功能。数据项应包括项目编号、项目名称、项目地址、项目法人、联系人及其联系方式、项目行业分类、资金来源、项目规模等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00165", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备招标项目相关信息的建立和递交功能。数据项应包括项目名称、招标项目编号、招标项目名称、招标人代码、招标代理机构代码、招标内容与范围及招标方案说明、招标方式、招标组织形式、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00166", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应建立项目与属于本项目下的招标项目之间的关联关系。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00167", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备招标项目标段（包）建立和修改等管理功能。数据项应包括招标项目编号、标段（包）编号、标段（包）名称、标段（包）内容、标段（包）分类代码、投标人资格条件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00168", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应建立招标项目与本招标项目下标段（包）的关联关系。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00169", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
f) 应具备根据招标委托合同设定招标项目代理机构职责和权限的功能。数据项应包括招标代理机构代码、招标代理机构名称、招标代理机构资格分类分级代码、招标代理内容、范围、权限、招标代理机构项目负责人及其职责权限和联系方式等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00170", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
g) 宜具备招标委托合同的编辑、递交和签署功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00171", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
h) 应具备向公共服务平台提供招标项目数据的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00172", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
i) 数据项格式详见附录 A.1.1、A.1.2、A.1.3、A.1.25。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00173", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.2.2 招标项目计划

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00174", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标项目计划管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00175", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备设定招标项目团队成员组成及其职责分工的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00176", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 宜具备招标项目任务计划的编制、报审、下达、调整等管理功能。数据项应包括招标项目编号和招标项目名称、标段（包）编号、工作任务计划、项目团队成员组成及其职责分工等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00177", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 数据项格式详见附录 A.1.26。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00178", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.3 投标邀请

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00179", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.3.1 招标公告与资格预审公告

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00180", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标公告与资格预审公告管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00181", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备公开招标项目采用资格后审的招标公告和采用资格预审的资格预审公告的编辑、提交、审核、验证确认和发布功能。招标公告数据项应包括招标项目编号、招标项目名称、相关标段（包）编号和投标资格、招标文件获取时间及获取方法、投标文件递交截止时间及递交方法、公告发布时间、附件等。资格预审公告数据项应包括招标项目编号、招标项目名称、相关标段（包）编号和投标资格、资格预审文件获取时间及获取方法、资格预审申请文件递交截止时间及递交方法、资格预审公告发布时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00182", "chunk_name": "chunk-001-pages-0001-0020.pdf", "original_page_scope": [1, 20], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应该具备记录招标公告和资格预审公告编辑、递交发布责任人和交易平台验证责任人的功能。

## chunk-002-pages-0021-0040.pdf — original pages 21-40

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00001", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备招标公告和资格预审公告同步递交到指定媒介发布的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00002", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备向公共服务平台同步提供招标公告和资格预审公告的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00003", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 招标公告和资格预审公告的数据项格式详见附录 A.1.4。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00004", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.3.2 投标邀请书

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00005", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
投标邀请书管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00006", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备从投标人信息库中获取满足投标资格条件或特定条件的潜在投标人的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00007", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备投标邀请书的编辑和发出功能。数据项应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00008", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
采用邀请招标的数据项包括标段（包）编号、标段（包）名称、投标资格、招标文件获取时间及获取方法、投标文件递交截止时间及递交方法、回复截止时间、投标邀请发出时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00009", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
采用资格预审的项目投标邀请书（代资格预审结果通知书）数据项包括标段（包）编号、标段（包）名称、招标文件获取时间及获取方法、投标文件递交截止时间及递交方法、回复截止时间、投标邀请发出时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00010", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备被邀请人接受和拒绝投标邀请的回复功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00011", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 数据项格式详见附录 A.1.5。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00012", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.4 发标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00013", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.4.1 招标文件

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00014", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标文件管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00015", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备招标文件的编辑、提交、审核、确认、备案、发出功能。数据项应包括标段（包）编号、投标资格、投标有效期、投标保证金、投标文件递交截止时间、投标文件递交方法、开标时间、开标方式、评标办法、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00016", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备按照标准文件或示范文本生成招标文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00017", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备设定投标文件主要内容、格式要求的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00018", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备设定投标文件递交截止时间（开标时间）及其控制的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00019", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应具备记录招标文件下载人、下载时间、下载次数的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00020", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
f) 宜具备将招标文件多个不同格式附件组合打包生成一个文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00021", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
g) 应具备向公共服务平台提供招标文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00022", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
h) 数据项格式详见附录 A.1.9。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00023", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.4.2 资格预审文件

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00024", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
资格预审文件的管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00025", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 资格预审文件的管理应满足 5.4.1 的规定。资格预审文件数据项应包括标段（包）编号、申请资格、申请有效期、

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00026", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
申请文件递交截止时间、申请文件递交方法、开启时间、开启方式、评审办法、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00027", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 数据项格式详见附录 A.1.6。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00028", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.4.3 踏勘现场

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00029", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
踏勘现场管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00030", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备现场踏勘通知的编辑、发出功能。数据项应包括招标项目编号、标段（包）编号、踏勘通知内容、踏勘发出时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00031", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备按招标文件约定的时间，向所有已获取招标文件的潜在投标人发出现场踏勘通知和提示现场踏勘时间的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00032", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备现场踏勘信息的记录功能。数据项应包括招标项目编号、标段（包）编号、踏勘单位名称及其代表姓名、踏勘时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00033", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 数据项格式详见附录 A.1.10、A.1.11。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00034", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.4.4 资格预审文件/招标文件澄清与修改

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00035", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
资格预审文件/招标文件（5.4.4 中统称“文件”）澄清与修改管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00036", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备文件澄清问题的编辑、递交功能。数据项应包括标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00037", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
段（包）编号、文件编号、要求澄清的问题、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00038", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备符合法律法规规章规定和招标文件约定的由资格预审申请人/投标人递交澄清问题的时间控制功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00039", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备招标人对文件的澄清与修改进行编辑、审核、发出的功能。数据项应包括标段（包）编号、澄清与修改文件编号、对文件澄清与修改的内容、澄清与修改递交时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00040", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备符合法律法规规章规定和招标文件约定的招标人递交澄清答复的时间控制功能，以及向所有已获取文件的潜在资格预审申请人/投标人发送通知，并以醒目方式公告澄清与修改内容的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00041", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应具备潜在资格预审申请人/投标人下载澄清与修改文件，并递交回执的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00042", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
f) 文件澄清问题的数据项格式详见附录 A.1.27，对资格预审文件的澄清与修改的数据项格式详见附录 A.1.6，对招标文件的澄清与修改的数据项格式详见附录 A.1.9。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00043", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.5 投标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00044", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.5.1 资格预审申请文件/投标文件

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00045", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
资格预审申请文件/投标文件（在 5.5.1 中统称“文件”）管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00046", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备在线或离线编辑和制作文件的功能，主要包括文件导入、文件内容编辑、工程量清单（如有）导入、版式文件转换、电子签章、文件生成、校验以及加密等功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00047", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
投标文件数据项应包括标段（包）编号、投标人代码、投标报价、工期（交货期）、投标有效期、投标保证金形式、投标保证金金额、投标单位项目负责人、投标时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00048", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
资格预审申请文件数据项应包括标段（包）编号、申请人代码、投标资格条件、项目负责人、申请时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00049", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备通过网络对文件递交、修改和撤回功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00050", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备按照招标文件中的递交截止时间控制文件递交、补充、修改和撤回的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00051", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备递交时间截止后，拒绝资格预审申请人/投标人递交、修改和撤回文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00052", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应具备拒绝接收递交时间截止时尚未完成传输的文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00053", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
f) 应具备对文件的主要数据项内容和格式进行校验的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00054", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
g) 应具备文件防篡改的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00055", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
h) 应具备投标人按照招标文件约定的加密方式选择按标段（包）分段或整体加密、递交文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00056", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
i) 应具备文件接收、校验、按接收时间排序和回执递交功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00057", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
j) 应具备拒收未按法律法规规章规定和招标文件要求递交的文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00058", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
k) 应具备禁止除资格预审申请人/投标人外的任何人在投标截止前解密、提取文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00059", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
l) 截止时间应使用国家授时中心标准时间。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00060", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
m) 宜动态显示国家授时中心当前时间。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00061", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
n) 投标文件数据项格式详见附录A.1.12, 资格预审申请文件数据项格式详见附录 A.1.7。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00062", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.5.2 投标保证金

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00063", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备记录和提示投标保证金接收、退还信息的功能。数据项应包括标段（包）编号、投标人代码、投标人名称、保证金金额、保证金支付形式、保证金凭证接收时间、保证金到账时间和保证金退还时间等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00064", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 宜具备投标保证金接收情况展示的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00065", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 宜具备按照招标文件要求对投标保证金支付形式、资金到账时间、金额、接收凭证等进行符合性校验的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00066", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 数据项格式详见附录 A.1.13。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00067", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.6 开标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00068", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.6.1 签到记录

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00069", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
应具备参加开标的人员通过网络远程办理电子签到的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00070", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.6.2 开标唱标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00071", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
开标唱标管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00072", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备开标时验证投标单位是否达到和显示法定数量,并 可以根据实际情况启动开标或取消开标的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00073", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备开标时验证并公布投标文件不被篡改、不遗漏及其投标过程记录的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00074", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备按开标时间规定控制投标文件解密并记录解密过程的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00075", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备招标人和投标人按照招标文件约定的解密方式解密投标文件以及解密失败时按规定补救方式执行的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00076", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应具备投标文件数据读取、记录、展示的功能。展示内容中应包括标段（包）编号、投标人名称、报价、工期（交货期）、投标保证金额、投标保证金到账时间、投标文件递交时间等招标文件所确定的唱标内容。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00077", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
f) 应具备开标过程信息的记录、编辑、参与单位电子签名确认和递交功能。数据项应包括标段（包）编号、开标参与单位名称、开标展示内容等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00078", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
g) 应具备开标记录经过电子签名确认后，通过交易平台向社会公众和公共服务平台同步交换、公布的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00079", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
h) 宜具备开标记录模板的编辑、修改、管理的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00080", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
i) 招标项目开标记录的数据项格式详见附录 A.1.14。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00081", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.6.3 资格预审文件的开启

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00082", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 资格预审文件的开启管理要求应符合 5.6.2 的规定。资格预审文件开启记录的数据项应包括标段（包）编号开启参与单位名称、开启时间、开启内容等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00083", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 资格预审文件开启数据项格式详见附录 A.1.28。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00084", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.7 评标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00085", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.7.1 评标委员会

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00086", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
评标委员会管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00087", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备申请依法组建评标委员会的功能。数据项应包括标段（包）编号、专家人数、行政区域代码、专业、等级、回避条件等组建要求。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00088", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备连接依法建立的专家库的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00089", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备通过公共服务平台连接的专家库通知评标委员会成员报到时间、地点的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00090", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备接收专家库反馈抽取评标专家名单，并据此设置评标委员会职责分工的功能，相关数据项应包括专家编号、专家姓名、通知时间、通知方式等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00091", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应具备评标委员会成员帐号生成、签到、身份确认、回避确认的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00092", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
f) 应具备评标专家行为考评记录，并递交到专家所属公共服务平台连接的专家库的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00093", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
g) 应提供评标委员会名单在评标前的保密功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00094", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
h) 评标委员会数据项格式详见附录 A.2.9、A.2.10。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00095", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.7.2 评审

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00096", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
评审管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00097", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备能够按招标文件约定的评标方法、评审因素和标准设置评审表格和评审项目的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00098", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备按招标文件约定的评标方法，对投标文件进行解析、对比，辅助评分或计算评标价的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00099", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备汇总计算投标人综合评分或评标价并进行排序的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00100", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备编辑和发出评标澄清问题的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00101", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应具备投标人编辑和递交投标澄清文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00102", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
f) 应具备依评审权限设置评审项目访问、信息阅读的功能，确保无相应权限者无法查阅或操作相关数据。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00103", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
g) 宜具备以下评审功能：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00104", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
按招标项目类型和评标办法设置、维护和管理评标模板。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00105", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
依据招标项目清单、标底总价、分项单价与投标报价进行校验、对比，提示差异。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00106", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
检测和辅助分析投标文件及异常投标行为。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00107", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
评标委员会成员打分结果的检测和辅助分析。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00108", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.7.3 评标报告

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00109", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
评标报告管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00110", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备评标报告编辑、阅读的权限设置、签署和提交功能。数据项应包括标段（包）编号、中标候选人名称及排名、投标价格、评分结果或评标价格、中标价格、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00111", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备向公共服务平台监督通道提供评标报告数据的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00112", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 评标报告的数据项格式详见附录 A.1.15、A.1.16。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00113", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.7.4 远程异地评标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00114", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
宜按以下要求具备网络远程异地评标的功能：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00115", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 对评标委员会实现有效的监控。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00116", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 对评标时间和地点进行控制。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00117", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 评标委员会评标必需的沟通功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00118", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.7.5 资格预审申请文件的评审

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00119", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 资格预审评审委员会的管理要求应符合 5.7.1 的规定。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00120", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 资格预审申请文件的评审管理要求应符合 5.7.2 的规定，其中有关价格评审功能不适用于资格预审申请文件的评审。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00121", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 资格预审结果文件的管理要求应符合 5.7.3 的规定。数据项应包括标段（包）编号、通过资格预审的申请人名单、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00122", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 资格预审申请文件的远程异地评审的管理要求应符合5.7.4 的规定。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00123", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应具备向公共服务平台监督通道提供资格预审结果文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00124", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
f) 资格预审结果文件的数据项格式详见附录 A.1.8

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00125", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8 定标

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00126", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8.1 中标候选人公示

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00127", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备中标候选人公示的编辑、提交审核、验证确认、备案、发布功能。数据项应包括：标段（包）编号、公示内容（含中标候选人名称及排序、投标价格、中标价格）、公示时间等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00128", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备向公共服务平台提供中标候选人公示数据的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00129", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 中标候选人公示的数据项格式详见附录 A.1.17。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00130", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8.2 确认资格预审的申请人/确定中标人

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00131", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备授权资格审查委员会确认通过资格预审的申请人/授权评标委员会确定中标人的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00132", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应提供招标人确认通过资格预审的申请人/确定中标人的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00133", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8.3 中标结果公告

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00134", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备编辑、提交审核、验证确认、备案、发布和向公共服务平台提供中标结果公告的功能。数据项应包括：标段（包）编号、标段（包）名称、中标人名称、中标价格、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00135", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 中标结果公告的数据项格式详见附录 A.1.29。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00136", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8.4 中标通知书

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00137", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
中标通知书管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00138", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备中标通知书和招标结果通知书的编辑、验证确认和递交的功能。数据项应包括：招标项目名称及其编号、标段（包）编号、中标人、中标价格、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00139", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 宜具备中标、未中标理由的编辑、确认、递交功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00140", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备向公共服务平台提供中标通知书和招标结果通知书的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00141", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 中标通知书和招标结果通知的数据项格式详见附录A.1.18。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00142", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8.5 资格预审结果通知书

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00143", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 资格预审结果通知书的管理应满足 5.8.4 中 a)、b)、c)的规定。数据项应包括：招标人、招标代理机构、招标项目名称及其编号、标段（包）编号、资格预审通过单位名称、资格预审通知书发出时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00144", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 资格预审结果通知书的数据项格式详见附录 A.1.19。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00145", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.8.6 合同

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00146", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
合同管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00147", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应提供招标项目标段（包）与合同的关联关系。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00148", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备根据法律法规规章和招标文件约定的内容，编辑、形成、递交、验证确认和签署合同文本的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00149", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备向公共服务平台提供规定要求的合同信息的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00150", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 宜具备按规定要求向相关主体和管理单位收集、记录和验证合同履行结果的相关信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00151", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 合同的数据项格式详见附录 A.1.20。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00152", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.9 费用管理

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00153", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
费用管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00154", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备招投标过程中各类费用的支付结算、退还的信息管理及控制后续相关程序等管理功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00155", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 费用类型包括资格预审文件费用、招标文件费用、图纸押金、投标保证金及其利息、履约保证金、招标代理服务费、交易服务费、评标专家咨询费等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00156", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备选择多种支付结算方式的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00157", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 宜具备支持网上电子支付结算的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00158", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.10 异议

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00159", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
异议管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00160", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备投标人对资格预审文件、招标文件、开标过程、资格预审结果、评标结果按规定的时间提出异议的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00161", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备招标人在规定的时间内答复投标人异议的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00162", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 异议的数据项格式详见附录 A.1.21。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00163", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.11 招标异常

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00164", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标异常管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00165", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备招标终止功能及招标终止公告的编辑、提交和发布功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00166", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 宜具备重新发布招标公告或资格预审公告、资格预审文件或招标文件，并保留已完成招标程序的相关数据的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00167", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 宜具备招标项目按有关规定改用非招标方式后，记录其他交易方式和成交结果的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00168", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 招标异常情况报告的数据项格式详见 A.1.22。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00169", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.12 存档、归档

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00170", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
存档、归档管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00171", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备按照有关规定和招标文件的要求对招标投标数据和文件、活动记录进行存档的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00172", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备数据和文件的分类、整理和归档的功能。数据和文件的归档应符合国家有关电子档案的规定。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00173", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备按权限查阅招标投标数据和文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00174", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备记录、备份、存档、归档电子招标投标中涉及的操作时间和人员的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00175", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应具备评标全过程录像自投标有效期结束之日起存档 90日以上的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00176", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.13 监督

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00177", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.13.1 接受监督

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00178", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
按照招标投标法律法规规章和监督部门的要求，应具备通过公共服务平台的行政监督通道或直接通过行政监督平台，适时与监督部门交换相关数据和文件的功能，并满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00179", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 提交招标人和招标项目的基本情况，以及经核准的招标内容与范围、招标方式、招标组织形式。数据项格式详见附录 A.1.1、A.1.2、A.1.3。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00180", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 提交资格预审公告、招标公告或者投标邀请书。数据项格式详见附录 A.1.4、A.1.5。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00181", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 提交资格预审文件、招标文件。数据项格式详见附录 A.1.6、A.1.9。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00182", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 提交资格审查委员会名单和资格预审结果报告。资格审查委员会数据项格式详见附录 A.2.9、A.2.10，资格预审结果数据项格式详见附录 A.1.8。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00183", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 提交投标文件验证、解密及展示、投标人确认等开标过程和开标记录的信息。数据项格式详见 A.1.14。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00184", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
f) 提交评标委员会名单、评标报告和中标候选人。数据项格式详见附录 A.2.9、A.2.10、A.1.15、A.1.16。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00185", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
g) 提交中标候选人公示和中标结果。数据项格式详见附录A.1.17、A.1.29。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00186", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
h) 提交合同和履行信息。数据项格式详见附录 A.1.20。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00187", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
i) 提交招标异常的有关情况。需要审批或核准的，提交相关审批或核准信息。数据项格式详见附录 A.1.22。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00188", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
j) 接收和执行有关行政监督部门监督指令的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00189", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 5.13.2 配合投诉处理

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00190", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
配合投诉处理管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00191", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 宜具备编辑、提交投诉事项有关信息、接收、查询投诉受理情况和处理结果的功能。投诉时限应满足相关规定的要求。投诉处理的数据项应包括标段（包）编号、投诉人代码、投诉人名称、投诉内容、理由和依据、投诉提交时间、投诉受理人、受理时间、处理结果、反馈时间、附件等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00192", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 宜具备向公共服务平台提供投诉处理数据和文件的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00193", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 投诉处理的数据项格式详见附录 A.1.21。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00194", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 6 交易平台信息资源库

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00195", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
信息资源库采集整合的要素信息，仅限于政府有关网站、平台公布的信息和电子招标投标系统上记录并经过验证、交换、公布的信息，主要是电子招标投标交易平台上成交的项目及其相关主体的要素信息。除上述来源以外采集的信息和投标人在投标文件中提供的以纸质形式完成招标投标的中标项目业绩信誉、从业人员业绩信誉等信息，仅限于该招标项目中一次使用，禁止转入交易平台信息资源库分类集合，也不得用于对外查询、公布、交换及统计。但是，交易平台可以另行建立辅助信息资源库集中此类非可靠信息，仅限于内部交换和参考，且应当注明信息采集来源和相关责任人员。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00196", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 6.1 招标项目信息库

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00197", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标项目信息库管理应满足如下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00198", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备招标项目信息的建立和维护的功能。数据项应包括项目名称、项目编号、项目行业分类代码、项目所在行政区域代码、法定代表人、招标交易平台代码、招标项目编号、招标项目名称、招标内容与范围和招标方案说明及附件、招标人代码、招标代理机构代码，以及进行信息交换的公共服务平台标识码等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00199", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备标段（包）与中标信息建立和维护的功能。数据项应包括标段（包）编号、标段（包）内容、标段（包）分类代码、投标人资格条件、中标人代码、中标价格、项目负责人、项目质量要求、项目工期（交货期）、中标通知书编号、合同订立价格，合同结算价格、合同验收质量、合同履行期限等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00200", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备招标项目相关时间信息的建立和维护功能。数据项应包括招标项目建立时间、公告发布时间、开标时间、中标候选人公示时间、中标通知时间、签约时间、合同完成时间等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00201", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 数据项格式详见附录 A.1.1、A.1.2、A.1.3、A.1.4、A.1.18、A.1.20。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00202", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 6.2 招标人信息库

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00203", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标人信息库管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00204", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备招标人信息建立和维护的功能。数据项应包括招标人代码、招标人名称、负责人、国别/地区、行业代码、营业执照号码、CA 证书编号、组织机构代码、税务登记号、开户银行、基本账户账号、注册资本、币种、信息申报责任人、联系电话、联系地址、邮政编码、电子邮箱等信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00205", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备招标人招标业绩、奖惩、履约记录等信息管理的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00206", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备招标人信息的检索和统计分析的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00207", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 数据项格式详见附录 A.2.1, A.2.3、A.2.8、A.1.20。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00208", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 6.3 招标代理机构信息库

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00209", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
招标代理机构信息库管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00210", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备招标代理机构信息建立和维护的功能。数据项应包括代理机构代码、代理机构名称、负责人、国别/地区、资质类别、资质等级、营业执照号码、CA 证书编号、组织机构代码、税务登记号、开户银行、基本账户、注册资本、信息申报责任人、联系电话、联系地址、邮政编码、电子邮箱等信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00211", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备招标代理机构电子招标业绩、奖惩记录和履约记录等信息管理的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00212", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备招标职业资格人员的相关信息管理的功能。数据项包括姓名、性别、身份证件类型、身份证件号码、出生年月、所在行政区域代码、最高学历、联系电话、通讯地址、邮政编码、所在单位、职务、职业证书编号、注册登记证书编号、从业年限、项目业绩、奖惩记录等信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00213", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备招标代理机构信息的检索和统计分析的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00214", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 数据项格式详见附录 A.2.1、A.2.2、A.2.3、A.2.4、A.2.5、A.2.6、A.2.8、A.1.20。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00215", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 6.4 投标人信息库

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00216", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
投标人信息库管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00217", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备投标人信息建立和维护的功能。数据项按不同主体应相应包括：投标人代码、投标人名称、负责人、国别/地区、资质序列、资质等级、资信等级、奖惩记录、营业执照号码、CA 证书编号、组织机构代码、税务登记号、开户银行、基本账户账号、注册资本、注册资本币种、信息申报和变更责任人、联系电话、联系地址、邮政编码、电子邮箱等信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00218", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备投标人中标业绩明细数据、奖惩与履约等信息归集的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00219", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备投标人信息的检索和统计分析的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00220", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备投标人黑名单的建立和管理的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00221", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应具备投标人专业职业资格人员（注册建造师、注册监理工程师等）的相关信息管理的功能。数据项包括姓名、性别、身份证件类型、身份证件号码、出生年月、所在行政区域代码、最高学历、联系电话、通讯地址、邮政编码、所在单位、职务、技术职称、职业资格序列、职业资格等级、职业证书编号、从业经历、从业年限、项目业绩、奖惩记录等信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00222", "chunk_name": "chunk-002-pages-0021-0040.pdf", "original_page_scope": [21, 40], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
f) 数据项格式详见附录 A.2.1、A.2.2、A.2.4、A.2.5、A.2.6、A.2.7、A.2.8、A.1.20。

## chunk-003-pages-0041-0060.pdf — original pages 41-60

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00001", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 6.5 专家信息库

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00002", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
必要时可建立交易平台专家信息库。专家信息库管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00003", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备专家信息建立和维护的功能。数据项应包括：专家编号、姓名、性别、身份证件类型、身份证件号码、出生年月、所在行政区域代码、最后毕业院校、最高学历、联系电话、通讯地址、邮政编码、所在单位、是否在职、职务、工作简历、专业分类、技术职称、职业资格序列、职业资格等级、从业年限、奖惩记录等信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00004", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应具备记录专家信息入库、变更和审核验证的时间以及责任人的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00005", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应具备专家回避情形和单位列表建立和维护的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00006", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应具备按地区、专业等随机抽取和记录专家的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00007", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应具备专家审核、入库、培训、考核、暂停、退出等功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00008", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
f) 宜具备专家自荐入库的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00009", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
g) 宜具备向公共服务平台专家库推荐专家入库的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00010", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
h) 数据项格式详见附录 A.2.8、A.2.11。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00011", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 6.6 价格信息库

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00012", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
价格信息库管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00013", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备工程、货物、服务分类分项单价信息的收集、整理、维护和查询的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00014", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 宜具备价格统计分析的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00015", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 7 交易平台的系统接口

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00016", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
系统接口是指交易平台与公共服务平台、行政监督平台以及专业工具软件之间根据电子招标投标流程及有关规定应具有的数据交换功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00017", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 7.1 公共服务平台的接口

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00018", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 7.1.1 交易平台注册登记

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00019", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
交易平台应选择任一公共服务平台注册登记和按规定对接交互信息。在全国公共服务平台体系形成前，交易平台选择注册登记和对接交换公共服务平台应同时满足行政监督信息交换的需要。登记的数据信息应包括：交易平台名称、运营机构代码、运营机构名称、CA 证书编号、系统访问地址、检测和认证报告附件等，数据项格式详见附录 A3。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00020", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 7.1.2 与公共服务平台的接口

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00021", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
交易平台与公共服务平台的数据接口应符合《公共服务平台和行政监督平台技术规范》和相关公共服务平台公布的数据接口要求。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00022", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 7.2 与行政监督平台的接口

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00023", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
交易平台可以选择公共服务平台的监督通道与行政监督平台交换信息，其数据接口应符合 7.1.2 的规定。交易平台也可以选择直接与行政监督平台交换信息，与行政监督平台的数据接口应符合《公共服务平台和行政监督平台技术规范》和相关行政监督平台公布的数据接口要求。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00024", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 7.3 与专业工具软件的接口

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00025", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
交易平台与专业工具软件的数据接口应符合本技术规范和国家有关计价规范要求，并在交易平台公布。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00026", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8 交易平台技术支撑与保障要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00027", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.1 接口技术要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00028", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.1.1 基本要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00029", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
接口技术基本要求如下：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00030", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应对数据交互提供企业级的支持，在系统高并发和大容量的基础上提供安全可靠的交互。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00031", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应提供完善的信息安全机制，以实现对信息的全面保护，保证系统的正常运行.应防止大量访问以及大量占用资源的情况发生，保证系统的健壮性。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00032", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应提供有效的、系统的可监控机制，以使接口的运行情况可监控，以便及时发现错误及排除故障。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00033", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 在充分利用系统资源的前提下，应实现系统平滑的移植和扩展，同时在系统并发增加时提供系统资源的动态扩展，以保证系统的稳定性。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00034", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 在进行扩容、新业务扩展时，应能提供快速、方便和准确的实现方式。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00035", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
f) 接口技术实现方式应当保持中立性。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00036", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
g) 应提供信息交换中自动标记输入和输出来源出处的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00037", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.1.2 通信方式

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00038", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
接口应通过基于主流的通信协议，并满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00039", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 数据传输应具备可控制性，提供数据重发功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00040", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 数据传输应具备可靠性，确保数据不会丢失，并进行充分的数据校验。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00041", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 大数据传输应具备断点续传的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00042", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.1.3 接口方式

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00043", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
接口方式管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00044", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 信息交换方式应符合 XML 数据交换标准。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00045", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 交互操作服务接口应符合 Web Services 标准。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00046", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 系统交互模式支持同步与异步方式。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00047", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 交互数据应支持各种数据类型。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00048", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.1.4 接口模型

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00049", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
数据接口模型应由数据结构、数据集、附件集组成：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00050", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 数据结构用来描述接口的结构信息，是可选元素。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00051", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 数据集是用来封装结构化数据，是可选元素。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00052", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 附件集是用来表述非结构化数据，是可选元素。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00053", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 数据集和附件集可以并存或单独出现。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00054", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.1.5 安全认证

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00055", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
为了保证数据的安全性，各种接口方式都应该保证其接入的安全性：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00056", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应通过接口实现技术上的安全控制，做到对安全事件的可知、可控、可预测。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00057", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应制定专门的安全技术实施策略，保证接口的数据传输和数据处理的安全性。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00058", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 系统应在接入点的网络边界实施接口安全控制。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00059", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 接口的安全控制在逻辑上应包括：安全评估、访问控制、入侵检测、口令认证、安全审计、防恶意代码、加密等内容。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00060", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 数据接口访问应进行双方身份安全认证，确保接口访问的安全性。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00061", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.1.6 传输控制

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00062", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
传输控制应利用如下高速数据通道技术实现将前端的大

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00063", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
数据量并发请求分发到后端，从而保证应用系统在大量客户端同时请求服务时，能够保持快速、稳定的工作状态：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00064", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 系统应采用传输控制手段降低接口网络负担，提高接口吞吐能力，保证系统的整体处理能力。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00065", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 为了确保接口服务吞吐量最大，接口宜自动地在系统中完成动态负载均衡调度。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00066", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 系统宜提供自动伸缩管理方式或动态配置管理方式实现队列管理、存取资源管理，以及接口应用的恢复处理等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00067", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 在双方接口之间宜设置多个网络通道，实现接口的多数据通道和容错性，保证在出现一个网络通道通讯失败时，进行自动的切换，实现接口连接的自动恢复。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00068", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.2 安全性

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00069", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.2.1 身份标识与鉴别

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00070", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
应对招标人、招标代理机构、投标人、授权评标专家等登录用户进行身份标识与鉴别，并提供身份标识唯一性检查功能。应采用以下措施，确保用户身份不易被冒用：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00071", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应提供鉴别信息复杂度检查功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00072", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应对身份标识与鉴别异常提供保护措施。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00073", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应使用有关部门认可的合法电子认证服务机构提供的 CA数字证书对交易主体身份标识与鉴别，需要进行身份标识与鉴别的电子招标投标交易行为包括：递交资格预审申请文件、递交投标文件、递交投标保证金、撤回投标文件、确认开标记录、递交回执、发出中标通知书、签订合同（协议书）等需要招标投标主体承担相应法律责任的电子招标投标行为。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00074", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 宜采用两种或两种以上上述措施组合的鉴别技术。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00075", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.2.2 电子签名

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00076", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
电子签名管理要求应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00077", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应通过电子签名来确保数据电文的完整性和不可抵赖性，电子签名应用的数字证书应采用合法的电子认证服务机构颁发的 CA 证书。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00078", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应使用电子签名的数据电文包括：招标公告（资格预审公告）、投标邀请书、资格预审文件（澄清和修改）、资格预审申请文件（澄清和修改）、资格审查报告、招标文件（澄清和修改）、投标文件（补充、修改、撤回、澄清）、开标记录、评标报告、中标通知书、合同（协议书）及相关文件的签收回执等具有法律约束力的文件。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00079", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应提供按照国家授时中心的标准时间源对需要电子签名的数据电文生成时间戳的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00080", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应执行统一规范的数据接口标准，并可通过公共服务平台协议联机等方式，支持不同的合法电子认证服务机构颁发的 CA 数字证书的兼容互认。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00081", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.2.3 电子加密和解密

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00082", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
应使用合法的电子认证服务机构颁发的数字证书，并能够根据招标文件选择确定的操作方式和责任主体，对需要保密的数据电文进行加密和解密，以确保数据电文的保密性。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00083", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.2.4 访问控制

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00084", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
访问控制管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00085", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应具备用户功能使用、数据访问的权限及其时限控制功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00086", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应能够识别对系统的非授权访问并提供相应的处理方法。应具备禁止同一帐户多处同时登录的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00087", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 用户的管理权限应按照边界清晰，且权限唯一性和最小化原则设置。实施系统开发权、系统管理权和业务权的责任人应相互分离、相互监控，同时，系统应具有自动警示超权限异常操作的功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00088", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 宜提供对重要信息资源设置敏感标记的功能，并根据安全策略严格控制用户对有敏感标记重要信息资源的操作。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00089", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.2.5 通信安全

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00090", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
通信安全管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00091", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应能够检测传输过程中数据电文的完整性，在检测到完整性错误时，应提示用户采取必要的措施。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00092", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应采用加密或其它有效措施实现数据传输的保密性。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00093", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.2.6 存储安全

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00094", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
存储安全管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00095", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应采用加密或其他保护措施实现鉴别信息存储的保密性。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00096", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 宜采用加密或其他保护措施确保重要数据存储的保密性。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00097", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 宜对重要数据存储过程中的完整性进行检测，在检测到完整性错误时，应提示用户采取相应的措施。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00098", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.2.7 资源控制

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00099", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
资源控制管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00100", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应该能够对单个帐户的多重并发会话进行限制，并能够对系统的最大并发会话连接数进行限制。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00101", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 宜对一个时间段内可能的并发会话连接数进行限制。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00102", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.2.8 数据安全及备份恢复

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00103", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
数据安全及备份恢复管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00104", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应对关键数据提供自动定时本地备份与恢复功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00105", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 宜提供异地数据定期备份功能和异地灾备功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00106", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.2.9 安全缺陷防范

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00107", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
安全缺陷防范管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00108", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 不应存在可能引起安全缺陷的语句、命令。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00109", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应能够识别和屏蔽非法访问。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00110", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 宜加强系统安全防范，能够识别和抵御程序恶意攻击。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00111", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.2.10 安全审计

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00112", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
安全审计管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00113", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应提供安全审计功能。安全审计范围应覆盖系统中的每个用户及系统中的所有重要安全事件，如登录事件、关键数据变更等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00114", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 审计记录的内容应包括事件的日期、时间、发起者信息、类型、描述和结果等。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00115", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应提供审计记录数据的查询、统计、分析功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00116", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 安全审计人员不能同时兼任系统管理员。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00117", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 安全审计系统设备宜独立部署，以确保数据不被篡改。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00118", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.3 性能

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00119", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.3.1 响应时间

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00120", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
响应时间管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00121", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应满足主要功能在单点操作下响应时间少于 5 秒。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00122", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 典型功能在 50 人并发情况下，响应时间应少于 15 秒。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00123", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应支持大文件传输功能。支持 100MB 以内的文件稳定上传。服务器端接收上传文件的最大吞吐量应不低于 10Mbit/S。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00124", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 投标文件集中解密功能模块的系统处理能力应保证每分钟文件解密应大于 100 个或大于 1GB。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00125", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.4 可靠性

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00126", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.4.1 稳定性

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00127", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
系统稳定性管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00128", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应保证在高负荷状态下能提供不间断的可靠服务，系统运行稳定。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00129", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 在容量到达规定及超出规定的极限时，系统不能因为崩溃、异常退出等原因而导致数据错误或丢失。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00130", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.4.2 容错性

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00131", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
系统容错性管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00132", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应提供数据有效性检验功能，对无效数据应给出简洁、准确的提示信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00133", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应提供数据一致性校验机制。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00134", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应能识别和屏蔽可能引起系统崩溃、异常退出的用户输入或用户误操作，并给出提示。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00135", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.5 易用性

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00136", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.5.1 易理解性

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00137", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
系统易理解性管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00138", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应通过适当的术语、释义、图形、背景信息和操作帮助，协助用户理解和使用系统的各项功能。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00139", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应对平台功能操作错误的原因和纠正信息加以提示。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00140", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 宜提供在线帮助。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00141", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.5.2 易浏览性

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00142", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
系统易浏览性管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00143", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应显示系统当前处理状态。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00144", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应规范化设计屏幕提示、输入和输出。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00145", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.6 运行环境

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00146", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.6.1 机房要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00147", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
机房管理应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00148", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应满足《GB/T50311-2007 综合布线系统工程设计规范》、《GB 2887-2011 计算机场地通用规范》、《GB 50174-2008电子信息系统机房设计规范》标准。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00149", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应采用 UPS 不间断电源，UPS 电源提供不低于 2 小时后备供电能力。UPS 功率大小应根据设备功率进行计算，并留有 30%的余量。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00150", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 宜设计物理屏障，通过门禁、安全制度等技术和管理措施保证机房环境物理安全性。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00151", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.6.2 网络要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00152", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
网络带宽应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00153", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 接入互联网的独享带宽应不小于 10Mbps。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00154", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 接入互联网的实际带宽应根据峰值流量进行计算确定。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00155", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
网络安全应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00156", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 网络安全等级应通过《GB17859-1999 计算机信息系统安全保护等级划分准则》中第二级“系统审计保护级”的评测。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00157", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 网络安全等级宜通过《GB17859-1999 计算机信息系统安全保护等级划分准则》中第三级 “安全标记保护级”的评测。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00158", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.6.3 主机要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00159", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.6.3.1 服务器要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00160", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
服务器应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00161", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应满足系统对可靠性、安全性和性能的要求。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00162", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 关键部件应采用冗余配置。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00163", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 服务器时间应与国家授时中心时间同步。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00164", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.6.3.2 主机安全要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00165", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
主机安全应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00166", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 主机安全等级应通过《GB17859-1999 计算机信息系统安全保护等级划分准则》中第二级“系统审计保护级”的评测。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00167", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 主机安全等级宜通过《GB17859-1999 计算机信息系统安全保护等级划分准则》中第三级“安全标记保护级”的评测。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00168", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.6.3.3 存储要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00169", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
存储应满足以下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00170", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 宜采用独立磁盘存储设备进行核心数据存储。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00171", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 关键部件应采用冗余配置。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00172", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 应采用主流存储技术，实现存储设备的冗余和可靠接入，保证存储稳定性。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00173", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 应根据在线数据规模计算存储空间，并保留不少于 20%的冗余。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00174", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
e) 应具有扩展性，可按需增加存储空间，应对系统应用范围的扩展。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00175", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 8.6.4 系统软件要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00176", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
系统软件应满足如下要求：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00177", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
a) 应用服务器和数据库服务器应物理分离。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00178", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
b) 应支持主流数据库。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00179", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
c) 宜支持集群部署，实现负载均衡。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00180", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
d) 宜同时支持包括但不仅限于 Unix、Linux、Windows 等操作系统。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00181", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 附录A 数据项的基本要求

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00182", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
A.1 业务对象

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00183", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
A.1.1 项目

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00184", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">项目编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.2项目编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..17</td></tr><tr><td colspan="1" rowspan="1">项目名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..200</td></tr><tr><td colspan="1" rowspan="1">项目所在行政区域代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T2260-2007《中华人民共和国行政区划代码》的市级代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">项目地址</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..200</td></tr><tr><td colspan="1" rowspan="1">项目法人</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">项目行业分类</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">GB/T  4754-2011，取1位行业门类字母码+2位大类数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">资金来源</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..1000</td></tr><tr><td colspan="1" rowspan="1">项目规模</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..1000</td></tr><tr><td colspan="1" rowspan="1">联系人</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">联系方式</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00185", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.2 招标项目

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00186", "chunk_name": "chunk-003-pages-0041-0060.pdf", "original_page_scope": [41, 60], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">项目编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.2项目编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C17</td></tr><tr><td colspan="1" rowspan="1">招标项目编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.4招标项目编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C20</td></tr><tr><td colspan="1" rowspan="1">招标项目名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">招标内容与范围及招标方案说明</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">附件关联标识号</td><td colspan="1" rowspan="1">关联到附件表中1-n 个附件记录</td><td colspan="1" rowspan="1">附录B.3.7附件关联标识号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">招标人代码</td><td colspan="1" rowspan="1">组织机构代码</td><td colspan="1" rowspan="1">采用     GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">招标代理机构代码</td><td colspan="1" rowspan="1">组织机构代码</td><td colspan="1" rowspan="1">采用     GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">招标方式</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.8招标方式代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">招标组织形式</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.3招标组织形式代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">招标项目建立时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">监督部门代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用     GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">监督部门名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr></table>

## chunk-004-pages-0061-0080.pdf — original pages 61-80

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00001", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>审核部门代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>采用     GB11714-1997《全国组织机构代码编制规则》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C9</td></tr><tr><td rowspan=1 colspan=1>审核部门名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>交换公共服务平台标识码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B3.23 公共服务平台标识代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C10</td></tr><tr><td rowspan=1 colspan=1>申报责任人</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00002", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.3 标段（包）

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00003", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">招标项目编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.4招标项目编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C20</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1">由招标项目编号和标段 (包)序列号组成</td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">标段（包）名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..200</td></tr><tr><td colspan="1" rowspan="1">标段（包）内容</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">标段 (包）分类代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.6标段 (包)分类代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C7</td></tr><tr><td colspan="1" rowspan="1">标段合同估算价</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">标段合同估算价币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">标段合同估算价单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.25金|字符型额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">投标人资格条件</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00004", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.4 招标公告与资格预审公告

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00005", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">招标项目编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.4招标项目编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C20</td></tr><tr><td colspan="1" rowspan="1">公告性质</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.9 公告性质代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">公告类型</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.10 公告类型代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">招标文件/资格预审文件获取时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">招标文件/资格预审文件获取方法</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">投标文件/资格预审申请文件递交截止时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">投标文件/资格预审申请文件递交方法</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">公告内容文本</td><td colspan="1" rowspan="1">应包括标段名称、标段编号及投标资格等信息</td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.ul</td></tr><tr><td colspan="1" rowspan="1">公告发布时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">公告附件关联标识号</td><td colspan="1" rowspan="1">关联到附件表的多条记录</td><td colspan="1" rowspan="1">附录 B.3.7附件关联标识号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.50</td></tr><tr><td colspan="1" rowspan="1">相关标段(包)编号</td><td colspan="1" rowspan="1">由多个标段（包）编号组成，半角分号隔开</td><td colspan="1" rowspan="1">附录 B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.ul</td></tr><tr><td colspan="1" rowspan="1">公告结束日期</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">公告发布责任人</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">交易平台验证责任人</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">公告发布媒体</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..1000</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00006", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.5 投标邀请书

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00007", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.5标段(包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">投标资格</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">投标文件/资格预审申请文件获取时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">招标文件/资格预审文件获取方法</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.ul</td></tr><tr><td colspan="1" rowspan="1">投标文件/资格预审申请文件递交截止时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">投标文件/资格预审申请文件递交方法</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">回复截止时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">投标邀请发出时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">附件关联标识号</td><td colspan="1" rowspan="1">关联到附件表的多条记录</td><td colspan="1" rowspan="1">附录 B.3.7附件关联标识号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00008", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.6 资格预审文件/资格预审文件澄清与修改

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00009", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5 标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">文件编号</td><td colspan="1" rowspan="1">资格预审文件/澄清与修改文件编号</td><td colspan="1" rowspan="1">附录B.3.11资格预审文件/招标文件/澄清与修改文件编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">申请资格</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.ul</td></tr><tr><td colspan="1" rowspan="1">申请有效期</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..200</td></tr><tr><td colspan="1" rowspan="1">申请文件递交截止时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">申请文件递交方法</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">文件开启时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">文件开启方式</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">评审办法</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.ul</td></tr><tr><td colspan="1" rowspan="1">对文件澄清与修改的主要内容</td><td colspan="1" rowspan="1">文件修改的章节、条款等信息</td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">递交时间</td><td colspan="1" rowspan="1">资格预审文件、澄清与修改文件的递交时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">附件关联标识号</td><td colspan="1" rowspan="1">关联到附件表的多条记录</td><td colspan="1" rowspan="1">附录 B.3.7附件关联标识号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.50</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00010", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.7 资格预审申请文件
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段(包)编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>申请人代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>采                  用GB11714-1997《全国组织机构代码编制规则》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C9</td></tr><tr><td rowspan=1 colspan=1>投标资格条件</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>投标单位项目负责人</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.50</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表的多条记录</td><td rowspan=1 colspan=1>附录B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.50</td></tr><tr><td rowspan=1 colspan=1>申请递交时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00011", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.8 资格预审结果文件
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>通过资格预审的申请人名单</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表的多条记录</td><td rowspan=1 colspan=1>附录B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.50</td></tr><tr><td rowspan=1 colspan=1>资格评审结果生成时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00012", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.9 招标文件/招标文件澄清与修改

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00013", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5 标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">文件编号</td><td colspan="1" rowspan="1">招标文件/澄清与修改文件编号</td><td colspan="1" rowspan="1">附录 B.3.11资格预审文件/招标文件/澄清与修改文件编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.50</td></tr><tr><td colspan="1" rowspan="1">投标资格</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">投标有效期</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..3</td></tr><tr><td colspan="1" rowspan="1">投标文件递交截止时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">投标文件递交方法</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">投标保证金金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..10,2</td></tr><tr><td colspan="1" rowspan="1">投标保证金币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">投标保证金单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.25金额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">附件关联标识号</td><td colspan="1" rowspan="1">关联到附件表的多条记录</td><td colspan="1" rowspan="1">附录 B.3.7附件关联标识号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">评标办法</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">开标时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">开标方式</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">资格审查方式</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">答疑澄清时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">对文件澄清与修改的主要内容</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.ul</td></tr><tr><td colspan="1" rowspan="1">递交时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00014", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.10 现场踏勘通知
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>通知内容</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.ul</td></tr><tr><td rowspan=1 colspan=1>通知发出时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00015", "chunk_name": "chunk-004-pages-0061-0080.pdf", "original_page_scope": [61, 80], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.11 现场踏勘记录
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>踏勘单位名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.200</td></tr><tr><td rowspan=1 colspan=1>踏勘单位代表姓名</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..200</td></tr><tr><td rowspan=1 colspan=1>踏勘时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表的多条记录</td><td rowspan=1 colspan=1>附录B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr></table>

## chunk-005-pages-0081-0100.pdf — original pages 81-100

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00001", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.12 投标文件

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00002", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">投标人代码</td><td colspan="1" rowspan="1">组织机构代码</td><td colspan="1" rowspan="1">采                 用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">投标文件附件关联标识号</td><td colspan="1" rowspan="1">关联到附件表的多条记录</td><td colspan="1" rowspan="1">附录B.3.7附件关联标识号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">投标报价金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">投标报价币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">投标报价单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.25金额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">工期(交货期)</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..4</td></tr><tr><td colspan="1" rowspan="1">投标保证金形式</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">投标保证金金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">投标保证金币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">投标保证金单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.25金额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">投标单位项目负责人</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">投标有效期</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..3</td></tr><tr><td colspan="1" rowspan="1">投标时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">投标排序</td><td colspan="1" rowspan="1">按投标时间排序</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..2</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00003", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.13 投标保证金记录

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00004", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">投标人代码</td><td colspan="1" rowspan="1">组织机构代码</td><td colspan="1" rowspan="1">采                 用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">投标人名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">保证金支付形式</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">保证金金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">保证金币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">保证金单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.25金额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">保证金凭证接收时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">保证金到账时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">保证金退还时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00005", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.14 开标记录
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>开标参与人</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.500</td></tr><tr><td rowspan=1 colspan=1>开标记录内容</td><td rowspan=1 colspan=1>包括投标人名称、报价、工期(交货期)、投标保证金额、投标文件递交时间等招标文件所规定的唱标内容</td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表的多条记录</td><td rowspan=1 colspan=1>附录 B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>开标时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00006", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.15 评标报告
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>评标报告正文</td><td rowspan=1 colspan=1>包含中标候选人名称及排名、投标价格、评分结果或评标价格、中标价格等内容</td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.ul</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>评标报告各附件资料，关联到附件表的多条记录</td><td rowspan=1 colspan=1>附录 B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>提交时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00007", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.16 中标候选人

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00008", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">中标候选人名称</td><td colspan="1" rowspan="1">每个中标候选人一条记录</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">中标候选人代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">中标候选人排名</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..10</td></tr><tr><td colspan="1" rowspan="1">投标价格</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">评分结果</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">评标价格</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">中标价格</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">价格币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">价格单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.25金|字符型额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00009", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
注：每个中标候选人都应在此表中对应一条独立的数据记录。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00010", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.17 中标候选人公示
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.5 标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>公示类型</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.13 公示类型代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C1</td></tr><tr><td rowspan=1 colspan=1>公示开始时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>公示结束时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>公示内容</td><td rowspan=1 colspan=1>多个中标候选人一并显示</td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>公示提交时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00011", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.18 中标/招标结果通知书

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00012", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">通知书类型</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.26通知书类型代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">中标/招标结果通知书编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.50</td></tr><tr><td colspan="1" rowspan="1">中标人/未中标人名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">中标人/未中标人代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">中标/投标价格</td><td colspan="1" rowspan="1">对中标人，填入中标价格；对未中标人，填入投标价格</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">价格币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用   GB/T字符型12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">GB/T字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">价格单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.25金额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">通知书文本</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">附件关联标识号</td><td colspan="1" rowspan="1">关联到附件表的多条记录</td><td colspan="1" rowspan="1">附录 B.3.7附件关联标识号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.50</td></tr><tr><td colspan="1" rowspan="1">发出时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00013", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.19 资格预审结果通知书
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.5 标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>资格预审通过单位名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>资格预审通过单位代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>采用GB11714-1997《全国组织机构代码编制规则》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C9</td></tr><tr><td rowspan=1 colspan=1>通知书文本</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.ul</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表的多条记录</td><td rowspan=1 colspan=1>附录 B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>发出时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00014", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.20 合同和履行

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00015", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">招标人代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">中标人代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">合同金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">金额币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">金额单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.25金额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">合同期限</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N.4</td></tr><tr><td colspan="1" rowspan="1">质量要求</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">合同主要内容</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">合同签署时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">附件关联标识号</td><td colspan="1" rowspan="1">关联到附件表的多条记录</td><td colspan="1" rowspan="1">附录 B.3.7附件关联标识号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">合同结算金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">履约变更内容</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">合同完成时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">实际履约期限</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..4</td></tr><tr><td colspan="1" rowspan="1">履约信息递交时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00016", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.21 异议与投诉

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00017", "chunk_name": "chunk-005-pages-0081-0100.pdf", "original_page_scope": [81, 100], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>异议或投诉人代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>采用GB11714-1997《全国组织机构代码编制规则》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C9</td></tr><tr><td rowspan=1 colspan=1>异议或投诉人名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>依据和理由</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>异议与投诉内容</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表的多条记录</td><td rowspan=1 colspan=1>附录B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>提交时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>异议或投诉受理人</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..20</td></tr></table>

## chunk-006-pages-0101-0120.pdf — original pages 101-120

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00001", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>受理时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>处理结果</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>反馈时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00002", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.22 招标异常情况报告
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>异常情况描述</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表的多条记录</td><td rowspan=1 colspan=1>附录 B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>提交时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>审批或核准结果</td><td rowspan=1 colspan=1>由招标项目表中描述的核准机构进行核准</td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>审批或核准时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00003", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.23 附件
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.50</td></tr><tr><td rowspan=1 colspan=1>上传时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>附件名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>附件内容</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>二进制型</td><td rowspan=1 colspan=1>BY</td></tr><tr><td rowspan=1 colspan=1>附件电子签名</td><td rowspan=1 colspan=1>无须电子签名的附件，此字段可忽略</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>二进制BY型</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>签名证书的公钥</td><td rowspan=1 colspan=1>用于验证文件签名，无须电子签名的附件，此字段可忽略</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>二进制BY型</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00004", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.24 开标签到
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段（包）编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>投标人名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>签到时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00005", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.25 招标委托代理
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>招标项目编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.4招标项目编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C20</td></tr><tr><td rowspan=1 colspan=1>招标代理机构代码</td><td rowspan=1 colspan=1>组织机构代码</td><td rowspan=1 colspan=1>采用GB11714-1997《全国组织机构代码编制规则》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C9</td></tr><tr><td rowspan=1 colspan=1>招标代理机构名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>招标代理资格分类代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.15资字符型质代码</td><td rowspan=1 colspan=1>字衔型</td><td rowspan=1 colspan=1>C6</td></tr><tr><td rowspan=1 colspan=1>招标代理资格分级代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.16资质等级代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C6</td></tr><tr><td rowspan=1 colspan=1>招标代理内容与范围</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>招标代理权限</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.ul</td></tr><tr><td rowspan=1 colspan=1>招标代理机构项目负责人信息</td><td rowspan=1 colspan=1>负责人姓名、职责权限及联系方式等</td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00006", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.26 招标项目计划
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>招标项目编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.4招标项目编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C20</td></tr><tr><td rowspan=1 colspan=1>招标项目名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>相关标段 (包)编号</td><td rowspan=1 colspan=1>由多个标段（包）编号组成，半角分号隔开</td><td rowspan=1 colspan=1>附录B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.ul</td></tr><tr><td rowspan=1 colspan=1>工作任务计划</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.ul</td></tr><tr><td rowspan=1 colspan=1>项目团队成员组成与职责分工</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00007", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.27 要求澄清的问题
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段(包)编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.5标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>文件编号</td><td rowspan=1 colspan=1>对应具体的资格预审文件/招标文件/澄清与修改文件</td><td rowspan=1 colspan=1>附录 B.3.11资格预审文件/招标文件/澄清与修改文件编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>要求澄清的问题</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>要求提交的时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>提交人代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>采用GB11714-1997《全国组织机构代码编制规则》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C9</td></tr><tr><td rowspan=1 colspan=1>提交人名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表|附录 B.3.7附的多条记录</td><td rowspan=1 colspan=1>关联到附件表|附录 B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00008", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.1.28 资格预审文件开启
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>标段(包)编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.5 标段（包）编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C23</td></tr><tr><td rowspan=1 colspan=1>开启参与单位名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..500</td></tr><tr><td rowspan=1 colspan=1>开启时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>开启内容</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00009", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.1.29 中标结果公告

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00010", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">标段 (包）名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..200</td></tr><tr><td colspan="1" rowspan="1">中标人名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">中标人代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采                  用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">中标价格</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">价格币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">价格单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.25金额单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">其他说明</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..1000</td></tr><tr><td colspan="1" rowspan="1">附件关联标识号</td><td colspan="1" rowspan="1">关联到附件表的多条记录</td><td colspan="1" rowspan="1">附录B.3.7附件关联标识号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00011", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2 招投标主体

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00012", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.1 招投标主体基本信息表

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00013", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">主体代码</td><td colspan="1" rowspan="1">采用组织机构代码</td><td colspan="1" rowspan="1">采用     GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">主体名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">负责人</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">国别/地区</td><td colspan="1" rowspan="1">按国标编码</td><td colspan="1" rowspan="1">采用GB/T2659-2000中的3位数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">单位性质</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">GB/T   12402《经济类型分类与代码》。</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.20</td></tr><tr><td colspan="1" rowspan="1">行政区域代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T2260-2007 中的市级代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">行业代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T4754《国民经济行业分类》中的门类和大类</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">营业执照号码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">CA证书编号</td><td colspan="1" rowspan="1">取 CA 证书的唯一编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">税务登记号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">资信等级</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">开户银行</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">基本账户账号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">注册资本</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">注册资本币种</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">注册资本单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.25价格单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">信息申报责任人</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">联系电话</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">联系地址</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">邮政编码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">电子邮箱</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">主体类型</td><td colspan="1" rowspan="1">多个不同的主体类型用半角分号隔开</td><td colspan="1" rowspan="1">附录 B.3.14主体角色类型代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..10</td></tr><tr><td colspan="1" rowspan="1">交易平台验证人员</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">交易平台验证时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00014", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.2.2 主体经营资质信息表
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>主体代码</td><td rowspan=1 colspan=1>组织机构代码</td><td rowspan=1 colspan=1>采用GB11714-1997《全国组织机构代码编制规则》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C9</td></tr><tr><td rowspan=1 colspan=1>资质序列、行业和专业类别</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.15资质序列、行业和专业类别</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C6</td></tr><tr><td rowspan=1 colspan=1>资质等级</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.16资质等级代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C2</td></tr><tr><td rowspan=1 colspan=1>资质证书编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>信息申报责任人</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00015", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.3 招标人/招标代理机构电子招标业绩

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00016", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">招标人/招标代理机构代码</td><td colspan="1" rowspan="1">招标人/招标代理机构组织机构代码</td><td colspan="1" rowspan="1">采用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">招标项目编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.4招标项目编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C20</td></tr><tr><td colspan="1" rowspan="1">招标项目名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">招标人代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">招标人名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">招标项目合同总金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">招标项目代理收费金额</td><td colspan="1" rowspan="1">仅招标代理机构需要填写</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">金额币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用    GB/T12406-2008《表示货币和资金的代码》的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">金额单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.25价格单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">招标项目合同签署时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00017", "chunk_name": "chunk-006-pages-0101-0120.pdf", "original_page_scope": [101, 120], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
注：业绩仅限于在电子招投标交易平台上成交的项目。

## chunk-007-pages-0121-0140.pdf — original pages 121-140

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00001", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.4 职业人员基本信息

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00002", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">职业人员代码</td><td colspan="1" rowspan="1">取身份证号码</td><td colspan="1" rowspan="1">采用 GB 11643 -1999《公民身份号码》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C18</td></tr><tr><td colspan="1" rowspan="1">姓名</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">性别</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用 GB/T 2261.1-2003《个人基本信息分类与代码第1部分人的性别代码》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">出生年月</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDD</td></tr><tr><td colspan="1" rowspan="1">所在行政区域代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用 GB/T 2260-2007《中华人民共和国行政区划代码》的市级代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">最高学历</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">联系电话</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">通讯地址</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.50</td></tr><tr><td colspan="1" rowspan="1">邮政编码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">所在单位代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11714-1997《全国组织机构代码编制规则》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">所在单位名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">是否在职</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.12是否代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..10</td></tr><tr><td colspan="1" rowspan="1">职务</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">技术职称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">从业经历</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.ul</td></tr><tr><td colspan="1" rowspan="1">从业年限</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..2</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00003", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.5 人员职业资格信息

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00004", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>职业人员代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>采用     GB11643 - 1999《公民身份号码》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C18</td></tr><tr><td rowspan=1 colspan=1>职业资格序列</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>职业资格等级</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>资格资格证书编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>注册登记证书编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00005", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.6 人员业绩信息

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00006", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">职业人员代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用 GB11643 -1999《公民身份号码》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C18</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.5标段字符型（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">标段（包）名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">招标人代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用 GB 11714-1997中的代码编制规则</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">招标人名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">合同金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">结算金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">金额币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用 GB/T12406-2008中的数字码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">金额单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.25价格单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">合同签署时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">合同完成时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00007", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
备注：业绩仅限于在电子招投标交易平台上成交的项目。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00008", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.7 投标人业绩

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00009", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">投标人代码</td><td colspan="1" rowspan="1">组织机构代码</td><td colspan="1" rowspan="1">采用    GB11714-1997中的代码编制规则</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">中标项目的标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">中标项目和标段（包）名称</td><td colspan="1" rowspan="1">按照招标项目和标段(包)的名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">招标人代码</td><td colspan="1" rowspan="1">组织机构代码</td><td colspan="1" rowspan="1">采用    GB11714-1997中的代码编制规则</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C9</td></tr><tr><td colspan="1" rowspan="1">招标人名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">中标金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">合同金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">合同结算金额</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..20,2</td></tr><tr><td colspan="1" rowspan="1">合同期限</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..4</td></tr><tr><td colspan="1" rowspan="1">实际履行期限</td><td colspan="1" rowspan="1">单位：天</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..4</td></tr><tr><td colspan="1" rowspan="1">金额币种代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用（GB/T字符型12406-2008中的数字码</td><td colspan="1" rowspan="1">GB/T字符型</td><td colspan="1" rowspan="1">C3</td></tr><tr><td colspan="1" rowspan="1">金额单位</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.25价格单位代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">合同签署时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00010", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
备注：业绩仅限于在电子招投标交易平台上成交的项目。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00011", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.8 奖惩记录

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00012", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>奖惩对象代码</td><td rowspan=1 colspan=1>单位取组织机构代码；个人取身份证号码</td><td rowspan=1 colspan=1>采用      GB11714-1997中的代码编制规则和GB11643 - 1999《公民身份号码》</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..18</td></tr><tr><td rowspan=1 colspan=1>奖惩对象类型</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.18奖惩对象类型代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C1</td></tr><tr><td rowspan=1 colspan=1>奖惩时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>奖惩内容</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr><tr><td rowspan=1 colspan=1>奖惩类型</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.19奖惩类型代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C1</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00013", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.9 资格审查委员会/评标委员会组建申请

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00014", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">组建申请编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录 B.3.22评标委员会组建申请编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.20</td></tr><tr><td colspan="1" rowspan="1">标段（包）编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.5标段（包）编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C23</td></tr><tr><td colspan="1" rowspan="1">专家库名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..500</td></tr><tr><td colspan="1" rowspan="1">专家抽取要求</td><td colspan="1" rowspan="1">包含专业分类代码、行政区域代码、专家人数、专家等级、回避条件等抽取说明</td><td colspan="1" rowspan="1">自由文本</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">评审时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">评审地点</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">抽取时间</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDDhhmmss</td></tr><tr><td colspan="1" rowspan="1">抽取人姓名</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00015", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
A.2.10 资格审查委员会/评标委员会成员
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>组建申请编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录B.3.20评标委员会组建申请编号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..20</td></tr><tr><td rowspan=1 colspan=1>专家编号</td><td rowspan=1 colspan=1>如果是专家库成员，需要有此编号</td><td rowspan=1 colspan=1>附录B.3.22专字符型家编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>C17</td></tr><tr><td rowspan=1 colspan=1>专家姓名</td><td rowspan=1 colspan=1>如果是招标人代表，填入姓名</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>专家类型</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.21专字符型家类型代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C1</td></tr><tr><td rowspan=1 colspan=1>通知方式</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr><tr><td rowspan=1 colspan=1>通知时间</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>日期时间型</td><td rowspan=1 colspan=1>YYYYMMDDhhmmss</td></tr><tr><td rowspan=1 colspan=1>专家考核记录</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>自由文本</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..ul</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00016", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.2.11 评标专家

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00017", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td><td colspan="1" rowspan="1">值域</td><td colspan="1" rowspan="1">数据类型</td><td colspan="1" rowspan="1">数据格式</td></tr><tr><td colspan="1" rowspan="1">专家编号</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.22专家编号</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C17</td></tr><tr><td colspan="1" rowspan="1">姓名</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">性别</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用 GB/T 2261.1-2003 中人的性别代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">身份证件类型</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.16身份证件类型代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C2</td></tr><tr><td colspan="1" rowspan="1">身份证件号码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB11643-1999《公民身份号码》</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C18</td></tr><tr><td colspan="1" rowspan="1">出生年月</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">日期时间型</td><td colspan="1" rowspan="1">YYYYMMDD</td></tr><tr><td colspan="1" rowspan="1">所在行政区域代码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用GB/T 2260-2007中的市级代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">最后毕业院校</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">最高学历</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..30</td></tr><tr><td colspan="1" rowspan="1">联系电话</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">通讯地址</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">邮政编码</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">所在单位名称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..100</td></tr><tr><td colspan="1" rowspan="1">是否在职</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">附录B.3.12是否代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C1</td></tr><tr><td colspan="1" rowspan="1">职务</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">工作简历</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..ul</td></tr><tr><td colspan="1" rowspan="1">专业分类</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">采用《评标专家专业分类标准 (试行)》中约定的代码</td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C6</td></tr><tr><td colspan="1" rowspan="1">技术职称</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">职业资格序列</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C.50</td></tr><tr><td colspan="1" rowspan="1">职业资格等级</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">字符型</td><td colspan="1" rowspan="1">C..50</td></tr><tr><td colspan="1" rowspan="1">从业年限</td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">数值型</td><td colspan="1" rowspan="1">N..2</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00018", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.3 交易平台或公共服务平台

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00019", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td><td rowspan=1 colspan=1>值域</td><td rowspan=1 colspan=1>数据类型</td><td rowspan=1 colspan=1>数据格式</td></tr><tr><td rowspan=1 colspan=1>交易平台或公共服务平台代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.1交易平台标识代码；附录 B.3.23 公共服务平台标识代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C11</td></tr><tr><td rowspan=1 colspan=1>平台类型</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>附录 B.3.24平台类型代码</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C1</td></tr><tr><td rowspan=1 colspan=1>平台名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>运营机构代码</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>采用    GB11714-1997中的代码编制规则</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C9</td></tr><tr><td rowspan=1 colspan=1>运营机构名称</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..100</td></tr><tr><td rowspan=1 colspan=1>CA证书编号</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C.50</td></tr><tr><td rowspan=1 colspan=1>系统访问地址</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..200</td></tr><tr><td rowspan=1 colspan=1>检测和认证报告附件关联标识号</td><td rowspan=1 colspan=1>关联到附件表</td><td rowspan=1 colspan=1>附录 B.3.7附件关联标识号</td><td rowspan=1 colspan=1>字符型</td><td rowspan=1 colspan=1>C..50</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00020", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.4 数据项术语说明

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00021", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.4.1 值域

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00022", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
值域是指数据项的有效取值范围。一般分为自由文本型、枚举型、代码型等。自由文本型表示没有特别规定的内容类型；枚举型指元数据元素有可枚举的取值；代码型指元数据元素能对应到某个代码表的代码列或名称列。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00023", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## A.4.2 数据类型和数据格式

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00024", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
数据项允许值的数据类型及表示格式。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00025", "chunk_name": "chunk-007-pages-0121-0140.pdf", "original_page_scope": [121, 140], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td>数据类型</td><td>说明</td><td>数据格式</td></tr><tr><td>字符型</td><td>一切可以显示打 印的字符，包括 汉字、字母、数 字、各种符号、空 格等，不具有计 算能力。</td><td>以大写字母&quot;C&quot;代表字符型: CX:表示定长为“X”的字符 型数据元值; C..X:表示最长为&quot;X&quot;的字符 型数据元值； C..ul:表示长度不确定的字符 型数据元值。</td></tr></table>

## chunk-008-pages-0141-0160.pdf — original pages 141-160

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00001", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>数值型</td><td rowspan=1 colspan=1>可以进行数学运算的数据。</td><td rowspan=1 colspan=1>以大写字母“N”代表数值型:N..X:表示最长为“X&quot;的数值型数据元值;N..X,y:表示总长度为&quot;X&quot;位、其中小数点后为“y”位的数值型数据元值。</td></tr><tr><td rowspan=1 colspan=1>型</td><td rowspan=1 colspan=1>日期时间|用以表示日期及时间的数据。</td><td rowspan=1 colspan=1>采用GB/T7408《数据元和交换格式 信息交换 日期和时间表示法》的规定。</td></tr><tr><td rowspan=1 colspan=1>二进制型</td><td rowspan=1 colspan=1>图象、音频、视频等二进制数据。</td><td rowspan=1 colspan=1>以大写字母“BY”代表二进制型:BY-X:表示媒体格式为“X&quot;的二进制型数据元值。</td></tr><tr><td rowspan=1 colspan=1>布尔型</td><td rowspan=1 colspan=1>两个且只有两个表明条件的值，如 On/Off、True/False。</td><td rowspan=1 colspan=1>以大写字母&quot;B&quot;代表布尔型。</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00002", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 附录B 编码总体规则

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00003", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.1 编码总体规则说明

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00004", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
信息分类与编码是建设电子招标投标系统不可或缺的部分，是支撑电子招标投标系统信息交换、共享的主要技术手段。电子招标投标信息分类与编码主要用于表示数据项的值域。当数据项是代码型数据项时，其值域指向了相应的信息分类与编码信息，如果有相应的国家标准，则优先采用国家标准信息。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00005", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
用于电子招标投标系统建设信息分类和编码的基本原则有：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00006", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
实用性：在对事物或概念进行分类编码时，既要保证科学合理，又要立足于电子招标投标的实际管理需求，满足电子招标投标业务管理和电子招标投标系统建设的需求。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00007", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
稳定性：宜选择事物或概念相对稳定的属性或特征作为分类依据，代码不宜频繁变动和修改，以避免造成人、财、物的浪费。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00008", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
唯一性：在一个分类编码标准中，一个编码对象只能有一个代码，一个代码只能唯一表示一个编码对象，即编码对象与代码间是一一对应的关系。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00009", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
可扩展性：在进行分类编码时，通常要设置收容类目（其他类），为新增加的编码对象留有足够的可扩充的备用码，以保证增加新的事物或概念时，不必打乱已建立的分类体系。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00010", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
同时，还应为分类的进一步延拓细化创造条件，并充分考虑电子招标投标改革与可持续发展的需要。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00011", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
兼容性：应与相关的国家标准及相关行业标准协调一致。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00012", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
电子招标投标系统建设用信息编码的常用方法包括：顺序码、缩写码、层次码、组合码。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00013", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
依据信息分类编码标准化的一般要求，结合电子招标投标系统建设的实际需要和特点，电子招标投标信息分类与编码信息主要通过 2 个属性来描述：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00014", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
1、编码规则：描述代码的分类原则和编码方法。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00015", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
2、码值：代码对应的代码表。代码表有 3 个字段，“名称”字段表示编码对象的中文名称；“代码”字段表示编码对象的代码，可以是数字码、字母码或数字字母混合码；“说明”字段表示需要特殊说明的内容。其中，“名称”和“代码”是必选字段，“说明”是可选字段。如下表所示：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00016", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00017", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.2 通用编码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00018", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
本技术规范中引用到的信息分类编码国家标准包括：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00019", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
1. GB/T 4754-2011 国民经济行业分类

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00020", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
2. GB 11714-1997 全国组织机构代码编制规则

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00021", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
3. GB/T 12406-2008 表示货币和资金的代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00022", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
4. GB/T 2659-2000 世界各国和地区名称代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00023", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
5. GB/T 2260-2007 中华人民共和国行政区划代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00024", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
6. GB 11643－1999 公民身份号码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00025", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
7. GB/T 2261.1-2003 个人基本信息分类与代码 第 1部分：人的性别代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00026", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
8. 评标专家专业分类标准（试行）（发改法规[2010]1538号）

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00027", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3 业务编码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00028", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
结合数据项中的有关代码字段（在值域中有相关描述）进行编码说明。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00029", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.1 交易平台标识代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00030", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用组合码，编码长度为 11 位。排列顺序从左至右依次为：1 位行业门类字母码、6 位行政区域代码，以及 4 位全国交易平台序列号。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00031", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
其中行业门类字母码采用《GB/T 4754-2011 国民经济行业分类 GB/T 4754 国民经济行业分类》的门类。行政区域代码采用《GB/T 2260-2007 中华人民共和国行政区划代码GB/T 2260 中华人民共和国行政区划代码》的 6 位数字码。全国交易平台序列号的取值从 0001-9999，按照其在国家公共服务平台注册登记或交换登记信息时间排序。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00032", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.2 项目编号

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00033", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用组合码，编码长度为 17 位。排列顺序从左至右依次为：前 11 位由交易平台标识代码组成，后 6 位由项目序列号组成，项目序列号的取值从 000001-999999。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00034", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.3 招标组织形式代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00035", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 1 位顺序码表示。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00036", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00037", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>自行招标</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>委托招标</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00038", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.4 招标项目编号

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00039", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用组合码，编码长度为 20 位。排列顺序从左至右依次为：前 17 位由项目编号组成，后 3 位由招标项目在项目中的序列号组成，招标项目序列号的取值从 001-999。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00040", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.5 标段（包）编号

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00041", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用组合码，编码长度为 23 位。排列顺序从左至右依次为：前 20 位由招标项目编号组成，后 3 位由标段（包）在招标项目中的序列号组成，标段（包）序列号的取值从 001-999。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00042", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.6 标段（包）分类代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00043", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用组合码，编码长度 7 位。此编码参考了《评标专家专业分类标准（试行）》（发改法规[2010]1538 号），并在此基础上进行了扩展，排列顺序从左至右依次为：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00044", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
（1）第一级 1 位，A -工程、B-货物、C-服务、D-产权、E-土地；

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00045", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
（2）第二级 2 位，对应《评标专家专业分类标准》中的一级类别;

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00046", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
（3）第三级 2 位，对应《评标专家专业分类标准》的二
<table><tr><td>一级类别</td><td>二级类别</td></tr><tr><td>A-工程</td><td>01规划</td></tr><tr><td rowspan="9"></td><td>02投资策划与决策</td></tr><tr><td>03勘察</td></tr><tr><td>04设计</td></tr><tr><td>05监理</td></tr><tr><td>06 工程造价</td></tr><tr><td>07 1 项目管理(含代建)</td></tr><tr><td>08 工程施工</td></tr><tr><td>09 其他工程</td></tr><tr><td></td></tr><tr><td rowspan="4">B-货物</td><td>01 机械、设备类</td></tr><tr><td>02医疗器械</td></tr><tr><td>03金属材料</td></tr><tr><td>04 石油及其制品</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">05 煤炭煤层气及其制品06 化工材料及其制品07 建筑材料08药品其他</td></tr><tr><td colspan="1" rowspan="1">C-服务</td><td colspan="1" rowspan="1">01勘查与调查02 公共咨询03经济管理04 工商管理05金融06 法律07修理08租赁09交通运输与物流10 节能服务11高新技术服务12 其他服务13招标代理服务（备注：新增)</td></tr><tr><td colspan="1" rowspan="1">D-产权</td><td colspan="1" rowspan="1">另行制定</td></tr><tr><td colspan="1" rowspan="1">E-土地</td><td colspan="1" rowspan="1">另行制定</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00047", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
级类别，并新增以下类别：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00048", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>一级类别</td><td rowspan=1 colspan=1>二级类别</td><td rowspan=1 colspan=1>三级类别</td></tr><tr><td rowspan=1 colspan=1>C-服务</td><td rowspan=1 colspan=1>13招标代理服务</td><td rowspan=1 colspan=1>01工程类代理02货物类代理03月服务类代理04产权类代理05土地类代理</td></tr><tr><td rowspan=1 colspan=1>D-产权</td><td rowspan=1 colspan=1>另行制定</td><td rowspan=1 colspan=1>另行制定</td></tr><tr><td rowspan=1 colspan=1>E-土地</td><td rowspan=1 colspan=1>另行制定</td><td rowspan=1 colspan=1>另行制定</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00049", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
（4）第四级 2 位，对应《评标专家专业分类标准》的三级类别，如果没有四级类别可以使用 00 补充，例如：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00050", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">一级类别</td><td colspan="1" rowspan="1">二级类别</td><td colspan="1" rowspan="1">三级类别</td><td colspan="1" rowspan="1">四级类别</td></tr><tr><td colspan="1" rowspan="1">C-服务</td><td colspan="1" rowspan="1">13招标代理服务</td><td colspan="1" rowspan="1">01 工程类代|01中央投资理02 货物类代理03服务类代理04产权类代理</td><td colspan="1" rowspan="1">01 工程类代|01中央投资项目02 政府采购项目代03机电国际招标项目04通讯建设项目</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1">05土地类代理</td><td colspan="1" rowspan="1">05其他如果没有四级类别，可以用00补足</td></tr><tr><td colspan="1" rowspan="1">D-产权</td><td colspan="1" rowspan="1">另行制定</td><td colspan="1" rowspan="1">另行制定</td><td colspan="1" rowspan="1">另行制定</td></tr><tr><td colspan="1" rowspan="1">E-土地</td><td colspan="1" rowspan="1">另行制定</td><td colspan="1" rowspan="1">另行制定</td><td colspan="1" rowspan="1">另行制定</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00051", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.7 附件关联标识号

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00052", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用全球唯一标识符（GUID）表示，格式为“xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx”，其中每个 x是 0-9 或 a-f 范围内的一个 32 位十六进制数。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00053", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.8 招标方式代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00054", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 1 位顺序码。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00055", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00056", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>公开招标</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>邀请招标</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>其它</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00057", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.9 公告性质代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00058", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 1 位顺序码表示。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00059", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00060", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>正常公告</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>更正公告</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00061", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
B.3.10 公告类型代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00062", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 1 位顺序码表示。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00063", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00064", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>招标公告</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>资格预审公告</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00065", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
B.3.11 资格预审文件/招标文件/澄清与修改文件编号

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00066", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用组合码，编码长度为 26 位。排列顺序从左至右依次为：前 23 位由标段（包）编号组成；1 位表示文件类型，Y 表示资格预审文件，Z 表示招标文件， 2 位表示文件版本号，资格预审文件/招标文件从 01 开始编号，此后的答疑澄清与修改文件每次版本号递增 1，取值范围从 01-99。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00067", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.12 是否代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00068", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 1 位顺序码。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00069", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00070", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>0</td><td rowspan=1 colspan=1>否</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>是</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00071", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.13 公示类型代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00072", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 1 位顺序码表示。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00073", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00074", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>正常</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>更正</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>其他</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00075", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.14 主体角色类型代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00076", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：用 1 位字母码表示。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00077", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00078", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">代码</td><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td></tr><tr><td colspan="1" rowspan="1">T</td><td colspan="1" rowspan="1">招标人</td><td colspan="1" rowspan="1"></td></tr><tr><td>B</td><td>投标人</td><td></td></tr><tr><td>A</td><td>招标代理机构</td><td></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00079", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.15 资质序列、行业和专业类别代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00080", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：用 6 位数字层次码表示。第一层 1、2 两位表示资质序列；第二层 3、4 两位表示行业分类，00 表示不分行业；第三层 5、6 位表示专业类别，00 表示不分专业类别。各层次的资质编码均按有关部门颁发的资质标准排序。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00081", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 1、第一层（1-2 位）资质序列：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00082", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>01</td><td rowspan=1 colspan=1>工程咨询</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>02</td><td rowspan=1 colspan=1>工程规划</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>03</td><td rowspan=1 colspan=1>工程勘察</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>04</td><td rowspan=1 colspan=1>工程设计</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>05</td><td rowspan=1 colspan=1>施工总承包</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>06</td><td rowspan=1 colspan=1>施工专业分包</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>07</td><td rowspan=1 colspan=1>施工劳务分包</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>08</td><td rowspan=1 colspan=1>工程监理</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>09</td><td rowspan=1 colspan=1>招标代理</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>工程造价</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>工程检测</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00083", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>房地产开发</td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>房地产评估</td></tr><tr><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>拆迁</td></tr><tr><td rowspan=1 colspan=1>15</td><td rowspan=1 colspan=1>园林</td></tr><tr><td rowspan=1 colspan=1>16</td><td rowspan=1 colspan=1>设计施工一体化</td></tr><tr><td rowspan=1 colspan=1>...9</td><td rowspan=1 colspan=1>其他</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00084", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 2、第二层（3-4 位）资质行业：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00085", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">代码</td><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td></tr><tr><td colspan="1" rowspan="1">00</td><td colspan="1" rowspan="1">不分行业</td><td colspan="1" rowspan="1">如果资质没有行业区分，第二层编码就使用00。</td></tr><tr><td colspan="1" rowspan="1">01</td><td colspan="1" rowspan="1">房屋建筑</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">02</td><td colspan="1" rowspan="1">公路</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">03</td><td colspan="1" rowspan="1">铁路</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">04</td><td colspan="1" rowspan="1">港口与航道</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">05</td><td colspan="1" rowspan="1">水利水电</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">06</td><td colspan="1" rowspan="1">电力</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">07</td><td colspan="1" rowspan="1">矿山</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">08</td><td colspan="1" rowspan="1">冶炼</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">09</td><td colspan="1" rowspan="1">化工石油</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">10</td><td colspan="1" rowspan="1">市政公用</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">11</td><td colspan="1" rowspan="1">通信</td><td colspan="1" rowspan="1"></td></tr><tr><td>12</td><td>机电安装</td><td></td></tr><tr><td>...99</td><td>其他</td><td></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00086", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## 3、第三层（5-6 位）资质专业：

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00087", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>00</td><td rowspan=1 colspan=1>不分专业</td><td rowspan=1 colspan=1>如果没有专业区分，第三层编码就使用00。</td></tr><tr><td rowspan=1 colspan=1>01</td><td rowspan=1 colspan=1>地基与基础工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>02</td><td rowspan=1 colspan=1>土石方工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>03</td><td rowspan=1 colspan=1>建筑装修装饰</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>04</td><td rowspan=1 colspan=1>建筑幕墙工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>05</td><td rowspan=1 colspan=1>预拌商品混凝土</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>06</td><td rowspan=1 colspan=1>混凝土预制构件</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>07</td><td rowspan=1 colspan=1>园林古建筑工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>08</td><td rowspan=1 colspan=1>钢结构工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>09</td><td rowspan=1 colspan=1>高耸构筑物工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>电梯安装工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>消防设施工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>建筑防水工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>防腐保温工程</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>附着升降脚手架</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>15</td><td rowspan=1 colspan=1>金属门窗工程</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00088", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">16</td><td colspan="1" rowspan="1">预应力工程</td></tr><tr><td colspan="1" rowspan="1">17</td><td colspan="1" rowspan="1">起重设备安装工程</td></tr><tr><td colspan="1" rowspan="1">18</td><td colspan="1" rowspan="1">机电设备安装工程</td></tr><tr><td colspan="1" rowspan="1">19</td><td colspan="1" rowspan="1">爆破与拆除工程</td></tr><tr><td colspan="1" rowspan="1">20</td><td colspan="1" rowspan="1">建筑智能化工程</td></tr><tr><td colspan="1" rowspan="1">21</td><td colspan="1" rowspan="1">环保工程</td></tr><tr><td colspan="1" rowspan="1">22</td><td colspan="1" rowspan="1">电信工程</td></tr><tr><td colspan="1" rowspan="1">23</td><td colspan="1" rowspan="1">电子工程</td></tr><tr><td colspan="1" rowspan="1">24</td><td colspan="1" rowspan="1">桥梁工程</td></tr><tr><td colspan="1" rowspan="1">25</td><td colspan="1" rowspan="1">隧道工程</td></tr><tr><td colspan="1" rowspan="1">26</td><td colspan="1" rowspan="1">公路路面工程</td></tr><tr><td colspan="1" rowspan="1">27</td><td colspan="1" rowspan="1">公路路基工程</td></tr><tr><td colspan="1" rowspan="1">28</td><td colspan="1" rowspan="1">公路交通工程</td></tr><tr><td colspan="1" rowspan="1">29</td><td colspan="1" rowspan="1">铁路电务工程</td></tr><tr><td colspan="1" rowspan="1">30</td><td colspan="1" rowspan="1">铁路铺轨架梁工程</td></tr><tr><td colspan="1" rowspan="1">31</td><td colspan="1" rowspan="1">铁路电气化工程</td></tr><tr><td colspan="1" rowspan="1">32</td><td colspan="1" rowspan="1">机场场道工程</td></tr><tr><td colspan="1" rowspan="1">33</td><td colspan="1" rowspan="1">机场空管工程及航站楼弱电系统工程</td></tr><tr><td colspan="1" rowspan="1">34</td><td colspan="1" rowspan="1">机场目视助航工程</td></tr><tr><td colspan="1" rowspan="1">35</td><td colspan="1" rowspan="1">港口与海岸工程</td></tr><tr><td colspan="1" rowspan="1">36</td><td colspan="1" rowspan="1">港口装卸设备安装工程</td></tr><tr><td colspan="1" rowspan="1">37</td><td colspan="1" rowspan="1">航道工程</td></tr><tr><td colspan="1" rowspan="1">38</td><td colspan="1" rowspan="1">通航建筑工程</td></tr><tr><td colspan="1" rowspan="1">39</td><td colspan="1" rowspan="1">通航设备安装工程</td></tr><tr><td colspan="1" rowspan="1">40</td><td colspan="1" rowspan="1">水上交通管制工程</td></tr><tr><td colspan="1" rowspan="1">41</td><td colspan="1" rowspan="1">水工建筑物基础处理工程</td></tr><tr><td colspan="1" rowspan="1">42</td><td colspan="1" rowspan="1">水工金属结构制作与安装工程</td></tr><tr><td colspan="1" rowspan="1">43</td><td colspan="1" rowspan="1">水利水电机电设备安装工程</td></tr><tr><td colspan="1" rowspan="1">44</td><td colspan="1" rowspan="1">河湖整治工程</td></tr><tr><td colspan="1" rowspan="1">45</td><td colspan="1" rowspan="1">堤防工程</td></tr><tr><td colspan="1" rowspan="1">46</td><td colspan="1" rowspan="1">水工大坝工程</td></tr><tr><td colspan="1" rowspan="1">47</td><td colspan="1" rowspan="1">水工隧洞工程</td></tr><tr><td colspan="1" rowspan="1">48</td><td colspan="1" rowspan="1">火电设备安装工程</td></tr><tr><td colspan="1" rowspan="1">49</td><td colspan="1" rowspan="1">送变电工程</td></tr><tr><td colspan="1" rowspan="1">50</td><td colspan="1" rowspan="1">核工程</td></tr><tr><td colspan="1" rowspan="1">51</td><td colspan="1" rowspan="1">炉窑工程</td></tr><tr><td colspan="1" rowspan="1">52</td><td colspan="1" rowspan="1">冶炼机电设备安装工程</td></tr><tr><td colspan="1" rowspan="1">53</td><td colspan="1" rowspan="1">化工石油设备管道安装工程</td></tr><tr><td colspan="1" rowspan="1">54</td><td colspan="1" rowspan="1">管道工程</td></tr><tr><td colspan="1" rowspan="1">55</td><td colspan="1" rowspan="1">无损检测</td></tr><tr><td colspan="1" rowspan="1">56</td><td colspan="1" rowspan="1">海洋石油工程</td></tr><tr><td colspan="1" rowspan="1">57</td><td colspan="1" rowspan="1">城市轨道交通工程</td></tr><tr><td colspan="1" rowspan="1">58</td><td colspan="1" rowspan="1">城市及道路照明工程</td></tr><tr><td colspan="1" rowspan="1">59</td><td colspan="1" rowspan="1">体育场地设施工程</td></tr><tr><td colspan="1" rowspan="1">60</td><td colspan="1" rowspan="1">特种专业工程</td></tr><tr><td colspan="1" rowspan="1">61</td><td colspan="1" rowspan="1">工程建设项目招标代理</td></tr><tr><td colspan="1" rowspan="1">62</td><td colspan="1" rowspan="1">中央投资项目招标代理</td></tr><tr><td colspan="1" rowspan="1">63</td><td colspan="1" rowspan="1">政府采购招标代理</td></tr><tr><td colspan="1" rowspan="1">64</td><td colspan="1" rowspan="1">机电产品国际招标代理</td></tr><tr><td colspan="1" rowspan="1">65</td><td colspan="1" rowspan="1">通讯建设项目招标代理</td></tr><tr><td colspan="1" rowspan="1"></td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">99</td><td colspan="1" rowspan="1">其他</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00089", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
例如：房屋建筑工程施工总承包企业资质对应的代码是050100（05-施工总承包序列；01-房屋建筑行业；00-不分专业）；工程建设项目招标代理资格的代码是 090061。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00090", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.16 资质等级代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00091", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 2 位顺序码表示。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00092", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
码值内容见下表。
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>01</td><td rowspan=1 colspan=1>特级</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>02</td><td rowspan=1 colspan=1>一级</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00093", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>03</td><td rowspan=1 colspan=1>二级</td></tr><tr><td rowspan=1 colspan=1>04</td><td rowspan=1 colspan=1>三级</td></tr><tr><td rowspan=1 colspan=1>05</td><td rowspan=1 colspan=1>四级</td></tr><tr><td rowspan=1 colspan=1>06</td><td rowspan=1 colspan=1>甲级</td></tr><tr><td rowspan=1 colspan=1>07</td><td rowspan=1 colspan=1>乙级</td></tr><tr><td rowspan=1 colspan=1>08</td><td rowspan=1 colspan=1>丙级</td></tr><tr><td rowspan=1 colspan=1>09</td><td rowspan=1 colspan=1>丁级</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>暂定级 (预乙级)</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>初级</td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>中级</td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>高级</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00094", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.17 身份证件类型代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00095", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则： 参 考公安部制定 的《常用证件 代码》（GA/T517-2004），采用 2 位顺序码。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00096", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00097", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>01</td><td rowspan=1 colspan=1>居民身份证</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>02</td><td rowspan=1 colspan=1>军官证</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>03</td><td rowspan=1 colspan=1>武警警官证</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>04</td><td rowspan=1 colspan=1>士兵证</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00098", "chunk_name": "chunk-008-pages-0141-0160.pdf", "original_page_scope": [141, 160], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>05</td><td rowspan=1 colspan=1>军队离退休干部证</td></tr><tr><td rowspan=1 colspan=1>06</td><td rowspan=1 colspan=1>残疾人证</td></tr><tr><td rowspan=1 colspan=1>07</td><td rowspan=1 colspan=1>残疾军人证（1-8级）</td></tr><tr><td rowspan=1 colspan=1>08</td><td rowspan=1 colspan=1>护照</td></tr><tr><td rowspan=1 colspan=1>09</td><td rowspan=1 colspan=1>港澳同胞回乡证</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>港澳居民来往内地通行证</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>中华人民共和国往来港澳通行证</td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>台湾居民来往大陆通行证</td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>大陆居民往来台湾通行证</td></tr><tr><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>外国人居留证</td></tr><tr><td rowspan=1 colspan=1>15</td><td rowspan=1 colspan=1>外交官证</td></tr><tr><td rowspan=1 colspan=1>16</td><td rowspan=1 colspan=1>领事馆证</td></tr><tr><td rowspan=1 colspan=1>17</td><td rowspan=1 colspan=1>海员证</td></tr><tr><td rowspan=1 colspan=1>18</td><td rowspan=1 colspan=1>香港身份证</td></tr><tr><td rowspan=1 colspan=1>19</td><td rowspan=1 colspan=1>台湾身份证</td></tr><tr><td rowspan=1 colspan=1>20</td><td rowspan=1 colspan=1>澳门身份证</td></tr><tr><td rowspan=1 colspan=1>21</td><td rowspan=1 colspan=1>外国人身份证件</td></tr></table>

## chunk-009-pages-0161-0165.pdf — original pages 161-165

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00001", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>22</td><td rowspan=1 colspan=1>高校毕业生自主创业证</td></tr><tr><td rowspan=1 colspan=1>23</td><td rowspan=1 colspan=1>就业失业登记证</td></tr><tr><td rowspan=1 colspan=1>24</td><td rowspan=1 colspan=1>台胞证</td></tr><tr><td rowspan=1 colspan=1>25</td><td rowspan=1 colspan=1>退休证</td></tr><tr><td rowspan=1 colspan=1>26</td><td rowspan=1 colspan=1>离休证</td></tr><tr><td rowspan=1 colspan=1>99</td><td rowspan=1 colspan=1>其他证件</td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00002", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
B.3.18 奖惩对象类型代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00003", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 1 位顺序码。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00004", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00005", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">代码</td><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td></tr><tr><td colspan="1" rowspan="1">1</td><td colspan="1" rowspan="1">招标人</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">2</td><td colspan="1" rowspan="1">招标代理机构</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">3</td><td colspan="1" rowspan="1">招标代理人员</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">4</td><td colspan="1" rowspan="1">投标人</td><td colspan="1" rowspan="1">含工程、货物、服务投标人</td></tr><tr><td colspan="1" rowspan="1">5</td><td colspan="1" rowspan="1">设计和施工项目经理</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">6</td><td colspan="1" rowspan="1">总监理工程师</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">7</td><td colspan="1" rowspan="1">评标专家</td><td colspan="1" rowspan="1"></td></tr><tr><td></td><td></td><td></td></tr><tr><td>9</td><td>其他</td><td></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00006", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.19 奖惩类型代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00007", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 2 位顺序码。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00008", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00009", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td colspan="1" rowspan="1">代码</td><td colspan="1" rowspan="1">名称</td><td colspan="1" rowspan="1">说明</td></tr><tr><td colspan="1" rowspan="1">01</td><td colspan="1" rowspan="1">优良招标投标主体</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">02</td><td colspan="1" rowspan="1">优良交易对象</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">03</td><td colspan="1" rowspan="1">优良从业人员</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">04</td><td colspan="1" rowspan="1">警告</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">05</td><td colspan="1" rowspan="1">罚款</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">06</td><td colspan="1" rowspan="1">没收非法所得、没收非法财物</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">07</td><td colspan="1" rowspan="1">责令停产停业</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">08</td><td colspan="1" rowspan="1">暂扣或吊销许可证、执照</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">09</td><td colspan="1" rowspan="1">行政拘留</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">10</td><td colspan="1" rowspan="1">降低资质等级</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">11</td><td colspan="1" rowspan="1">暂停、取消职业资格证书</td><td colspan="1" rowspan="1"></td></tr><tr><td colspan="1" rowspan="1">12-99</td><td colspan="1" rowspan="1">其他行政处罚或不</td><td colspan="1" rowspan="1"></td></tr><tr><td></td><td>良行为记录</td><td></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00010", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.20 评标委员会组建申请编号

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00011", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用全球唯一标识符（GUID）表示，格式为“xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx”，其中每个 x是 0-9 或 a-f 范围内的一个 32 位十六进制数。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00012", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.21专家类型代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00013", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 1 位顺序码。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00014", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00015", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>招标人代表</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>专家库成员</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00016", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.22 专家编号

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00017", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用组合码，编码长度为 17。排列顺序从左至右依次为：10 位公共服务平台标识代码，1 位专家库在公共服务平台中的序列号，6 位是专家在专家库中的序列号（根据登记入库的先后自动排序）。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00018", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.23 公共服务平台标识代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00019", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用组合码，编码长度为 10 位。排列顺序从左至右依次为：6 位行政区域代码，以及 4 位全国公共服务

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00020", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
平台序列号。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00021", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
行政区域代码采用《GB/T 2260-2007 中华人民共和国行政区划代码》的 6 位数字码。全国公共服务平台序列号的取值从 001-999，按照其在国家公共服务平台注册登记或交换登记信息时间排序。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00022", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.24 平台类型代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00023", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 1 位字母码。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00024", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00025", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>P</td><td rowspan=1 colspan=1>公共服务平台</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>E</td><td rowspan=1 colspan=1>交易平台</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>G</td><td rowspan=1 colspan=1>行政监督平台</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00026", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.25金额单位代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00027", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 1 位顺序码。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00028", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00029", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>元</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>万元</td><td rowspan=1 colspan=1></td></tr></table>

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00030", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
## B.3.26通知书类型代码

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00031", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
编码规则：采用 1 位顺序码。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00032", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "no_baseline_text_match"} -->
码值内容见下表。

<!-- mineru_pdf_source_locator: {"mineru_block_id": "mineru-block-00033", "chunk_name": "chunk-009-pages-0161-0165.pdf", "original_page_scope": [161, 165], "mapping_method": "unmapped", "confidence": 0.0, "source_locators": [], "gate_block_reason": "complex_or_merged_table_without_baseline_match"} -->
<table><tr><td rowspan=1 colspan=1>代码</td><td rowspan=1 colspan=1>名称</td><td rowspan=1 colspan=1>说明</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>中标通知书</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>招标结果通知书</td><td rowspan=1 colspan=1></td></tr></table>
