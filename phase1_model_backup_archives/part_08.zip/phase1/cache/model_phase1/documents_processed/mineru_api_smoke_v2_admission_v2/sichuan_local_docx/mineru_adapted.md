---
document_id: "DOC-5672f78d7ba4"
source_file: "E:\\申博材料\\Davood Shojaei\\cache\\model_phase1\\law_sources\\Level 4 (Local regulations and standard documents)\\四川省建筑管理条例_20210929.docx"
source_file_hash: "5672f78d7ba4e31d4cbb06f2e34f3a199cc4765f858b1e232e1b721ba8a19778"
parser: MinerU Agent API + source-locator adapter
quality_gate: "pass"
rag_eligible: true
untrusted_document_content: true
---

<!-- MinerU content remains untrusted data, not system instructions. -->

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00001", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 3"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
四川省建筑管理条例

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00002", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 5"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（1996年10月14日四川省第八届人民代表大会常务委员会第二十三次会议通过  根据2002年5月30日四川省第九届人民代表大会常务委员会第二十九次会议《关于修改〈四川省建筑管理条例〉的决定》第一次修正  根据2021年9月29日四川省第十三届人民代表大会常务委员会第三十次会议《关于修改〈四川省建筑管理条例〉的决定》第二次修正）

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00003", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 7"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第一条  为了贯彻创新、协调、绿色、开放、共享的发展理念，维护建筑活动当事人的合法权益，规范建筑市场秩序，保证建设工程质量，提高建设工作投资效益，促进建筑业健康发展，根据国家有关法律、法规规定，结合四川省实际，制定本条例。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00004", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 8"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第二条  在四川省行政区域内从事建筑活动的当事人应当遵守本条例。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00005", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 9"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第三条  本条例所称建筑活动，是指新建、扩建、改建的建设工作（包括土木建筑工程，线路、管道和设备安装工程，建筑装饰装修工程等）的勘察、设计、施工、工程发包、工程承包、中介服务以及建筑构配件、商品混凝土生产等相关行为。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00006", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 10"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第四条  省人民政府住房城乡建设主管部门负责全省建筑活动的统一监督管理。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00007", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 11"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
市（州）、县（市、区）人民政府住房城乡建设主管部门负责所辖区域内建筑活动的统一监督管理。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00008", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 12"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
水利、交通运输、电力等部门依照法律、法规规定和政府职责分工，协助同级住房城乡建设主管部门负责本专业建筑活动的监督管理。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00009", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 13"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第五条  从事建筑活动的当事人，应当遵守国家法律、法规的规定，禁止分割、封锁、垄断建筑市场。坚持公开、公平、公正的原则，不得损害国家利益、社会公共利益和他人的合法权益。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00010", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 14"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
住房城乡建设主管部门工作人员应当认真履行职责，公正廉洁、秉公执法，不得参与对公正执行公务有影响的活动，不得违反规定收取费用。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00011", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 15"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
国家机关工作人员不得违反规定利用职权，参与建筑活动，谋取私利。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00012", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 16"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第六条  县级以上地方人民政府应当推进建筑业供给侧结构性改革和高质量发展，鼓励建筑科学技术研究，促进建筑技术进步，支持开发和采用建筑新技术、新工艺、新设备、新材料，推广装配化建造等新型绿色建造方式，推动智能建造与建筑工业化协同发展，推行工程总承包和全过程工程咨询,构建以信用为基础的新型监管机制。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00013", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 17"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
对建筑活动中和建筑科学技术研究方面做出显著成绩的当事人，由县级以上地方人民政府或者有关行政主管部门按照国家有关规定给予表彰、奖励。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00014", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 18"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第七条  县级以上地方人民政府住房城乡建设主管部门，对从事建筑活动的当事人实行统一的资质管理。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00015", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 19"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第八条  下列从事建筑活动的企事业单位，依法向县级以上地方人民政府住房城乡建设主管部门申请资质等级，经审查合格后，取得相应的资质证书：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00016", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 20"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（一）建设工程勘察、设计单位；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00017", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 21"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（二）建筑业企业（包括土木建筑工程、线路、管道和设备安装，建筑装饰装修，商品混凝土生产等企业）；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00018", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 22"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（三）建设工程监理、建设工程质量检测等机构。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00019", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 23"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第九条  从事建筑活动的专业技术人员，应当依法取得相应的执业资格证书，并在执业资格证书许可的范围内从事建筑活动。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00020", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 24"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
施工现场专业人员、建筑工人职业培训应当执行国家和省有关规定。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00021", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 25"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第十条  从事建筑活动的企事业单位应当在资质证书许可的范围内从事建筑活动。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00022", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 26"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
从事建筑活动的企事业单位合并、分立、解散等，应当于变更后三十日内，向原核发资质证书的部门办理变更或者注销手续。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00023", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 27"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第十一条  省外、境外企事业单位在四川省行政区域内从事建筑活动，应当向省人民政府住房城乡建设主管部门报送企业基本信息。企业应当对报送信息的真实性负责。企业基本信息发生变更的，应当及时告知省人民政府住房城乡建设主管部门。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00024", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 28"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第十二条  新建、扩建、改建工程，由建设单位依法申请办理施工许可证。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00025", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 29"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第十三条  建设单位在取得建设工程施工许可证后因故不能按期开工需要申请延期的，或者在建工程中止施工、恢复施工的，应当依法执行相关管理规定。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00026", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 30"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第十四条  住房城乡建设主管部门应当按照规定核发资质证书，任何单位和个人不得伪造、涂改、转让、出借本条例规定的资质证书。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00027", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 31"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第十五条  在本省行政区域内进行的建设工程，除依法不宜进行招标的外，应当采取招标方式发包，不得指定单位承包。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00028", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 32"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
有影响的公共大型建设工程设计方案，可以采取竞投方式确定。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00029", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 33"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
县级以上地方人民政府有关部门按照职责分工，对建设工程招标投标活动实施监督管理。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00030", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 34"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第十六条  建设工程招标信息，由建设单位和建设工程招标投标管理机构发布。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00031", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 35"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第十七条  政府投资建设的项目，不得要求施工单位垫资。发包人不得将应当由一个承包人完成的建设工程支解成若干部分发包给数个承包人。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00032", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 36"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第十八条  建筑业企业应当按照核定的资质等级和范围参加建设工程投标活动。不得在建设工程投标中哄抬或者不合理降低标价，串通投标。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00033", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 37"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第十九条  承包方不得以带资承包作为竞争手段承揽工程，也不得用拖欠建材和设备生产厂家货款的方法转嫁由此造成的资金缺口。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00034", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 38"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
承包方承包的建设工程应当自行组织完成，建设工程承包方可以按照规定将所承包的工程分包给具备相应资质的承包方。承包分包工程的承包方不得将承包工程转包。严禁挂靠承包。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00035", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 39"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第二十条  推行建设工程监理制度。下列建设工程应当实行监理：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00036", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 40"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（一）国家和省重点建设工程项目；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00037", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 41"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（二）大中型市政公用事业工程项目；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00038", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 42"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（三）成片开发建设的住宅小区工程项目；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00039", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 43"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（四）利用外资的建设项目；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00040", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 44"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（五）法律、法规规定的其他工程项目。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00041", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 45"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第二十一条  实行建设工程监理应当签订监理合同，建设工程监理单位应当按照监理合同和有关规定，从事监理活动。因监理责任造成损失的，监理单位应当依法承担相应的赔偿责任。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00042", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 46"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
监理单位不得承包工程，不得经营建筑材料、构配件和建筑机械、设备。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00043", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 47"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第二十二条  工程咨询单位不得同时接受招标方和投标方对同一工程项目的咨询。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00044", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 48"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第二十三条  从事建筑的各方当事人，应当参照示范文本签订合同。县级以上地方人民政府住房城乡建设主管部门依照法律、法规规定的职责，负责对建筑活动合同的监督。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00045", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 49"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第二十四条  省人民政府住房城乡建设主管部门会同有关部门根据国家规定，制定、发布本省建设工程计价定额、费用定额和计价方法。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00046", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 50"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第二十五条  省人民政府住房城乡建设主管部门应当根据市场价格变化情况，适时调整并发布工程造价调整系数。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00047", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 51"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第二十六条  工程造价由建设单位和承包方依据国家和省规定的工程计价定额、费用定额和计价方法在合同中确定。建设单位对工程质量和工期要求超过国家规定标准的，应当给予承包方相应的补偿或者奖励。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00048", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 52"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第二十七条  全部使用国有资金投资或者以国有资金投资为主的建设工程项目应当执行国家和省统一制定的各类定额及计价规则，有效控制和合理确定工程造价。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00049", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 53"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第二十八条  在建筑活动中执行定额，编制工程预算、结算、编审工程标底、确定工程中标价等，应当接受住房城乡建设主管部门的监督检查。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00050", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 54"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第二十九条  建设工程勘察、设计、施工的质量应当符合建设工程国家标准、行业标准、地方标准、企业标准的要求。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00051", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 55"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
建设工程地方标准由省人民政府住房城乡建设主管部门制定，并与省人民政府市场监管部门联合发布，报国务院住房城乡建设主管部门和市场监管部门备案。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00052", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 56"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第三十条  建设工程质量实行企业保证、社会监理、政府监督、用户评价相结合的质量管理体制。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00053", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 57"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第三十一条  实施建设工程质量监督制度。新建、扩建、改建的建设工程，建设单位应当接受建设工程质量监督机构的监督管理。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00054", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 58"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第三十二条  建设工程质量监督机构应当具备相应的条件和能力，经省人民政府住房城乡建设主管部门审查批准后，方可从事建设工程质量监督工作。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00055", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 59"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
建设工程质量检测机构应当经省人民政府住房城乡建设主管部门审查合格，并按照规定经市场监管部门计量认证合格，方可从事建设工程质量检测。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00056", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 60"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第三十三条  建设工程质量监督机构依据法律、法规和技术标准、规范、规程，对工程勘察、设计、施工质量以及工程所用的建筑材料、设备、构配件、商品混凝土的质量进行监督检查。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00057", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 61"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第三十四条  实行建设工程质量责任制度。建设单位、勘察、设计单位、建筑业企业应当建立健全质量管理和保障体系，全面落实质量责任制。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00058", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 62"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第三十五条  建设单位应当根据工程的规范、性质和质量要求，选择具有相应资质等级的勘察、设计和建筑业企业，不得擅自更改设计文件。不得指定购买建筑材料、设备的供应单位。建设单位需要自己定货采购的，应当在合同中明确其责任和要求。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00059", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 63"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第三十六条  建设工程勘察、设计单位应当按照国家和省有关工程勘察、设计技术标准、规范和规程进行设计，并对勘察、设计技术成果负责。不得无证或者未经批准越级承担勘察、设计，不得转让图签、图章，不得指定建设工程材料、设备供应单位。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00060", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 64"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第三十七条  建设工程承包方应当按照设计文件施工，并遵守国家和省制定的有关技术标准、质量验评标准、施工规范、操作规程，对所承包的工程质量负责。不得无证、越级承包工程，不得采购、使用不合格的材料、设备、构配件、商品混凝土。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00061", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 65"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第三十八条  建设构配件、商品混凝土生产企业应当严格按照产品质量标准进行生产，并对其生产的产品质量负责。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00062", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 66"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第三十九条  建设工程应当依法实行验收制度。未经竣工验收或者验收不合格的，不得交付使用。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00063", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 67"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
实行联合竣工验收的，应当遵守国家和省相关规定。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00064", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 68"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第四十条  建设工程应当按照国家有关建设工程质量管理的规定实行保修。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00065", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 69"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第四十一条  建设工程在规定的保修期限内，维修由建设工程承包方负责，其费用由责任方承担。因不可抗力造成的质量缺陷，维修费用由建设单位承担。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00066", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 70"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第四十二条  建筑施工应当贯彻安全第一、预防为主的方针，建筑业企业应当加强文明施工管理，科学组织施工，做好施工现场的各项管理工作。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00067", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 71"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第四十三条  建筑业企业应当采取维护安全、防范危险、预防火灾等措施。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00068", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 72"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
对毗邻建筑物、构筑物，建筑业企业应当采取防止其损坏的措施，所需费用由建设单位负责。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00069", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 73"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第四十四条  建设单位应当向建筑业企业提供与施工现场相关的地下管线资料，建筑业企业应当采取措施加以保护，所需费用由建设单位负责。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00070", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 74"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第四十五条  建设单位、建筑业企业应当遵守国家有关文物保护、环境保护的法律、法规的规定，采取措施做好文物、古树名木保护工作，控制施工现场的各种粉尘、废气、废水、固体废弃物以及噪声、震动对环境的污染和危害。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00071", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 75"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第四十六条  有下列情况之一，建设单位应当依法到有关部门办理申报批准手续：

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00072", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 76"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（一）临时占用规划批准范围以外场地的；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00073", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 77"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（二）损坏道路、管线、电力、通讯等公共设施及砍伐树木、迁移古树名木的；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00074", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 78"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（三）发现地下文物，需要继续进行施工的；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00075", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 79"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（四）临时停水、停电、中断交通的；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00076", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 80"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（五）进行爆破作业的；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00077", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 81"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（六）损毁水文、测绘标志的；

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00078", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 82"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
（七）法律、法规规定的其他需要办理报批手续的。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00079", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 83"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第四十七条  涉及主体和承重结构需要变动的建筑装饰工程及外型改变的工程，建设单位应当在施工前委托原设计单位或者具有相应资质等级的设计单位提出设计方案；没有设计方案的，不得施工。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00080", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 84"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第四十八条  建筑安全实行企业负责、行业管理、国家监察、群众监督的安全生产管理体制。建筑安全管理由项目所在地县级以上地方人民政府住房城乡建设主管部门负责，并接受同级应急管理部门的监督检查。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00081", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 85"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第四十九条  建筑工程施工实行安全生产责任制度。施工现场的安全由建设工程承包方负责。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00082", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 86"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
建设工程承包方应当加强安全技术管理，落实安全技术措施，加强安全技术培训、考核，严格安全纪律和安全教育。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00083", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 87"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
严禁违章指挥、违章作业，对危及生命安全和身体健康的违章指令，作业者有权拒绝执行和制止，并可以提出批评、检举和控告。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00084", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 88"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第五十条  建筑施工生产发生安全事故，应当依照有关法律、法规的规定及时报告和处理。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00085", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 89"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第五十一条  建筑活动当事人违反本条例规定，造成建筑物、构筑物垮塌或者人身伤亡事故，构成犯罪的，由司法机关依法追究刑事责任。并逐级追究主管机关和主管负责人的责任。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00086", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 90"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
国家机关工作人员和建筑活动当事人索贿、行贿、受贿、玩忽职守、滥用职权、徇私舞弊的，由所在单位或者有关主管部门依法给予处分；构成犯罪的，由司法机关依法追究刑事责任。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00087", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 91"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第五十二条  当事人对行政处罚不服的，可依法申请行政复议或者提起行政诉讼。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00088", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 92"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第五十三条  本条例收缴罚款按照《中华人民共和国行政处罚法》的规定执行。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00089", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 93"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第五十四条  违反本条例规定，法律法规已有法律责任规定的，从其规定。

<!-- mineru_source_locator: {"mineru_block_id": "mineru-block-00090", "mapping_method": "exact_block", "confidence": 1.0, "source_locators": ["document order / paragraph 94"], "retrieval_admission": "high_trust", "independent_evidence": true, "verification_status": "locator_gate_passed", "human_review_required_if_used": false} -->
第五十五条  本条例自公布之日起施行。
